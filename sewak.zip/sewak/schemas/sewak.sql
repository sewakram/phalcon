-- phpMyAdmin SQL Dump
-- version 4.5.2
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Feb 02, 2018 at 10:50 AM
-- Server version: 10.1.13-MariaDB
-- PHP Version: 5.6.21

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `sewak`
--

-- --------------------------------------------------------

--
-- Table structure for table `companies`
--

CREATE TABLE `companies` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(70) COLLATE utf8_unicode_ci NOT NULL,
  `telephone` varchar(30) COLLATE utf8_unicode_ci NOT NULL,
  `address` varchar(40) COLLATE utf8_unicode_ci NOT NULL,
  `city` varchar(40) COLLATE utf8_unicode_ci NOT NULL,
  `creat_date` timestamp(6) NOT NULL DEFAULT CURRENT_TIMESTAMP
) ;

--
-- Dumping data for table `companies`
--

INSERT INTO `companies` (`id`, `name`, `telephone`, `address`, `city`, `creat_date`, `email`) VALUES
(1, 'Acme', '31566564', 'Address', 'nagpur', '2017-12-01 08:39:25.555274', 'acme@gmail.com'),
(2, 'Acme Inc', '+44 564612345', 'Guildhall, PO Box 270, London', 'London', '2017-12-14 00:49:08.000000', 'acme@gmail.com'),
(3, 'ram', '1234567689', 'ramtek', 'nagpur', '0000-00-00 00:00:00.000000', 'sewakdeshmukh19@gmail.com'),
(4, 'ganesh', '12345665432', 'ram nagar,nagpur,maharashtra,india', 'nagpur', '2018-01-25 09:01:45.215672', 'ganesh@gmail.com');

-- --------------------------------------------------------

--
-- Table structure for table `contact`
--

CREATE TABLE `contact` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(70) COLLATE utf8_unicode_ci NOT NULL,
  `email` varchar(70) COLLATE utf8_unicode_ci NOT NULL,
  `comments` text COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `genba_languages`
--

CREATE TABLE `genba_languages` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(20) NOT NULL,
  `code` varchar(10) NOT NULL,
  `country_prefix` varchar(20) NOT NULL,
  `flag_url` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `genba_languages`
--

INSERT INTO `genba_languages` (`id`, `name`, `code`, `country_prefix`, `flag_url`) VALUES
(5, 'Español', '1', 'es', 'https://genba.online/uploads/flag/Spanish-ES.png'),
(15, 'English', '5', 'en', 'https://genba.online/uploads/flag/English-EN.png'),
(16, 'Hindi', '4', 'in', 'https://www.fg-a.com/flags/indian-button-round-1.png');

-- --------------------------------------------------------

--
-- Table structure for table `genba_lang_strings`
--

CREATE TABLE `genba_lang_strings` (
  `id` int(11) UNSIGNED NOT NULL,
  `languages_id` int(11) UNSIGNED NOT NULL,
  `backend` longtext,
  `frontend` longtext,
  `customer_app` text,
  `operator_app` text
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `genba_lang_strings`
--

INSERT INTO `genba_lang_strings` (`id`, `languages_id`, `backend`, `frontend`, `customer_app`, `operator_app`) VALUES
(3, 5, '{"Edit selected language":"Editar el idioma seleccionado"}', '{}', '{}', '{}'),
(4, 15, '{"Edit selected language":"Edit selected language","Invoices":"Invoices","Customer":"Customer","Name":"Name","Telephone":"Telephone","address":"address","city":"city","Product Type":"Product Type","Product":"Product","Stores Stock":"Stores Stock","Price":"Price","Quantity":"Quantity","Subtotal":"Subtotal","CGST(%)":"CGST(%)","SGST(%)":"SGST(%)","Sub Total":"Sub Total","Total Amount":"Total Amount","Rs":"Rs","Go Back":"Go Back","Save":"Save","edit_invoice":"Edit Invoice"}', NULL, NULL, NULL),
(5, 16, '{"Edit selected language":"\\u091a\\u092f\\u0928\\u093f\\u0924 \\u092d\\u093e\\u0937\\u093e \\u0938\\u0902\\u092a\\u093e\\u0926\\u093f\\u0924 \\u0915\\u0930\\u0947\\u0902","Invoices":" \\u091a\\u093e\\u0932\\u093e\\u0928","Customer":"\\u0917\\u094d\\u0930\\u093e\\u0939\\u0915","Name":"\\u0928\\u093e\\u092e","Telephone":"\\u091f\\u0947\\u0932\\u0940\\u092b\\u094b\\u0928","address":"\\u092a\\u0924\\u093e","city":"\\u0936\\u0939\\u0930","Product Type":"\\u0909\\u0924\\u094d\\u092a\\u093e\\u0926 \\u092a\\u094d\\u0930\\u0915\\u093e\\u0930","Product":"\\u0909\\u0924\\u094d\\u092a\\u093e\\u0926","Stores Stock":"\\u0938\\u094d\\u091f\\u094b\\u0930 \\u0938\\u094d\\u091f\\u0949\\u0915","Price":"\\u092e\\u0942\\u0932\\u094d\\u092f","Quantity":"\\u092e\\u093e\\u0924\\u094d\\u0930\\u093e","Subtotal":"\\u0909\\u092a-\\u092f\\u094b\\u0917","CGST(%)":"\\u0938\\u0940\\u091c\\u0940\\u090f\\u0938\\u091f\\u0940 (%)","SGST(%)":"\\u090f\\u0938\\u091c\\u0940\\u090f\\u0938\\u091f\\u0940 (%)","Sub Total":"\\u0909\\u092a \\u0915\\u0941\\u0932","Total Amount":"\\u0915\\u0941\\u0932 \\u0930\\u0915\\u092e","Rs":"\\u0930\\u0941\\u092a\\u092f\\u0947","Go Back":"\\u0935\\u093e\\u092a\\u0938 \\u091c\\u093e\\u0913","Save":"\\u091c\\u092e\\u093e \\u0915\\u0930\\u0947\\u0902","edit_invoice":"\\u091a\\u093e\\u0932\\u093e\\u0928 \\u0938\\u0902\\u092a\\u093e\\u0926\\u093f\\u0924 \\u0915\\u0930\\u0947\\u0902","Create Invoice":"\\u0907\\u0928\\u0935\\u0949\\u092f\\u0938 \\u092c\\u0928\\u093e\\u090f\\u0901","ADD ANOTHER":"\\u090f\\u0915 \\u0914\\u0930 \\u091c\\u094b\\u0921\\u093c\\u0947\\u0902","Search Customer":"\\u0917\\u094d\\u0930\\u093e\\u0939\\u0915 \\u0916\\u094b\\u091c\\u0947\\u0902","Id":"\\u0905\\u0928\\u0941 \\u0915\\u094d\\u0930\\u092e\\u093e\\u0902\\u0915","email":"\\u0908\\u092e\\u0947\\u0932","Search":"\\u0916\\u094b\\u091c","Create Customer":"\\u0917\\u094d\\u0930\\u093e\\u0939\\u0915 \\u092c\\u0928\\u093e\\u090f\\u0902"}', NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `invoices`
--

CREATE TABLE `invoices` (
  `id` int(10) UNSIGNED NOT NULL,
  `cid` int(10) NOT NULL,
  `cname` varchar(70) NOT NULL,
  `cnumber` varchar(70) NOT NULL,
  `caddress` varchar(70) NOT NULL,
  `ccity` varchar(70) NOT NULL,
  `amount` decimal(16,2) NOT NULL,
  `cgst` int(70) NOT NULL,
  `sgst` int(70) NOT NULL,
  `create_date` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `invoices`
--

INSERT INTO `invoices` (`id`, `cid`, `cname`, `cnumber`, `caddress`, `ccity`, `amount`, `cgst`, `sgst`, `create_date`) VALUES
(2, 4, 'ganesh', '12345665432', 'ram nagar,nagpur,maharashtra,india', 'nagpur', '20.40', 1, 1, '2018-01-25 14:54:59'),
(3, 4, 'ganesh', '12345665432', 'ram nagar,nagpur,maharashtra,india', 'nagpur', '11.55', 5, 5, '2018-01-25 14:58:18'),
(4, 4, 'ganesh', '12345665432', 'ram nagar,nagpur,maharashtra,india', 'nagpur', '11.55', 5, 5, '2018-01-25 15:15:31'),
(5, 3, 'ram', '1234567689', 'ramtek', 'nagpur', '11.00', 5, 5, '2018-01-25 16:47:27'),
(6, 3, 'ram', '1234567689', 'ramtek', 'nagpur', '11.00', 5, 5, '2018-01-25 17:23:46'),
(7, 3, 'ram', '1234567689', 'ramtek', 'nagpur', '100.20', 10, 10, '2018-01-25 17:35:02');

-- --------------------------------------------------------

--
-- Table structure for table `invoice_items`
--

CREATE TABLE `invoice_items` (
  `id` int(10) UNSIGNED NOT NULL,
  `ptype` int(40) NOT NULL,
  `name` varchar(40) NOT NULL,
  `price` decimal(16,2) NOT NULL,
  `qty` int(10) NOT NULL,
  `total` decimal(16,2) NOT NULL,
  `invoiceid` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `invoice_items`
--

INSERT INTO `invoice_items` (`id`, `ptype`, `name`, `price`, `qty`, `total`, `invoiceid`) VALUES
(3, 6, '11', '20.00', 1, '20.00', 2),
(4, 5, '6', '3.50', 3, '10.50', 3),
(5, 5, '6', '3.50', 3, '10.50', 4),
(6, 5, '12', '10.00', 1, '10.00', 5),
(7, 5, '12', '10.00', 1, '10.00', 6),
(8, 5, '12', '10.00', 4, '40.00', 7),
(9, 6, '9', '40.00', 1, '40.00', 7),
(10, 5, '6', '3.50', 1, '3.50', 7);

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE `products` (
  `id` int(10) UNSIGNED NOT NULL,
  `product_types_id` int(10) UNSIGNED NOT NULL,
  `name` varchar(70) COLLATE utf8_unicode_ci NOT NULL,
  `price` decimal(16,2) NOT NULL,
  `active` enum('Y','N') COLLATE utf8_unicode_ci NOT NULL,
  `qty` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  `creat_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`id`, `product_types_id`, `name`, `price`, `active`, `qty`, `creat_date`) VALUES
(1, 5, 'Artichoke', '10.50', 'Y', '40', '2017-12-30 04:33:12'),
(2, 5, 'Bell pepper', '10.40', 'Y', '10.00', '2017-12-30 04:33:12'),
(3, 5, 'Cauliflower', '20.10', 'Y', '0.00', '2017-12-30 04:33:12'),
(4, 5, 'Chinese cabbage', '15.50', 'Y', '10.00', '2017-12-30 04:33:12'),
(5, 5, 'Malabar spinach', '7.50', 'Y', '0.00', '2017-12-30 04:33:12'),
(6, 5, 'Onion', '3.50', 'Y', '49', '2017-12-30 04:33:12'),
(7, 5, 'Peanut', '4.50', 'Y', '0.00', '2017-12-30 04:33:12'),
(8, 6, 'Banana', '10.00', 'Y', '10.00', '2017-12-30 04:33:12'),
(9, 6, 'Apple', '40.00', 'Y', '9', '2018-01-09 12:07:55'),
(10, 6, 'Mango', '50.00', 'Y', '10', '2018-01-09 12:19:46'),
(11, 6, 'Orange', '20.00', 'Y', '10', '2018-01-09 13:18:06'),
(12, 5, 'tomato', '10.00', 'Y', '45', '2018-01-25 10:48:06');

-- --------------------------------------------------------

--
-- Table structure for table `product_types`
--

CREATE TABLE `product_types` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(70) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `product_types`
--

INSERT INTO `product_types` (`id`, `name`) VALUES
(5, 'Vegetables'),
(6, 'Fruits');

-- --------------------------------------------------------

--
-- Table structure for table `site_options`
--

CREATE TABLE `site_options` (
  `id` int(11) UNSIGNED NOT NULL,
  `key` varchar(70) NOT NULL,
  `value` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `site_options`
--

INSERT INTO `site_options` (`id`, `key`, `value`) VALUES
(3, 'lang_native_backend', '["Edit selected language","Invoices","Customer","Name","Telephone","address","city","Product Type","Product","Stores Stock","Price","Quantity","Subtotal","CGST(%)","SGST(%)","Sub Total","Total Amount","Rs","Go Back","Save","edit_invoice","Create Invoice","ADD ANOTHER","Search Customer","Id","email","Search","Create Customer"]'),
(4, 'lang_native_frontend', '[]'),
(5, 'lang_native_customer', '[]'),
(6, 'lang_native_operator', '[]'),
(7, 'site_close_status', '0'),
(8, 'site_close_message', 'App is close for now.'),
(9, 'country_iso_codes', '1,34,52,502,503,504,505,506,507');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(10) UNSIGNED NOT NULL,
  `username` varchar(32) COLLATE utf8_unicode_ci NOT NULL,
  `password` char(40) COLLATE utf8_unicode_ci NOT NULL,
  `name` varchar(120) COLLATE utf8_unicode_ci NOT NULL,
  `email` varchar(70) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `active` char(1) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `username`, `password`, `name`, `email`, `created_at`, `active`) VALUES
(1, 'demo', 'e10adc3949ba59abbe56e057f20f883e', 'Phalcon Demo', 'demo@phalconphp.com', '2012-04-10 20:53:03', 'Y'),
(2, 'sewak', '827ccb0eea8a706c4c34a16891f84e7b', 'sewak deshmukh', 'sewakdeshmukh19@gmail.com', '2017-11-27 12:33:24', 'Y'),
(3, 'ttttt', '8cb2237d0679ca88db6464eac60da96345513964', 'ttt', 'jorge@indicode.tech', '2017-11-28 11:32:52', 'Y'),
(4, 'ram', '8cb2237d0679ca88db6464eac60da96345513964', 'deshmukh', 'ram@gmail.com', '2017-12-26 12:13:54', 'Y');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `contact`
--
ALTER TABLE `contact`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `genba_languages`
--
ALTER TABLE `genba_languages`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `genba_lang_strings`
--
ALTER TABLE `genba_lang_strings`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `invoices`
--
ALTER TABLE `invoices`
  ADD PRIMARY KEY (`id`),
  ADD KEY `cid` (`cid`);

--
-- Indexes for table `invoice_items`
--
ALTER TABLE `invoice_items`
  ADD PRIMARY KEY (`id`),
  ADD KEY `invoiceid` (`invoiceid`),
  ADD KEY `ptype` (`ptype`) USING BTREE;

--
-- Indexes for table `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `product_types`
--
ALTER TABLE `product_types`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `site_options`
--
ALTER TABLE `site_options`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `key` (`key`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `companies`
--
ALTER TABLE `companies`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `contact`
--
ALTER TABLE `contact`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `genba_languages`
--
ALTER TABLE `genba_languages`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;
--
-- AUTO_INCREMENT for table `genba_lang_strings`
--
ALTER TABLE `genba_lang_strings`
  MODIFY `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
--
-- AUTO_INCREMENT for table `invoices`
--
ALTER TABLE `invoices`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;
--
-- AUTO_INCREMENT for table `invoice_items`
--
ALTER TABLE `invoice_items`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;
--
-- AUTO_INCREMENT for table `products`
--
ALTER TABLE `products`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;
--
-- AUTO_INCREMENT for table `product_types`
--
ALTER TABLE `product_types`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
--
-- AUTO_INCREMENT for table `site_options`
--
ALTER TABLE `site_options`
  MODIFY `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;
--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
