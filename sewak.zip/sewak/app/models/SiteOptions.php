<?php
use Phalcon\Mvc\Model;

class SiteOptions extends Model
{
    public function initialize()
    {
     $this->setSource("site_options");
    }
    public function validation()
    {
        
    }
}