<?php

use Phalcon\Mvc\Model;

/**
 * Products
 */
class Products extends Model
{
	/**
	 * @var integer
	 */
	public $id;

	/**
	 * @var integer
	 */
	public $product_types_id;

	/**
	 * @var string
	 */
	public $name;

	/**
	 * @var string
	 */
	public $price;

	/**
	 * @var string
	 */
	public $active;

	public $qty;


	/**
	 * Products initializer
	 */
	public function initialize()
	{
		$this->belongsTo('product_types_id', 'ProductTypes', 'id', [
			'reusable' => true
		]);
		try{
     $this->setSource("products");
   
    }
    catch(Exception $e){
      //var_dump($e->getMessage());
      echo " Line=", $e->getLine(), "\n";
    }
	}

	/**
	 * Returns a human representation of 'active'
	 *
	 * @return string
	 */
	public function getActiveDetail()
	{
		if ($this->active == 'Y') {
			return 'Yes';
		}
		return 'No';
	}
}
