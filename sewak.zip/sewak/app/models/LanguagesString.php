<?php 
use Phalcon\Mvc\Model;
class LanguagesString extends Model
{
   public function initialize()
   {
     $this->setSource("genba_lang_strings");
   }
}
?>