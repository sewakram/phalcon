<?php
 use Phalcon\Tag;
use Phalcon\Mvc\User\Component;

/**
 * Elements
 *
 * Helps to build UI elements for the application
 */
class Elements extends Component
{
    private $_headerMenu = [
        // 'navbar-left' => [
        //     'index' => [
        //         'caption' => 'Home',
        //         'action' => 'index'
        //     ],
        //     'invoices' => [
        //         'caption' => 'Invoices',
        //         'action' => 'index'
        //     ],
        //     'about' => [
        //         'caption' => 'About',
        //         'action' => 'index'
        //     ],
        //     'contact' => [
        //         'caption' => 'Contact',
        //         'action' => 'index'
        //     ],
        // ],
        'navbar-right' => [
            // 'session' => [
            //     'caption' => 'Log In/Sign Up',
            //     'action' => 'index'
            // ],
        ]
    ];

    private $_taben = [
        'Invoices' => [
            'controller' => 'invoices',
            'action' => 'index',
            'any' => false
        ],
        'Customers' => [
            'controller' => 'companies',
            'action' => 'index',
            'any' => true
        ],
        'Products' => [
            'controller' => 'products',
            'action' => 'index',
            'any' => true
        ],
        'Product Types' => [
            'controller' => 'producttypes',
            'action' => 'index',
            'any' => true
        ],
        'Your Profile' => [
            'controller' => 'invoices',
            'action' => 'profile',
            'any' => false
        ],
        'language Admin' => [
            'controller' => 'admin-languages',
            'action' => 'index',
            'any' => false
        ]
    ];

    private $_tabsp = [
        'Facturas' => [
            'controller' => 'invoices',
            'action' => 'index',
            'any' => false
        ],
        'Clientes' => [
            'controller' => 'companies',
            'action' => 'index',
            'any' => true
        ],
        'Productos' => [
            'controller' => 'products',
            'action' => 'index',
            'any' => true
        ],
        'Tipos de productos' => [
            'controller' => 'producttypes',
            'action' => 'index',
            'any' => true
        ],
        'Tu perfil' => [
            'controller' => 'invoices',
            'action' => 'profile',
            'any' => false
        ],
        'administrador del idioma' => [
            'controller' => 'admin-languages',
            'action' => 'index',
            'any' => false
        ]
    ];

    private $_tabh = [
        ' चालान' => [
            'controller' => 'invoices',
            'action' => 'index',
            'any' => false
        ],
        'ग्राहकों' => [
            'controller' => 'companies',
            'action' => 'index',
            'any' => true
        ],
        'उत्पाद' => [
            'controller' => 'products',
            'action' => 'index',
            'any' => true
        ],
        'उत्पाद प्रकार' => [
            'controller' => 'producttypes',
            'action' => 'index',
            'any' => true
        ],
        'आपकी रूपरेखा' => [
            'controller' => 'invoices',
            'action' => 'profile',
            'any' => false
        ],
        'भाषा प्रशासन' => [
            'controller' => 'admin-languages',
            'action' => 'index',
            'any' => false
        ]
    ];



    /**
     * Builds header menu with left and right items
     *
     * @return string
     */
    public function getMenu()
    {

        $auth = $this->session->get('auth');
        if ($auth) {
            $this->_headerMenu['navbar-right']['session'] = [
                'caption' => 'Log Out',
                'action' => 'end'
            ];
        } else {
            unset($this->_headerMenu['navbar-left']['invoices']);
        }

        $controllerName = $this->view->getControllerName();
        foreach ($this->_headerMenu as $position => $menu) {
            echo '<div class="nav-collapse">';
            echo '<ul class="nav navbar-nav ', $position, '">';
            foreach ($menu as $controller => $option) {
                if ($controllerName == $controller) {
                    echo '<li class="active">';
                } else {
                    echo '<li>';
                }
                echo $this->tag->linkTo($controller . '/' . $option['action'], $option['caption']);
                echo '</li>';
            }
            echo '</ul>';
            echo '</div>';
        }

    }

    /**
     * Returns menu tabs
     */
    public function getTabs()
    {
        $controllerName = $this->view->getControllerName();
        $actionName = $this->view->getActionName();
        echo '<ul class="nav nav-tabs">';
        $auth = $this->session->get('lang');
        if($auth=='in'){
        foreach ($this->_tabh as $caption => $option)
    
         {
            if ($option['controller'] == $controllerName && ($option['action'] == $actionName || $option['any'])) {
                echo '<li class="active">';
            } else {
                echo '<li>';
            }

            echo $this->tag->linkTo($option['controller'] . '/' . $option['action'], $caption); 


            echo '</li>';
        }
        }else if($auth=='es'){
        foreach ($this->_tabsp as $caption => $option)
    
         {
            if ($option['controller'] == $controllerName && ($option['action'] == $actionName || $option['any'])) {
                echo '<li class="active">';
            } else {
                echo '<li>';
            }

            echo $this->tag->linkTo($option['controller'] . '/' . $option['action'], $caption); 


            echo '</li>';
        }
        }
        else
        {
        foreach ($this->_taben as $caption => $option)
            {
            if ($option['controller'] == $controllerName && ($option['action'] == $actionName || $option['any'])) {
                echo '<li class="active">';
            } else {
                echo '<li>';
            }

            echo $this->tag->linkTo($option['controller'] . '/' . $option['action'], $caption); 


            echo '</li>';
        }
    }
        echo '</ul>';
    }
}
