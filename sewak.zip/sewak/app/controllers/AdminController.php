<?php

/**
 * AdminController
 *
 * Allows to authenticate users
 */
/*use Phalcon\Http\Response\Cookies;*/
use Phalcon\Http\Response;
use Phalcon\Session\Adapter\Files as Session;

class AdminController extends ControllerAdminBase
{
    public function initialize()
    {
        parent::initialize();
    }
     
    
    public function langSetAction($mylang)
    {
/*            $session = new Session();
            $session->start();*/
			//echo $mylang;
			//die;

            $this->view->disable();
            $request=$this->request;
            $url = $request->get('redirect_url');
			 // echo 'sewak'.$url;  
			 // die;
            $this->session->set("lang", $mylang);
            return $this->response->redirect($url);
      
    }
    

}