<?php
/*use Phalcon\Mvc\View;
use Phalcon\Mvc\Controller;*/
use Phalcon\Mvc\Model\Criteria;
use Phalcon\Paginator\Adapter\Model as Paginator;

/**
 * ProductTypesController
 *
 * Manage operations for product of types
 */
class TestMapsController extends ControllerBase
{
   // echo "string";exit();
    // public function initialize()
    // {
    //     $this->tag->setTitle('Manage your products types');
    //     parent::initialize();
    // }

    /**
     * Shows the index action
     */
    public function indexAction()
    {
      echo "fgdgdfgdf";exit();  
    }

    public function testAction()
    {
        echo "string";exit();
    }

    
}
