<?= $this->getContent() ?>

<ul class="pager">
    <li class="previous">
        <?= $this->tag->linkTo(['products', '&larr; Go Back']) ?>
    </li>
    <li class="next">
        <?= $this->tag->linkTo(['products/new', 'Create products']) ?>
    </li>
</ul>

<?php $v13395702621iterated = false; ?><?php $v13395702621iterator = $page->items; $v13395702621incr = 0; $v13395702621loop = new stdClass(); $v13395702621loop->self = &$v13395702621loop; $v13395702621loop->length = count($v13395702621iterator); $v13395702621loop->index = 1; $v13395702621loop->index0 = 1; $v13395702621loop->revindex = $v13395702621loop->length; $v13395702621loop->revindex0 = $v13395702621loop->length - 1; ?><?php foreach ($v13395702621iterator as $product) { ?><?php $v13395702621loop->first = ($v13395702621incr == 0); $v13395702621loop->index = $v13395702621incr + 1; $v13395702621loop->index0 = $v13395702621incr; $v13395702621loop->revindex = $v13395702621loop->length - $v13395702621incr; $v13395702621loop->revindex0 = $v13395702621loop->length - ($v13395702621incr + 1); $v13395702621loop->last = ($v13395702621incr == ($v13395702621loop->length - 1)); ?><?php $v13395702621iterated = true; ?>
    <?php if ($v13395702621loop->first) { ?>
<table class="table table-bordered table-striped" align="center">
    <thead>
        <tr>
            <th>Id</th>
            <th>Product Type</th>
            <th>Name</th>
            <th>Price</th>
            <th>Stock</th>
            <th>Active</th>
            <th colspan="2">Action</th>
        </tr>
    </thead>
    <tbody>
    <?php } ?>
        <tr>
            <td><?= $product->id ?></td>
            <td><?= $product->getProductTypes()->name ?></td>
            <td><?= $product->name ?></td>
            <td>$<?= sprintf('%.2f', $product->price) ?></td>
            <td><?= $product->qty ?></td>
            <td><?= $product->getActiveDetail() ?></td>
            <td width="7%"><?= $this->tag->linkTo(['products/edit/' . $product->id, '<i class="glyphicon glyphicon-edit"></i> Edit', 'class' => 'btn btn-default']) ?></td>
            <td width="7%"><?= $this->tag->linkTo(['products/delete/' . $product->id, '<i class="glyphicon glyphicon-remove"></i> Delete', 'class' => 'btn btn-default']) ?></td>
        </tr>
    <?php if ($v13395702621loop->last) { ?>
    </tbody>
    <tbody>
        <tr>
            <td colspan="8" align="right">
                <div class="btn-group">
                    <?= $this->tag->linkTo(['products/search', '<i class="icon-fast-backward"></i> First', 'class' => 'btn']) ?>
                    <?= $this->tag->linkTo(['products/search?page=' . $page->before, '<i class="icon-step-backward"></i> Previous', 'class' => 'btn']) ?>
                    <?= $this->tag->linkTo(['products/search?page=' . $page->next, '<i class="icon-step-forward"></i> Next', 'class' => 'btn']) ?>
                    <?= $this->tag->linkTo(['products/search?page=' . $page->last, '<i class="icon-fast-forward"></i> Last', 'class' => 'btn']) ?>
                    <span class="help-inline"><?= $page->current ?> of <?= $page->total_pages ?></span>
                </div>
            </td>
        </tr>
    </tbody>
</table>
    <?php } ?>
<?php $v13395702621incr++; } if (!$v13395702621iterated) { ?>
    No products are recorded
<?php } ?>
