
<?= $this->getContent() ?>
<br>
<div align="right">
    <?= $this->tag->linkTo(['companies/new', $t->_('Create Customer'), 'class' => 'btn btn-primary']) ?>
</div>

<?= $this->tag->form(['companies/search']) ?>

<h2><?= $t->_('Search Customer') ?></h2>

<fieldset>

<?php foreach ($form as $element) { ?>
    <?php if (is_a($element, 'Phalcon\Forms\Element\Hidden')) { ?>
<?= $element ?>
    <?php } else { ?>
<div class="control-group">
    <?= $element->label(['class' => 'control-label']) ?>
    <div class="controls">
        <?= $element ?>
    </div>
</div>
    <?php } ?>
<?php } ?>

<br><div class="control-group">
    <?= $this->tag->submitButton([$t->_('Search'), 'class' => 'btn btn-primary']) ?>
</div>

</fieldset>

</form>
