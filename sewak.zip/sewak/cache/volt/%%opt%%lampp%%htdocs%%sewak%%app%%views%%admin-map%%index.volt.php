<?php use Phalcon\Tag;?>
<!-- <link rel="stylesheet" type="text/css" href="/global/vendor/bootstrap-select/bootstrap-select.css">
<script type="text/javascript" src="/global/vendor/bootstrap-select/bootstrap-select.js"></script>
<script type="text/javascript" src="/global/js/components/bootstrap-select.js"></script>
<?= $this->tag->javascriptInclude('js/bootbox.min.js') ?> -->
<div class="row" data-plugin="matchHeight" data-by-row="true">
        <div class="col-sm-12">
        <!-- Panel Linearea Two -->

        <!--<h3 class="panel-title blue-grey-200 font-weight-200">
        <i class="panel-title-icon icon md-cast blue-gray-100" aria-hidden="true"></i> Create a new country</h3>-->

        <div class="widget widget-shadow" id="charLineareaTwo">
            <div class="widget-content padding-30 height-full">
                <div class="row" style="height:calc(100% - 300px);">
                    <div class="col-xs-8">
                      <h3 class="grey-700">STRING KEY</h3>
                      
                    </div>
                    <div class="col-xs-8">
                      <div class="row pull-right">
                        <div class="col-xs-12">
                          

                        </div>
                      </div>
                    </div>
                   
                    
                  </div>


                  <div style="padding-top:10px;">
                     <form action="#!" method="POST" autocomplete="false" class="form-horizontal" >
                     <div class="row">
                        <div class="col-md-1"></div>
                        <div class="col-md-4">
                        <label for="key" class="label-field">Key:</label>
                          <div class="form-group">
                           
                            <select name="key" class="form-control" required data-plugin="selectpicker" id="searchkey">
                              <option value="lang_native_backend">Backend</option>
                              <option value="lang_native_frontend">Frontend</option>
                              <option value="lang_native_customer">Customer</option>
                              <option value="lang_native_operator">Operator</option>
                            </select>
                            </div>
                          </div>
                          <div class="col-md-1"></div>
                          <div class="col-md-4">
                           <div class="form-group">
                              <label for="value" class="label-field">Value:</label>
                              <!-- <input type="text" name="value_search" class="form-control" required> -->
                              <textarea id="value_search" class="form-control" required>
                              </textarea>
                           </div>
                           </div>
                          <div class="col-md-1">
                                    <div class="text-right">
                                        <button type="button" name="submit" class="btn btn-block btn-success create_operator waves-effect waves-light" onclick="checkvalue(this);">SUBMIT</button>
                                    </div>
                                </div>
                        </div>
                        <!-- <div class="row">
                              <div class="col-md-9"></div> -->
                                
                            <!-- </div> -->
                      </form>
                  </div>



          </div>
          </div>
        <!-- End Panel Linearea Two -->
      </div>
      </div>
      <div id="keysresult" class="modal fade modal-lg" role="dialog">
        <div class="modal-dialog">
          <div class="modal-content">
            <div class="modal-header">
              <button type="button" class="close" data-dismiss="modal">&times;</button>
              <h4 class="modal-title">Result</h4>
            </div>
            <div class="modal-body">
              <div class="row">
                <div class="col-md-4" id="added">

                </div>
                <div class="col-md-2">
                  
                </div>
                <div class="col-md-4" id="found">
                  
                </div>
            </div>
            <div class="modal-footer">
              <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
            </div>
          </div>

        </div>
      </div>
    </div>
<script type="text/javascript">
function checkvalue(){
  var value = $("#value_search").val();
  var searchkey = $('#searchkey').val();
  $("#value_search").val('');
  console.log('value',value,'searchkey',searchkey);
  //return false;
  if(value!='' && searchkey!='')
  {
    $.ajax({
      type:'POST',
      url:'admin-map/index',
      data:'value='+value+'&searchkey='+searchkey,
      dataType:'JSON',
      success:function(response){
        console.log(response);
        if(response.status==true){
          $('#added').html('');
          $('#found').html('');
          var added = response.added;
          var found = response.found;
          var li_added = '<span>Added Key</span><br/><ul class="list-group">';
          for(var i in added){
            li_added+='<li class="list-group-item">'+added[i]+'</li>';
          }          
          li_added+='</ul>';
          $('#added').append(li_added);
          var li_found = '<span>Found Key</span><br/><ul class="list-group">';
          for(var i in found){
            li_found+='<li class="list-group-item">'+found[i]+'</li>';
          }
          li_found+='</ul>';
          $('#found').append(li_found);
          $('#keysresult').modal('show');
        }
        else{
          
        }
      }
    })
  }
}
</script>