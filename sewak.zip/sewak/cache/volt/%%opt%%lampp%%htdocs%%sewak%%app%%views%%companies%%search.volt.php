<?= $this->getContent() ?>

<ul class="pager">
    <li class="previous pull-left">
        <?= $this->tag->linkTo(['companies/index', '&larr; Go Back']) ?>
    </li>
    <li class="pull-right">
        <?= $this->tag->linkTo(['companies/new', 'Create Customer']) ?>
    </li>
</ul>

<?php $v26418550411iterated = false; ?><?php $v26418550411iterator = $page->items; $v26418550411incr = 0; $v26418550411loop = new stdClass(); $v26418550411loop->self = &$v26418550411loop; $v26418550411loop->length = count($v26418550411iterator); $v26418550411loop->index = 1; $v26418550411loop->index0 = 1; $v26418550411loop->revindex = $v26418550411loop->length; $v26418550411loop->revindex0 = $v26418550411loop->length - 1; ?><?php foreach ($v26418550411iterator as $company) { ?><?php $v26418550411loop->first = ($v26418550411incr == 0); $v26418550411loop->index = $v26418550411incr + 1; $v26418550411loop->index0 = $v26418550411incr; $v26418550411loop->revindex = $v26418550411loop->length - $v26418550411incr; $v26418550411loop->revindex0 = $v26418550411loop->length - ($v26418550411incr + 1); $v26418550411loop->last = ($v26418550411incr == ($v26418550411loop->length - 1)); ?><?php $v26418550411iterated = true; ?>
<?php if ($v26418550411loop->first) { ?>
<table class="table table-bordered table-striped" align="center">
    <thead>
        <tr>
            <th>Id</th>
            <th>Name</th>
            <th>Telephone</th>
            <th>Email</th>
            <th>Address</th>
            <th>City</th>
            <th colspan="2">Action</th>
        </tr>
    </thead>
<?php } ?>
    <tbody>
        <tr>
            <td><?= $company->id ?></td>
            <td><?= $company->name ?></td>
            <td><?= $company->telephone ?></td>
            <td><?= $company->email ?></td>
            <td><?= $company->address ?></td>
            <td><?= $company->city ?></td>
            <td width="7%"><?= $this->tag->linkTo(['companies/edit/' . $company->id, '<i class="glyphicon glyphicon-edit"></i> Edit', 'class' => 'btn btn-default']) ?></td>
            <td width="7%"><?= $this->tag->linkTo(['companies/delete/' . $company->id, '<i class="glyphicon glyphicon-remove"></i> Delete', 'class' => 'btn btn-default']) ?></td>
        </tr>
    </tbody>
<?php if ($v26418550411loop->last) { ?>
    <tbody>
        <tr>
            <td colspan="8" align="right">
                <div class="btn-group">
                    <?= $this->tag->linkTo(['companies/search', '<i class="icon-fast-backward"></i> First', 'class' => 'btn btn-default']) ?>
                    <?= $this->tag->linkTo(['companies/search?page=' . $page->before, '<i class="icon-step-backward"></i> Previous', 'class' => 'btn btn-default']) ?>
                    <?= $this->tag->linkTo(['companies/search?page=' . $page->next, '<i class="icon-step-forward"></i> Next', 'class' => 'btn btn-default']) ?>
                    <?= $this->tag->linkTo(['companies/search?page=' . $page->last, '<i class="icon-fast-forward"></i> Last', 'class' => 'btn btn-default']) ?>
                    <span class="help-inline"><?= $page->current ?>/<?= $page->total_pages ?></span>
                </div>
            </td>
        </tr>
    <tbody>
</table>
<?php } ?>
<?php $v26418550411incr++; } if (!$v26418550411iterated) { ?>
    No Customers are recorded
<?php } ?>
