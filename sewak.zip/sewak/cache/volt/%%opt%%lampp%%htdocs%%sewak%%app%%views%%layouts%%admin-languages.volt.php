
<?= $this->elements->getTabs() ?>

<div align="center">

    <?= $this->getContent() ?>
</div>
