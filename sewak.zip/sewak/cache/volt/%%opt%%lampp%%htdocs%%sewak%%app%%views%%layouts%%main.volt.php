<?php
$auth = $this->session->get('auth');
//$languages = Languages::find();
//print_r($languages);exit();



$sql="SELECT * 
FROM  `genba_languages` ";
//echo $sql;
$sql_execute=$this->db->query($sql);
$sql_execute->setFetchMode(Phalcon\Db::FETCH_ASSOC);
$sql_execute=$sql_execute->fetchAll();
//echo "<pre>";
//print_r($sql_execute);


?>
<nav class="navbar navbar-default navbar-inverse" role="navigation">
    <div class="container-fluid">
        <div class="navbar-header">
            <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
                <span class="sr-only">Toggle navigation</span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
            </button>
            <a class="navbar-brand" href="#">INVO</a>
        </div>
        <?= $this->elements->getMenu() ?>
        <ul class="nav navbar-toolbar navbar-right navbar-toolbar-right">
        <li class="dropdown"> <a class="dropdown-toggle" data-toggle="dropdown" href="javascript:void(0)" data-animation="scale-up"
            aria-expanded="false" role="button"> <?php  if(isset($_SESSION['lang'])) {
              $country_prefix = $_SESSION['lang'];
              // if(empty($_SESSION['lang']) && $_SESSION['lang']==''){
              //   $country_prefix = $_SESSION['lang_pre'];
              // }
              // echo $country_prefix;exit();
              $sql = "SELECT Languages.* FROM Languages WHERE country_prefix = '".$country_prefix."'";
              //echo $sql; exit();
              $languages = $this->modelsManager->executeQuery($sql)->getFirst();
              $url = $languages->flag_url;
              }
            ?>
            <?php if(isset($url)){ ?>
            <img src="<?php echo $url; ?>" width="30px" height="30px">
            <?php } else {?>
            <img src="https://genba.online/uploads/flag/English-EN.png" width="30px" height="30px">
            <?php } ?>
            
            </a>

            <ul class="dropdown-menu" role="menu">
<?php foreach($sql_execute as $k=>$v)
{
  ?>

<li role="presentation"> <a href="../admin/langSet/<?=$v['country_prefix']?>?redirect_url=<?= $this->router->getRewriteUri() ?>" role="menuitem"> <span><img src="<?= $this->url->get($v['flag_url']) ?>" width="30px" height="30px"></span> <?=$v['name']?></a> </li>

 
  <?php
}
/*if ($this->session->has("lang")) {
            // Retrieve its value
            $name = $this->session->get("lang");
            echo $name;
        }*/
?>

          </ul>
          </li>
          </ul>
    </div>
</nav>

<div class="container">
    <?= $this->flash->output() ?>
    <?= $this->getContent() ?>
    <hr class="hr-primary" /><br>
    <footer>
        <p>&copy; Company <?php echo date("Y"); ?></p>
    </footer>
</div>
