

<!-- <ul class="pager">
    <li class="previous">
        <?= $this->tag->linkTo(['invoices', '&larr; Go Back']) ?>
    </li>
    <li class="next">
        <?= $this->tag->linkTo(['invoices/new', $t->_('Create Invoice'), 'class' => 'btn btn-success']) ?>
    </li>
</ul> -->
<div class="row"><br>

<div class="col-md-10">
</div>
<div class="col-md-2">
<?= $this->tag->linkTo(['invoices/new', $t->_('Create Invoice'), 'class' => 'btn btn-primary']) ?>
</div>
</div><br>
<?= $this->getContent() ?>
<?php $v20855172841iterated = false; ?><?php $v20855172841iterator = $page->items; $v20855172841incr = 0; $v20855172841loop = new stdClass(); $v20855172841loop->self = &$v20855172841loop; $v20855172841loop->length = count($v20855172841iterator); $v20855172841loop->index = 1; $v20855172841loop->index0 = 1; $v20855172841loop->revindex = $v20855172841loop->length; $v20855172841loop->revindex0 = $v20855172841loop->length - 1; ?><?php foreach ($v20855172841iterator as $product) { ?><?php $v20855172841loop->first = ($v20855172841incr == 0); $v20855172841loop->index = $v20855172841incr + 1; $v20855172841loop->index0 = $v20855172841incr; $v20855172841loop->revindex = $v20855172841loop->length - $v20855172841incr; $v20855172841loop->revindex0 = $v20855172841loop->length - ($v20855172841incr + 1); $v20855172841loop->last = ($v20855172841incr == ($v20855172841loop->length - 1)); ?><?php $v20855172841iterated = true; ?>

    <?php if ($v20855172841loop->first) { ?>
<table class="table table-bordered table-striped" align="center">
    <thead>
        <tr>
            <th>Number</th>
            <th>Customer</th>
            <th>Contact No.</th>
            <th>Date</th>
            <th>Total</th>
            <th colspan="3">Action</th>
            
        </tr>
    </thead>
    <tbody>
    <?php } ?>
        <tr>
            <td>#WG<?= $product->id ?></td>
            <td><?= $product->cname ?></td>
            <td><?= $product->cnumber ?></td>
            <td><?= $product->create_date ?></td>
            <td>$<?= sprintf('%.2f', $product->amount) ?></td>
            <td width="7%"><?= $this->tag->linkTo(['print/index/' . $product->id, '<i class="glyphicon glyphicon-eye-open"></i> View', 'class' => 'btn btn-success']) ?></td>
            <td width="7%"><?= $this->tag->linkTo(['invoices/edit/' . $product->id, '<i class="glyphicon glyphicon-edit"></i> Edit', 'class' => 'btn btn-warning']) ?></td>
            <td width="7%"><?= $this->tag->linkTo(['invoices/delete/' . $product->id, '<i class="glyphicon glyphicon-remove"></i> Delete', 'class' => 'btn btn-danger']) ?></td>
        </tr>
    <?php if ($v20855172841loop->last) { ?>
    </tbody>
    <tbody>
        <tr>
            <td colspan="8" align="right">
                <div class="btn-group">
                    <?= $this->tag->linkTo(['invoices/index', '<i class="icon-fast-backward"></i> First', 'class' => 'btn']) ?>
                    <?= $this->tag->linkTo(['invoices/index?page=' . $page->before, '<i class="icon-step-backward"></i> Previous', 'class' => 'btn']) ?>
                    <?= $this->tag->linkTo(['invoices/index?page=' . $page->next, '<i class="icon-step-forward"></i> Next', 'class' => 'btn']) ?>
                    <?= $this->tag->linkTo(['invoices/index?page=' . $page->last, '<i class="icon-fast-forward"></i> Last', 'class' => 'btn']) ?>
                    <span class="help-inline"><?= $page->current ?> of <?= $page->total_pages ?></span>
                </div>
            </td>
        </tr>
    </tbody>
</table>
    <?php } ?>
<?php $v20855172841incr++; } if (!$v20855172841iterated) { ?>
    No invoices are recorded
<?php } ?>
