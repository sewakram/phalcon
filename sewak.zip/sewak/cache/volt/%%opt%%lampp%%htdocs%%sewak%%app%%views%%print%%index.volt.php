 
  <style>
  @import url(http://fonts.googleapis.com/css?family=Bree+Serif);
  body, h1, h2, h3, h4, h5, h6{
    font-family: 'Bree Serif', serif;
  }
  </style>


<?= $this->getContent() ?>
  <div class="container">

    <div class="row">
      <div class="col-xs-6">
        <h1>
          <a href="https://webgile.com/">
             <img src="https://webgile.com/wp-content/uploads/2015/06/cropped-new_logo.png">
            
          </a>
        </h1>
      </div>
      <div class="col-xs-6 text-right">
        <h1>INVOICE</h1>
        <h1><small>Invoice #WG<?php echo $amts->id;?></small></h1>
      </div>
    </div>

      <div class="row">
        <div class="col-xs-5">
          <div class="panel panel-default">
                  <div class="panel-heading">
                    <h4>From: <a href="#">Webgile Solutions</a></h4>
                  </div>
                  <div class="panel-body">
                    <p>
                     1st Floor, Savadia Complex,<br>
                      Above Titan Showroom,Gandhi Putla,<br>
                      Central Avenue / CA Road,<br>
                        Nagpur, Maharashtra 440002
                    </p>
                  </div>
                </div>
        </div>
        <div class="col-xs-5 col-xs-offset-2 text-right">
          <div class="panel panel-default">
                  <div class="panel-heading">
                    <h4>To : <a href="#"> <?php echo $amts->cname;?></a></h4>
                  </div>
                  <div class="panel-body">
                    <p>
                      <!-- Level 3, 48 Cambridge Street, <br>
                      Collingwood VIC 3066 <br>
                      Australia <br> -->
                      <?php echo $amts->caddress;?>
                    </p>
                  </div>
                </div>
        </div>
      </div> <!-- / end client details section -->

             <table class="table table-bordered">
        <thead>
          <tr>
            <th><h4>Product Type</h4></th>
            <th><h4>Product</h4></th>
            <th><h4>Qty</h4></th>
            <th><h4>Price</h4></th>
            <th><h4>Sub Total</h4></th>
          </tr>
        </thead>
        <tbody>
        <?php 
         $sum='';
        foreach($items as $v)
                    {
                    $sum += $v->i->total;
        ?>
          <tr>
            <td><?php echo $v->t->name; ?></td>
            <td><?php echo $v->p->name; ?></td>
            <td class="text-right"><?php echo $v->i->qty; ?></td>
             <td class="text-right"><?php echo $v->i->price; ?></td>
              <td class="text-right"><?php echo $v->i->total; ?></td>

           </tr>
           <?php } ?>
           <!-- <tr>
            <td>Template Design</td>
            <td><a href="#">Details of project here</a></td>
            <td class="text-right">10</td>
             <td class="text-right">75.00</td>
              <td class="text-right">$750.00</td>
          </tr>
          <tr>
            <td>Development</td>
            <td><a href="#">WordPress Blogging theme</a></td>
            <td class="text-right">5</td>
             <td class="text-right">50.00</td>
              <td class="text-right">$250.00</td>
          </tr>  --> 
        </tbody>
      </table>

    <div class="row text-right">
      <div class="col-xs-2 col-xs-offset-7">
        <p>
          <strong>
            Sub Total : <br>
            TAX : <br>
            Total : <br>
          </strong>
        </p>
      </div>
      <div class="col-xs-2">
        <strong>
          $<?php echo $sum;?> <br>
          CGST(<?php echo $amts->cgst;?>%):Rs.<?php echo (($sum*($amts->cgst))/100);?>&nbsp;+&nbsp;SGST(<?php echo $amts->sgst;?>%):Rs.<?php echo (($sum*($amts->sgst))/100);?> <br>
          Rs.<?php echo (($sum)+(($sum*($amts->cgst+$amts->sgst))/100));?><br>
        </strong>
      </div>
    </div>


    <div class="row">
      <div class="col-xs-5">
        <div class="panel panel-info">
        <div class="panel-heading">
          <h4>Paypal details</h4>
        </div>
        <div class="panel-body">
          <p>payment@webgile.com</p>
         <!--  <p>Bank Name</p>
          <p>SWIFT : ........</p>
          <p>Account Number : ...........</p>
          <p>IBAN : ............</p> -->
        </div>
      </div>
      </div>
      <div class="col-xs-7">
       <div class="span7">
        <div class="panel panel-info">
          <div class="panel-heading">
            <h4>Contact Details</h4>
          </div>
          <div class="panel-body">
            <p>
              Email : contact@webgile.com <br><br>
              Mobile : +911234567890 <br> <br>
              Twitter  : <a href="https://twitter.com/">@webgile</a>
            </p>
           <!--  <h4>Payment should be mabe by Bank Transfer</h4> -->
          </div>
        </div>
      </div>
      </div>
    </div>
    <div class="row" align="center">
    <button onclick="myFunction()" class="btn btn-success">Print</button>
    <a href="../../invoices/index" class="btn btn-success">Back</a>
    <br><br></div>

  </div>


<script>
function myFunction() {
  $(".btn").hide();
    print();
}
</script>

