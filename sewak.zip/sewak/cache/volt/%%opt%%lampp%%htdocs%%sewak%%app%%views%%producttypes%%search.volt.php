<?= $this->getContent() ?>

<ul class="pager">
    <li class="previous">
        <?= $this->tag->linkTo(['producttypes', '&larr; Go Back']) ?>
    </li>
    <li class="next">
        <?= $this->tag->linkTo(['producttypes/new', 'Create product types', 'class' => 'btn btn-primary']) ?>
    </li>
</ul>

<?php $v29856806001iterated = false; ?><?php $v29856806001iterator = $page->items; $v29856806001incr = 0; $v29856806001loop = new stdClass(); $v29856806001loop->self = &$v29856806001loop; $v29856806001loop->length = count($v29856806001iterator); $v29856806001loop->index = 1; $v29856806001loop->index0 = 1; $v29856806001loop->revindex = $v29856806001loop->length; $v29856806001loop->revindex0 = $v29856806001loop->length - 1; ?><?php foreach ($v29856806001iterator as $producttype) { ?><?php $v29856806001loop->first = ($v29856806001incr == 0); $v29856806001loop->index = $v29856806001incr + 1; $v29856806001loop->index0 = $v29856806001incr; $v29856806001loop->revindex = $v29856806001loop->length - $v29856806001incr; $v29856806001loop->revindex0 = $v29856806001loop->length - ($v29856806001incr + 1); $v29856806001loop->last = ($v29856806001incr == ($v29856806001loop->length - 1)); ?><?php $v29856806001iterated = true; ?>
    <?php if ($v29856806001loop->first) { ?>
<table class="table table-bordered table-striped" align="center">
    <thead>
        <tr>
            <th>Id</th>
            <th>Name</th>
            <th colspan="4">Action</th>
        </tr>
    </thead>
    <tbody>
    <?php } ?>
        <tr>
            <td><?= $producttype->id ?></td>
            <td><?= $producttype->name ?></td>
            <td width="7%"><?= $this->tag->linkTo(['producttypes/edit/' . $producttype->id, '<i class="glyphicon glyphicon-edit"></i> Edit', 'class' => 'btn btn-default']) ?></td>
            <td width="7%"><?= $this->tag->linkTo(['producttypes/delete/' . $producttype->id, '<i class="glyphicon glyphicon-remove"></i> Delete', 'class' => 'btn btn-default']) ?></td>
        </tr>
    <?php if ($v29856806001loop->last) { ?>
    </tbody>
    <tbody>
        <tr>
            <td colspan="4" align="right">
                <div class="btn-group">
                    <?= $this->tag->linkTo(['producttypes/search', '<i class="icon-fast-backward"></i> First', 'class' => 'btn']) ?>
                    <?= $this->tag->linkTo(['producttypes/search?page=' . $page->before, '<i class="icon-step-backward"></i> Previous', 'class' => 'btn']) ?>
                    <?= $this->tag->linkTo(['producttypes/search?page=' . $page->next, '<i class="icon-step-forward"></i> Next', 'class' => 'btn']) ?>
                    <?= $this->tag->linkTo(['producttypes/search?page=' . $page->last, '<i class="icon-fast-forward"></i> Last', 'class' => 'btn']) ?>
                    <span class="help-inline"><?= $page->current ?>/<?= $page->total_pages ?></span>
                </div>
            </td>
        </tr>
    <tbody>
</table>
    <?php } ?>
<?php $v29856806001incr++; } if (!$v29856806001iterated) { ?>
    No product types are recorded
<?php } ?>
