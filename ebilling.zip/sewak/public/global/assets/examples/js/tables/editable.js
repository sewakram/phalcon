/*!
 * SCS
 * Genba - Platform
 */
(function(document, window, $) {
  'use strict';

  var Site = window.Site;

  $(document).ready(function($) {
    //Site.run();
  });

  // Example editable Table
  // ----------------------
  

})(document, window, jQuery);
