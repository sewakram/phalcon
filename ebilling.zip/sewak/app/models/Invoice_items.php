<?php

use Phalcon\Mvc\Model;

class Invoice_items extends Model

{
  public $id;
  public $ptype;
  public $name;
  public $price;
  public $qty;
  public $total;
  public $invoiceid;

    public function initialize()
   {
     $this->belongsTo('invoiceid', 'Invoices', 'id', [
      'reusable' => true
    ]);
     try{
     $this->setSource("invoice_items");
   
    }
    catch(Exception $e){
      var_dump($e->getMessage());
      echo " Line=", $e->getLine(), "\n";exit();
    }
   }
}