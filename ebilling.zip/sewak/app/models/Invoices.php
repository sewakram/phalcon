<?php

use Phalcon\Mvc\Model;

class Invoices extends Model

{
  public $id;
  public $cname;
  public $cnumber;
  public $caddress;
  public $ccity;
  public $amount;
  public $cgst;
  public $sgst;
  public $create_date;
 
    public function initialize()
   {
     // $this->hasMany('id', 'invoice_items', 'invoiceid', [
     //      'foreignKey' => [
     //        'message' => 'Invoice cannot be deleted because it\'s used in invoice_items'
     //      ]
     //    ]);
     try{
     $this->setSource("invoices");
   
    }
    catch(Exception $e){
      var_dump($e->getMessage());
      echo " Line=", $e->getLine(), "\n";exit();
    }
   }
}