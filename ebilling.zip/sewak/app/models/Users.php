<?php

use Phalcon\Mvc\Model;
use Phalcon\Validation;
use Phalcon\Validation\Validator\Email as EmailValidator;
use Phalcon\Validation\Validator\Uniqueness as UniquenessValidator;

class Users extends Model
{
    public function validation()
    {
        $validator = new Validation();
        
        $validator->add(
            'email',
            new EmailValidator([
            'message' => 'Invalid email given'
        ]));
        $validator->add(
            'email',
            new UniquenessValidator([
            'message' => 'Sorry, The email was registered by another user'
        ]));
        $validator->add(
            'username',
            new UniquenessValidator([
            'message' => 'Sorry, That username is already taken'
        ]));
        
        return $this->validate($validator);
    }
    public function beforeValidationOnCreate()
    {
        
            // The user must not change its password in first login
            $this->mustChangePassword = 'N';
        

        // The account must be confirmed via e-mail
        // Only require this if emails are turned on in the config, otherwise account is automatically active
        // if ($this->getDI()->get('config')->useMail) {
        //     $this->active = 'N';
        // } else {
            $this->active = 'N';
        // }
        
        // The account is not suspended by default
        $this->suspended = 'N';

        // The account is not banned by default
        $this->banned = 'N';
        $this->profilesId = '2';

    }
    // public function initialize()
    //   {
    //     if($this->active = 'N'){
    //         'message' => 'Sorry, That username is already taken'
            
    //     }
    //   }
}
