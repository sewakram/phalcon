<?php
use Phalcon\Mvc\Model;
use Phalcon\Validation;
use Phalcon\Validation\Validator\PresenceOf;
use Phalcon\Validation\Validator\Uniqueness as UniquenessValidator;

class Languages extends Model
{
    public function initialize()
   {
     $this->setSource("genba_languages");
   }

    public function validation()
    {
        $validator = new Validation();

        $validator->add(
            "name",
            new PresenceOf(
                [
                    "message" => "Language Name is required",
                ]
            )
        );
        $validator->add(
            "code",
            new PresenceOf(
                [
                    "message" => "Language Code is required",
                ]
            )
        );
        $validator->add(
            'name',
            new UniquenessValidator([
                'model' => $this,
                'message' => 'Sorry, That Language  is already taken',
            ])
        );
        $validator->add(
            'code',
            new UniquenessValidator([
                'model' => $this,
                'message' => 'Sorry, That Language Code is already taken',
            ])
        );
       /* $validator->add(
            'flag_url',
            new UniquenessValidator([
                'model' => $this,
                'message' => 'Sorry, That Flag is already taken',
            ])
        );*/
        return $this->validate($validator);
    }
}