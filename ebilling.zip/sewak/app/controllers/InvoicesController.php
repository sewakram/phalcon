<?php
use Phalcon\Mvc\Model\Criteria;
use Phalcon\Paginator\Adapter\Model as Paginator;
use Phalcon\Http\Request;
use Phalcon\Flash;
use Phalcon\Session;
use PHPMailer\PHPMailer\PHPMailer;
use Phalcon\Mvc\Url;

/**
 * InvoicesController
 *
 * Manage operations for invoises
 */
class InvoicesController extends ControllerAdminBase
{
   private $translate;
    public function initialize()
    {
        $this->tag->setTitle('Manage your Invoices');
        parent::initialize();
        $this->translate=$this->getTranslation();
        $this->auth= $this->session->get('auth');
    }
    //list all invoices
    public function indexAction()
    {
      //phpinfo();
      
      //echo '<pre>';print_r(count($invoicef));exit;
      $numberPage = 1;
        if ($this->request->isPost()) {
            $mydata=$this->request->getPost();
               
            $query = Criteria::fromInput($this->di, "Invoices", $mydata);
            $this->persistent->searchParams = $query->getParams();
        } else {
            $numberPage = $this->request->getQuery("page", "int");
        }

        $parameters = array();
        if ($this->persistent->searchParams) {
            $parameters = $this->persistent->searchParams;
        }
        // echo '<pre>';print_r($parameters);exit();
        $auth = $this->session->get('auth');
                 
        $products = Invoices::find("userid='".$auth['id']."'");
       
        $paginator = new Paginator(array(
            "data"  => $products,
            "limit" => 10,
            "page"  => $numberPage
        ));
       if(count($paginator)!=1){
        if (count($products) == 0) {
            $this->flash->notice("The search did not find any invoice");

            return $this->dispatcher->forward(
                [
                    "controller" => "invoices",
                    "action"     => "index",
                ]
            );
        }
      }
// if($products){
//   $msg = "First line of text\nSecond line of text";
//   mail("sewakram.deshmukh@webgile.com","My subject",$msg);
// }
        $this->view->page = $paginator->getPaginate();

        $this->view->products = $products;
        }

/**
     * Deletes a product
     *
     * @param string $id
     */
    public function deleteAction($id)
    {

        $productss = Invoices::findFirstById($id);

        if (!$productss) {
         
            $this->flash->error("Invoice was not found");

            return $this->dispatcher->forward(
                [
                    "controller" => "invoices",
                    "action"     => "index",
                ]
            );

        }

        if (!$productss->delete()) { 

          
            foreach ($productss->getMessages() as $message) {
                $this->flash->error($message);
            }
            
            return $this->dispatcher->forward(
                [
                    "controller" => "invoices",
                    "action"     => "index",
                ]
            );
        }else{
           if($productss->id){
            $prod = Invoice_items::find("invoiceid='".$productss->id."'");
            for ($i=0; $i <count($prod) ; $i++) { 

             if (!$prod->delete()) { 

          
            foreach ($prod->getMessages() as $message) {
                $this->flash->error($message);
            }
            
            return $this->dispatcher->forward(
                [
                    "controller" => "invoices",
                    "action"     => "index",
                ]
            );
          }
       }
            
           }
           $this->flash->success("Invoice was deleted");

            return $this->dispatcher->forward(
                [
                    "controller" => "invoices",
                    "action"     => "index",
                ]
            );
          
        }

        
  }

    //edit invoice
         /**
     * Edits a product based on its id
     */
    public function editAction($id=null)
    {
        $prodtype = ProductTypes::find();
        $request = new Request();

       if ($request->isAjax() == true) {
       $prod_id = $this->request->get('ptype_id');
       $prod = false;
       if($this->request->get('data_type')=='products'){
        $prod = Products::find("id='".$prod_id."'");
       }else{
        $prod = Products::find("product_types_id='".$prod_id."'"); 
       }
       return json_encode(array('status'=>true,'prod'=>$prod));
     }
        if (!$this->request->isPost()) {
            $qry="SELECT t.*,i.*,p.* FROM ProductTypes as t,Invoice_items as i ,Products as p where t.id=i.ptype AND p.id=i.name AND i.invoiceid='".$id."'";
            
              $items = $this->modelsManager->executeQuery($qry);
              $products = Products::find();
                
             $this->view->prodtype = $prodtype;
             $this->view->items = $items;
             $this->view->products = $products;
                           
            $product = Invoices::findFirstById($id);
            

            if (!$product) {
                $this->flash->error("Invoice was not found");

                return $this->dispatcher->forward(
                    [
                        "controller" => "invoices",
                        "action"     => "index",
                    ]
                );
            }
            //$this->view->form = new InvoicesForm($product,array('edit' => true));
            try{
              $this->view->form = new InvoicesForm($product,['translate'=>$this->translate,'edit'=>true]);//edit
            }catch(Exception $e){
              var_dump($e->getMessage());exit();
            }
            
            $this->view->id = $product->id;
            $this->view->amount = $product->amount;
            $this->view->product = $product;
               
           

         }
    }


    /**
     * update a new invoice
     */
    public function updateAction($id=null)
    {   
        
        if (!$this->request->isPost()) {

            return $this->dispatcher->forward(
                [
                    "controller" => "invoices",
                    "action"     => "index",
                ]
            );
            
        }
      
        $invoice = new Invoices();
        //$id = $this->request->get('id');
        
        $mydata = $_POST['mydata'];
        
        $userdata=$mydata['user'];
        $invoice->id = $userdata['id'];
        $invoice->cid = $userdata['cid'];
        $invoice->cgst = $userdata['cgst'];
        $invoice->sgst = $userdata['sgst'];
        $invoice->cname = $userdata['cname'];
        $invoice->cnumber = $userdata['cnumber'];
        $invoice->caddress = $userdata['caddress'];
        $invoice->ccity = $userdata['ccity'];
        $invoice->amount = $userdata['gtotal'];
        $invoice->create_date = date('Y/m/d H:i:s');
          
         $data = $this->request->getPost();
         $invoicef = Invoices::findFirstById($userdata['id']);
        //echo '<pre>';print_r(count($invoicef));exit;
         if (!$invoicef) {
                $this->flash->error("Invoice was not found");

                return $this->dispatcher->forward(
                    [
                        "controller" => "invoices",
                        "action"     => "index",
                    ]
                );
            }
        $form = new InvoicesForm(null,['translate'=>$this->translate,'edit'=>true]);
        if ($form->isValid($data, $invoice)) {
            foreach ($form->getMessages() as $message) {
                $this->flash->error($message);

            } 
      }

        $invoice->userid=$this->auth['id'];
        if ($invoice->save() == false) {
            foreach ($invoice->getMessages() as $message) {
                $this->flash->error($message);

            }

            return $this->dispatcher->forward(
                [
                    "controller" => "invoices",
                    "action"     => "new",
                ]
            );

        }
        else{
          $lastid = $invoice->id;
        
           
           
          $status = false;
       //echo "<pre>";$lastid;exit();
          // if(!empty($lastid)){
          
         $pdata=$mydata['products'];
         //echo '<pre>';print_r($pdata);exit();
         $cnt=count($pdata);
         for($i=0;$i<$cnt;$i++){
         //foreach ($userdata->$key as $data){
         // echo $pdata[$i]['id'];exit;
          //$items = new Invoice_items();
          $items = Invoice_items::findFirstById($pdata[$i]['id']);

          //echo $items->id; exit();
          if (!$items) {
              $items = new Invoice_items();  
          }
          $items->ptype=$pdata[$i]['producttype'];
          $items->name=$pdata[$i]['products'];
          $items->price=$pdata[$i]['productprice'];
          $items->qty=$pdata[$i]['productqnty'];
          $items->total=$pdata[$i]['subt'];
          $items->invoiceid=$lastid;
          //echo '<pre>';print_r($items->total);exit();
          if ($items->save() == false) {
            foreach ($items->getMessages() as $message) {
                $this->flash->error($message);
                 return $this->dispatcher->forward(
                [
                    "controller" => "invoices",
                    "action"     => "new",
                ]
            );
                 
            }
           
        }
        else{  
          $status = true;
        }
        
      }
      if($status){
            $qry2="SELECT i.*,c.* FROM Invoices as i ,Companies as c where c.id=i.cid AND i.id='".$lastid."'";
            
            $customers = $this->modelsManager->executeQuery($qry2);
            foreach ($customers as $customer) 
              $auth = $this->session->get('auth');

              //echo '<pre>';print_r($auth['email']);exit;
            $mail = new PHPMailer;
            $mail->isSMTP();
            $mail->Host = "smtp.gmail.com";
            $mail->Port = 587; // 465 is for ssl
            //Whether to use SMTP authentication
            $mail->SMTPAuth = true;
            //Username to use for SMTP authentication
            $mail->Username = 'testtwg12@gmail.com';
            //Password to use for SMTP authentication
            $mail->Password = 'Wg@12345';
            //$mail->SMTPDebug  = 1;
            $mail->setFrom($auth['email'], $auth['name']); 
            $mail->addAddress($customer->c->email,$customer->c->name);
            $mail->Subject = 'Invoice';
            
            
            $qry="SELECT t.*,i.*,p.* FROM ProductTypes as t,Invoice_items as i ,Products as p where t.id=i.ptype AND p.id=i.name AND i.invoiceid='".$lastid."'";
            
              $itemss = $this->modelsManager->executeQuery($qry);
              $amts = Invoices::findFirstById($lastid);
              $this->view->itemss = $itemss;
              $this->view->amts = $amts;
              //$msg=include __DIR__ . "/msg.php";
            $msg='<html>
          <head>
           <style>
           table.blueTable {
  font-family: Tahoma, Geneva, sans-serif;
  border: 1px solid #082030;
  background-color: #EEEEEE;
  width: 100%;
  text-align: left;
}
table.blueTable td, table.blueTable th {
  border: 1px solid #AAAAAA;
  padding: 0px 0px;
}
table.blueTable tbody td {
  font-size: 13px;
}
table.blueTable thead {
  background: #D5EDF6;
  background: -moz-linear-gradient(top, #dff1f8 0%, #d9eef7 66%, #D5EDF6 100%);
  background: -webkit-linear-gradient(top, #dff1f8 0%, #d9eef7 66%, #D5EDF6 100%);
  background: linear-gradient(to bottom, #dff1f8 0%, #d9eef7 66%, #D5EDF6 100%);
  border-bottom: 2px solid #444444;
}
table.blueTable thead th {
  font-size: 15px;
  font-weight: bold;
  color: #040408;
}



           </style>

          </head>
         <body>
         <div class="container" align="center" width="800px">

          <div class="row">
            <div class="col-xs-6">
              <h1>
                <a href="https://webgile.com/">
                   <img src="https://webgile.com/wp-content/uploads/2015/06/cropped-new_logo.png">
                 </a>
              </h1>
            </div>
            <div class="col-xs-6 text-right">
              <h1>INVOICE</h1>
              <h1><small>Invoice No. #WG'.$amts->id.'</small></h1>
            </div>
          </div>
          <table>
          <tr><td width="400px"><!--gggggggggg-->
<table class="blueTable" style="border-radious:6px;width:400px;height:190px;">
        <thead>
          <tr>
            <th>
            <h4 style="font-size:20px">From: <a>Webgile Solutions</a></h4>
           </th>
           </tr>
        </thead>
        <tbody>
          <tr>
            <td>
            
            <p style="font-size:14px">
                     1st Floor, Savadia Complex,<br>
                      Above Titan Showroom,Gandhi Putla,<br>
                      Central Avenue / CA Road,<br>
                        Nagpur, Maharashtra 440002
             </p>
            </td>
           </tr>
        </tbody>
        </table>
          </td><!--gggggggggg-->
         
        <!--<td style="padding-right:545px;"></td>-->
        <td width="400px" style="vertical-align:top"><!--gggggggggg-->
        <table class="blueTable" style="border-radious:3px;width:400px;height:190px;">
        <thead>
          <tr>
            
            <th>
            <h4 style="font-size:20px">To : <a href="#">'.$amts->cname.'</a>
            </h4>
           </th>
            
          </tr>
        </thead>
        <tbody>
          <tr>
            
            <td>
            <p style="font-size:14px">'.$amts->caddress.'</p>
            </td>
            
          </tr>
        </tbody>
        </table>
        </td><!--gggggggggg-->

        </tr>
        </table>
          
       <table class="blueTable" style="border-radious:3px;width:800px;">
        <thead>
          <tr>
            <th><h4>Product Type</h4></th>
            <th><h4>Product</h4></th>
            <th><h4>Qty</h4></th>
            <th><h4>Price</h4></th>
            <th><h4>Sub Total</h4></th>
          </tr>
        </thead>
        <tbody>';
        $sum='';
        foreach($itemss as $v)
                    {
                    $sum += $v->i->total;
          $msg.='<tr>
            <td>'.$v->t->name.'</td>
            <td>'.$v->p->name.'</td>
            <td class="text-right">'.$v->i->qty.'</td>
             <td class="text-right">'.$v->i->price.'</td>
              <td class="text-right">'.$v->i->total.'</td>
          </tr>';
        }
          
          $msg.='</tbody>
          <thead>
          <tr>
            <th colspan="5">
              <div>
                <div align="right" style="font-size:14px">
                  <p>
                    <strong>
                      Sub Total : '.$sum.'<br>
                      TAX : CGST('.$amts->cgst.'%):Rs.'.(($sum*($amts->cgst))/100).'&nbsp;+&nbsp;SGST('.$amts->sgst.'%):Rs.'.(($sum*($amts->sgst))/100).'<br>
                      Total : Rs.'.(($sum)+(($sum*($amts->cgst+$amts->sgst))/100)).'<br>
                    </strong>
                  </p>
                </div>
              </div>
            </th>
            
          </tr>
        </thead>
      </table>
<table>
          <tr><td width="400px;"><!--gggggggggg-->
<table class="blueTable" style="border-radious:3px;vertical-align:top;width:400px;height:196px;">
        <thead>
          <tr>
            <th>
            <h4 style="font-size:20px">Paypal details</h4>
            
           </th>
           </tr>
        </thead>
        <tbody>
          <tr>
            <td>
            
          <p style="font-size:14px">payment@webgile.com</p>
          <!-- <p>Bank Name: .........</p>
          <p>SWIFT : ........</p>
          <p>Account Number : ...........</p>
          <p>IBAN : ............</p> -->
            </td>
           </tr>
        </tbody>
        </table>
          </td><!--gggggggggg-->
         
        
        <td width="400px"><!--gggggggggg-->
        <table class="blueTable" style="border-radious:3px;width:400px;height:190px;">
        <thead>
          <tr>
            
            <th>
            <h4 style="font-size:20px">Contact Details
            </h4>
            
           </th>
            
          </tr>
        </thead>
        <tbody>
          <tr>
            
            <td>
            <p style="font-size:14px">
              Email : contact@webgile.com <br><br>
              Mobile : +911234567890 <br> <br>
              Twitter  : <a href="https://twitter.com/">@webgile</a>
            </p>
            </td>
            
          </tr>
        </tbody>
        </table>
        </td><!--gggggggggg-->

        </tr>
        </table>
  


          </div>
          </body>
          </html>';
            $mail->msgHTML($msg);
              if (!$mail->send()) {
              echo "Mailer Error: " . $mail->ErrorInfo;
              }
        $this->flash->success('Invoice updated success');
        return json_encode(array('status'=>true));
        }
          
          // }
         
      }
    }

    //create invoice
    public function newAction($id=null)
    {
     try{
          
         $this->view->form = new InvoicesForm(null,['translate'=>$this->translate]);
        
      }catch(Exception $e){
        var_dump($e->getMessage());exit();
      }
      $prodtype = ProductTypes::find("userid='".$this->auth['id']."'");
      
       if(count($prodtype)>0)
    {
      $this->view->prodtype = $prodtype;
    }

    $request = new Request();

       if ($request->isAjax() == true) {
       $prod_id = $this->request->get('ptype_id');
       $prod = false;
       if($this->request->get('data_type')=='products'){
        $prod = Products::find("id='".$prod_id."'");
       }else{
        $prod = Products::find("product_types_id='".$prod_id."'"); 
       }
       return json_encode(array('status'=>true,'prod'=>$prod));
     }
        
  }

     public function findcustomersAction($id=null){
       $this->view->disable();
       $request = new Request();
       if ($request->isAjax() == true) {
       $cust_id = $this->request->get('customer_id');
       //var_dump($cust_id);exit;
       $fomdata = Companies::findFirst("id='".$cust_id."'");
       return json_encode(array('fomdata'=>$fomdata));

      }

      }



/**
     * Creates a new invoice
     */
    public function createAction()
    {   

        if (!$this->request->isPost()) {

            return $this->dispatcher->forward(
                [
                    "controller" => "invoices",
                    "action"     => "index",
                ]
            );
        }

        $form = new InvoicesForm(null,['translate'=>$this->translate]);
        $invoice = new Invoices();
       
        $mydata = $_POST['mydata'];
        //echo '<pre>';print_r($mydata);
        $userdata=$mydata['user'];
        $invoice->cid = $userdata['cid'];
        $invoice->cgst = $userdata['cgst'];
        $invoice->sgst = $userdata['sgst'];
        $invoice->cname = $userdata['cname'];
        $invoice->cnumber = $userdata['cnumber'];
        $invoice->caddress = $userdata['caddress'];
        $invoice->ccity = $userdata['ccity'];
        $invoice->amount = $userdata['gtotal'];
          
         $data = $this->request->getPost();
         
        if ($form->isValid($data, $invoice)) {
            foreach ($form->getMessages() as $message) {
                $this->flash->error($message);

            } 

        }
        $invoice->userid=$this->auth['id'];
        if ($invoice->save() == false) {
            foreach ($invoice->getMessages() as $message) {
                $this->flash->error($message);

            }

            return $this->dispatcher->forward(
                [
                    "controller" => "invoices",
                    "action"     => "new",
                ]
            );

        }
        else{
          $lastid = $invoice->id;

          $status = false;
       //echo "<pre>";var_dump($lastid);exit();
          if(!empty($lastid)){
          
         $userdata=$mydata['products'];
         //echo '<pre>';print_r($userdata);exit();
         $cnt=count($userdata);
         for($i=0;$i<$cnt;$i++){
         //foreach ($userdata->$key as $data){
          $items = new Invoice_items();
          $items->ptype=$userdata[$i]['producttype'];
          $items->name=$userdata[$i]['products'];
          $items->price=$userdata[$i]['productprice'];
          $items->qty=$userdata[$i]['productqnty'];
          $items->total=$userdata[$i]['subt'];
          $items->invoiceid=$lastid;

          if ($items->create() == false) {
            foreach ($invoice->getMessages() as $message) {
                $this->flash->error($message);
                 
            }
            return $this->dispatcher->forward(
                [
                    "controller" => "invoices",
                    "action"     => "new",
                ]
            );
        }else{
          $products = Products::findFirstById($userdata[$i]['products']);
          $stocks=$userdata[$i]['stock']-$userdata[$i]['productqnty'];
          $products->qty=$stocks;
          if ($products->save() == false) {
            foreach ($products->getMessages() as $message) {
                $this->flash->error($message);
                 return $this->dispatcher->forward(
                [
                    "controller" => "invoices",
                    "action"     => "new",
                ]
            );
                 
            }
          }
          $status = true;
        }
        
      }
      if($status){
            $qry2="SELECT i.*,c.* FROM Invoices as i ,Companies as c where c.id=i.cid AND i.id='".$lastid."'";
            
            $customers = $this->modelsManager->executeQuery($qry2);
            foreach ($customers as $customer) 
              $auth = $this->session->get('auth');
            $mail = new PHPMailer;
            $mail->isSMTP();
            $mail->Host = "smtp.gmail.com";
            $mail->Port = 587; // 465 is for ssl
            //Whether to use SMTP authentication
            $mail->SMTPAuth = true;
            //Username to use for SMTP authentication
            $mail->Username = 'testtwg12@gmail.com';
            //Password to use for SMTP authentication
            $mail->Password = 'Wg@12345';
            //$mail->SMTPDebug  = 1;
            $mail->setFrom($auth['email'], $auth['name']); 
            $mail->addAddress($customer->c->email,$customer->c->name);
            $mail->Subject = 'INVOICE';
            //$url = new Url();
            //$url->setBaseUri('http://localhost/sewak/print/index/');
            //$homepage = file_get_contents('http://www.example.com/');
           //echo $content=$url->getBaseUri().$lastid;
            //$mail->msgHTML(file_get_contents($content), __DIR__);
            //$mail->Body = '';
            
            $qry="SELECT t.*,i.*,p.* FROM ProductTypes as t,Invoice_items as i ,Products as p where t.id=i.ptype AND p.id=i.name AND i.invoiceid='".$lastid."'";
            
              $itemss = $this->modelsManager->executeQuery($qry);
              $amts = Invoices::findFirstById($lastid);
              $this->view->itemss = $itemss;
              $this->view->amts = $amts;
              //$msg=include __DIR__ . "/msg.php";
            $msg='<html>
          <head>
           <style>
           table.blueTable {
  font-family: Tahoma, Geneva, sans-serif;
  border: 1px solid #082030;
  background-color: #EEEEEE;
  width: 100%;
  text-align: left;
}
table.blueTable td, table.blueTable th {
  border: 1px solid #AAAAAA;
  padding: 0px 0px;
}
table.blueTable tbody td {
  font-size: 13px;
}
table.blueTable thead {
  background: #D5EDF6;
  background: -moz-linear-gradient(top, #dff1f8 0%, #d9eef7 66%, #D5EDF6 100%);
  background: -webkit-linear-gradient(top, #dff1f8 0%, #d9eef7 66%, #D5EDF6 100%);
  background: linear-gradient(to bottom, #dff1f8 0%, #d9eef7 66%, #D5EDF6 100%);
  border-bottom: 2px solid #444444;
}
table.blueTable thead th {
  font-size: 15px;
  font-weight: bold;
  color: #040408;
}



           </style>

          </head>
         <body>
         <div class="container" align="center" width="800px">

          <div class="row">
            <div class="col-xs-6">
              <h1>
                <a href="https://webgile.com/">
                   <img src="https://webgile.com/wp-content/uploads/2015/06/cropped-new_logo.png">
                 </a>
              </h1>
            </div>
            <div class="col-xs-6 text-right">
              <h1>INVOICE</h1>
              <h1><small>Invoice No. #WG'.$amts->id.'</small></h1>
            </div>
          </div>
          <table>
          <tr><td width="400px"><!--gggggggggg-->
<table class="blueTable" style="border-radious:6px;width:400px;height:190px;">
        <thead>
          <tr>
            <th>
            <h4 style="font-size:20px">From: <a>Webgile Solutions</a></h4>
           </th>
           </tr>
        </thead>
        <tbody>
          <tr>
            <td>
            
            <p style="font-size:14px">
                     1st Floor, Savadia Complex,<br>
                      Above Titan Showroom,Gandhi Putla,<br>
                      Central Avenue / CA Road,<br>
                        Nagpur, Maharashtra 440002
             </p>
            </td>
           </tr>
        </tbody>
        </table>
          </td><!--gggggggggg-->
         
        <!--<td style="padding-right:545px;"></td>-->
        <td width="400px" style="vertical-align:top"><!--gggggggggg-->
        <table class="blueTable" style="border-radious:3px;width:400px;height:190px;">
        <thead>
          <tr>
            
            <th>
            <h4 style="font-size:20px">To : <a href="#">'.$amts->cname.'</a>
            </h4>
           </th>
            
          </tr>
        </thead>
        <tbody>
          <tr>
            
            <td>
            <p style="font-size:14px">'.$amts->caddress.'</p>
            </td>
            
          </tr>
        </tbody>
        </table>
        </td><!--gggggggggg-->

        </tr>
        </table>
          
       <table class="blueTable" style="border-radious:3px;width:800px;">
        <thead>
          <tr>
            <th><h4>Product Type</h4></th>
            <th><h4>Product</h4></th>
            <th><h4>Qty</h4></th>
            <th><h4>Price</h4></th>
            <th><h4>Sub Total</h4></th>
          </tr>
        </thead>
        <tbody>';
        $sum='';
        foreach($itemss as $v)
                    {
                    $sum += $v->i->total;
          $msg.='<tr>
            <td>'.$v->t->name.'</td>
            <td>'.$v->p->name.'</td>
            <td class="text-right">'.$v->i->qty.'</td>
             <td class="text-right">'.$v->i->price.'</td>
              <td class="text-right">'.$v->i->total.'</td>
          </tr>';
        }
          
          $msg.='</tbody>
          <thead>
          <tr>
            <th colspan="5">
              <div>
                <div align="right" style="font-size:14px">
                  <p>
                    <strong>
                      Sub Total : '.$sum.'<br>
                      TAX : CGST('.$amts->cgst.'%):Rs.'.(($sum*($amts->cgst))/100).'&nbsp;+&nbsp;SGST('.$amts->sgst.'%):Rs.'.(($sum*($amts->sgst))/100).'<br>
                      Total : Rs.'.(($sum)+(($sum*($amts->cgst+$amts->sgst))/100)).'<br>
                    </strong>
                  </p>
                </div>
              </div>
            </th>
            
          </tr>
        </thead>
      </table>
<table>
          <tr><td width="400px;"><!--gggggggggg-->
<table class="blueTable" style="border-radious:3px;vertical-align:top;width:400px;height:196px;">
        <thead>
          <tr>
            <th>
            <h4 style="font-size:20px">Paypal details</h4>
            
           </th>
           </tr>
        </thead>
        <tbody>
          <tr>
            <td>
            
          <p style="font-size:14px">payment@webgile.com</p>
          <!-- <p>Bank Name: .........</p>
          <p>SWIFT : ........</p>
          <p>Account Number : ...........</p>
          <p>IBAN : ............</p> -->
            </td>
           </tr>
        </tbody>
        </table>
          </td><!--gggggggggg-->
         
        
        <td width="400px"><!--gggggggggg-->
        <table class="blueTable" style="border-radious:3px;width:400px;height:190px;">
        <thead>
          <tr>
            
            <th>
            <h4 style="font-size:20px">Contact Details
            </h4>
            
           </th>
            
          </tr>
        </thead>
        <tbody>
          <tr>
            
            <td>
            <p style="font-size:14px">
              Email : contact@webgile.com <br><br>
              Mobile : +911234567890 <br> <br>
              Twitter  : <a href="https://twitter.com/">@webgile</a>
            </p>
            </td>
            
          </tr>
        </tbody>
        </table>
        </td><!--gggggggggg-->

        </tr>
        </table>
  


          </div>
          </body>
          </html>';
            $mail->msgHTML($msg);
              if (!$mail->send()) {
              echo "Mailer Error: " . $mail->ErrorInfo;
              }
              $this->flash->success('Invoice created success');
               return json_encode(array('status'=>true));
              return $this->dispatcher->forward(
                [
                    "controller" => "invoices",
                    
                ]
            );
         }
          
          }
         
      }
    }


   
    /**
     * Edit the active user profile
     *
     */
    public function profileAction()
    {
        //Get session info
        $auth = $this->session->get('auth');

        //Query the active user
        $user = Users::findFirst($auth['id']);
        if ($user == false) {
            return $this->dispatcher->forward(
                [
                    "controller" => "index",
                    "action"     => "index",
                ]
            );
        }

        if (!$this->request->isPost()) {
            $this->tag->setDefault('name', $user->name);
            $this->tag->setDefault('email', $user->email);
        } else {

            $name = $this->request->getPost('name', ['string', 'striptags']);
            $email = $this->request->getPost('email', 'email');

            $user->name = $name;
            $user->email = $email;
            if ($user->save() == false) {
                foreach ($user->getMessages() as $message) {
                    $this->flash->error((string) $message);
                }
            } else {
                $this->flash->success('Your profile information was updated successfully');
            }
        }
    }
}
