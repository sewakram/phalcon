<?php
use Phalcon\Mvc\Controller;   
use Phalcon\Translate\Adapter\NativeArray;
use Phalcon\Mvc\Dispatcher;

class ControllerBase extends Controller
{	protected $t;
    protected function initialize()
    {
        //echo 'hi'; exit;
        $this->tag->prependTitle('INVO | ');
        $this->view->setTemplateAfter('main');
        $this->t=$this->getTranslation();
        $this->view->t=$this->t;
    }
	protected function getTranslation()
    {
        if(!$this->session->has('lang')){
          $this->session->set('lang','es');
          $lang = Languages::findFirst("country_prefix='es'");
          $this->session->set('lang_code',$lang->code);
        }
        $language=$this->session->get('lang');
        $languages_sql="SELECT frontend from LanguagesString,Languages  WHERE Languages.id=LanguagesString.languages_id AND Languages.country_prefix='".$language."'";
      
        $lang_trans_string = $this->modelsManager->executeQuery($languages_sql);

        if($lang_trans_string[0])
        {
            $messages=json_decode($lang_trans_string[0]->frontend,true);
      
        }
        else
        {    
            $messages=array();
      
        }
        return new NativeArray(
            array(
                "content" => $messages
            )
        );
    }

 }