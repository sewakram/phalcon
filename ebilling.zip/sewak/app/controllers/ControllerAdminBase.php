<?php
use Phalcon\Mvc\Controller;
use Phalcon\Translate\Adapter\NativeArray;

class ControllerAdminBase extends Controller
{
    protected $t;
    protected function initialize()
    {
        $this->tag->appendTitle(' | Invo');
        $this->view->setTemplateAfter('main');
        $this->t=$this->getTranslation();
        $this->view->t=$this->t;
    }
    protected function forward($uri)
    {
        $uriParts = explode('/', $uri);
        $params = array_slice($uriParts, 2);
    	return $this->dispatcher->forward(
    		array(
    			'controller' => $uriParts[0],
    			'action' => $uriParts[1],
                'params' => $params
    		)
    	);
    }
      public function getFrontendTranslation($langCode){
            try{
                  $app_type='frontend';
                  if($langCode){
                        $languages_sql="SELECT $app_type,country_prefix from LanguagesString,Languages  WHERE Languages.id=LanguagesString.languages_id AND Languages.country_prefix='".$langCode."'";
                  }else{
                        $languages_sql="SELECT $app_type,country_prefix from LanguagesString,Languages  WHERE Languages.id=LanguagesString.languages_id AND Languages.country_prefix='es'";
                  }
                  $lang_trans_string = $this->modelsManager->executeQuery($languages_sql);
                  foreach ($lang_trans_string as $key => $value) {
                        $lang_string = json_decode($value->$app_type, true);
                  }
                  return $lang_string = (array)$lang_string;
                  /*$returnString=($lang_string[$string]) ? $lang_string[$string] : $string;
                  return $returnString;*/
                  exit();
            }catch(Exception $err){
                  print_r($err);
                  exit();
            }
      }
    protected function getTranslation()
    {
      
      // echo '<pre>';
      // print_r($_SESSION); exit;
      //exit();
        $language=($this->session->get('lang')) ? $this->session->get('lang'):$this->request->getBestLanguage();
         //echo $this->session->get('lang_pre'); exit('ji');
        if($this->session->has('country_session'))
        {
            $country_id = $this->session->get('country_session');
            $this->setTimezone($country_id);
        }else{
            date_default_timezone_set('Asia/Kolkata');
        }
        $language=explode("-",$language);
        $language=$language[0];
        //echo $language;exit();
		  $this->session->set("lang_pre",$language);
        $languages_sql="SELECT backend from LanguagesString,Languages  WHERE Languages.id=LanguagesString.languages_id AND Languages.country_prefix='".$language."'";
        $lang_trans_string = $this->modelsManager->executeQuery($languages_sql);

		// echo "<pre>";
		// print_r($lang_trans_string[0]);
		// die;
        if($lang_trans_string[0])
            $messages=json_decode($lang_trans_string[0]->backend,true);
        else
            $messages=array();

          // echo '<pre>';print_r($messages); exit();
        //require_once APP_PATH.'app/messages/en.php';
        return new NativeArray(
            array(
                "content" => $messages
            )
        );
    }
	protected function setTimezone($country_id)
    {
       /* $url=$this->config->application->base_url;
        $str = file_get_contents($url."public/country_code.json");
        $json = json_decode($str, true);*/
        $country = Countries::findFirst($country_id);
        $countryname = $country->name;
        $timezone = DateTimeZone::listIdentifiers(DateTimeZone::PER_COUNTRY, $country->iso_code);
        date_default_timezone_set($timezone[0]);
    }
	public function _getTemplate($name)
	{
		 $this->view->setRenderLevel(\Phalcon\Mvc\View::LEVEL_ACTION_VIEW);
		 $template = $this->view->getRender('emailTemplates', $name, null, function($view) {
		 $view->setRenderLevel(Phalcon\Mvc\View::LEVEL_MAIN_LAYOUT);
		 $view->setRenderLevel(Phalcon\Mvc\View::LEVEL_ACTION_VIEW);
		 });
		 $this->view->disable();
		// var_dump($template);
		 return $template;
	}
}
