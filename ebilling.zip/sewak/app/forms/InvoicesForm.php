<?php

use Phalcon\Forms\Form;
use Phalcon\Forms\Element\Select;
use Phalcon\Forms\Element\Text;
use Phalcon\Forms\Element\Hidden;
use Phalcon\Validation\Validator\PresenceOf;
use Phalcon\Validation\Validator\Email;

class InvoicesForm extends Form
{
    /**
     * Initialize the invoices form
     */
    // $this->view->form = new InvoicesForm($this->translate,null);//new
    // $this->view->form = new InvoicesForm($product,array('edit' => true));//edit
    private $translate;
    public function initialize($entity = null,$options =[])
    {   
        $this->auth= $this->session->get('auth');
        if(isset($options['translate'])){
            $this->translate = $options['translate'];
        }
        if (!isset($options['edit'])) {
            $element = new Text("id");
            $this->add($element->setLabel("Id"));
        } else {
            $this->add(new Hidden("id"));
        }

        $customer = new Select('id', Companies::find("userid='".$this->auth['id']."'"), [
            'using'      => ['id', 'name'],
            'useEmpty'   => true,
            'emptyText'  => '...',
            'emptyValue' => ''
        ]);
        $customer->setLabel($this->translate->_('Customer'));
        $new = new Select('cid', Invoices::find(), [
            'using'      => ['cid', 'cname'],
            'useEmpty'   => true,
            'emptyText'  => '...',
            'emptyValue' => ''
        ]);
        $new->setLabel($this->translate->_('Customer'));
        if (!isset($options['edit'])) {
        $this->add($customer);
    } else {

        $this->add($new);
    }
        // 
        $name = new Text("cname");
        $name->setLabel($this->translate->_("Name"));
        $name->setFilters(['striptags', 'string']);
        $name->addValidators([
            new PresenceOf([
                'message' => 'Name is required'
            ])
        ]);
        $this->add($name);

        $telephone = new Text("cnumber");
        $telephone->setLabel($this->translate->_("Telephone"));
        $telephone->setFilters(['striptags', 'string']);
        $telephone->addValidators([
            new PresenceOf([
                'message' => 'Telephone is required'
            ])
        ]);
        $this->add($telephone);

        $address = new Text("caddress");
        $address->setLabel($this->translate->_("address"));
        $address->setFilters(['striptags', 'string']);
        $address->addValidators([
            new PresenceOf([
                'message' => 'Address is required'
            ])
        ]);
        $this->add($address);

        $city = new Text("ccity");
        $city->setLabel($this->translate->_("city"));
        $city->setFilters(['striptags', 'string']);
        $city->addValidators([
            new PresenceOf([
                'message' => 'City is required'
            ])
        ]);
        $this->add($city);
    }
}
