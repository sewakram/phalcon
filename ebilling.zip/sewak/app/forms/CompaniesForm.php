<?php

use Phalcon\Forms\Form;
use Phalcon\Forms\Element\Text;
use Phalcon\Forms\Element\Hidden;
use Phalcon\Validation\Validator\PresenceOf;
use Phalcon\Validation\Validator\Email;

class CompaniesForm extends Form
{
    /**
     * Initialize the companies form
     */
    private $translate;
    public function initialize($entity = null, $options = array())
    {   
         if(isset($options['translate'])){
            $this->translate = $options['translate'];
        }
        //echo '<pre>';print_r($options);exit;
        //echo $options['edit'];exit;
        if (!isset($options['edit'])) {
            $element = new Text("id");
            $this->add($element->setLabel($this->translate->_('Id')));
        } else {
            $this->add(new Hidden("id"));
        }

        $name = new Text("name");
        // $name->setLabel('Name');
        $name->setLabel($this->translate->_('Name'));
        $name->setFilters(['striptags', 'string']);
        $name->addValidators([
            new PresenceOf([
                'message' => 'Name is required'
            ])
        ]);
        $this->add($name);

        $telephone = new Text("telephone");
        $telephone->setLabel($this->translate->_('Telephone'));
        $telephone->setFilters(['striptags', 'string']);
        $telephone->addValidators([
            new PresenceOf([
                'message' => 'Telephone is required'
            ])
        ]);
        $this->add($telephone);

        $address = new Text("address");
        $address->setLabel($this->translate->_('address'));
        $address->setFilters(['striptags', 'string']);
        $address->addValidators([
            new PresenceOf([
                'message' => 'Address is required'
            ])
        ]);
        $this->add($address);

        $city = new Text("city");
        $city->setLabel($this->translate->_('city'));
        $city->setFilters(['striptags', 'string']);
        $city->addValidators([
            new PresenceOf([
                'message' => 'City is required'
            ])
        ]);
        $this->add($city);
        $email = new Text("email");
        $email->setLabel($this->translate->_('email'));
        //$email->setFilters('email');
        
        $this->add($email);
    }
}
