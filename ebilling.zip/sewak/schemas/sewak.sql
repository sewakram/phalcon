-- phpMyAdmin SQL Dump
-- version 4.5.4.1deb2ubuntu2
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Mar 31, 2018 at 01:09 PM
-- Server version: 5.7.21-0ubuntu0.16.04.1
-- PHP Version: 7.0.27-1+ubuntu16.04.1+deb.sury.org+1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `sewak`
--

-- --------------------------------------------------------

--
-- Table structure for table `companies`
--

CREATE TABLE `companies` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(70) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `telephone` varchar(30) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `address` varchar(40) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `city` varchar(40) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `creat_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `email` varchar(70) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `userid` int(70) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `companies`
--

INSERT INTO `companies` (`id`, `name`, `telephone`, `address`, `city`, `creat_date`, `email`, `userid`) VALUES
(1, 'Acme', '31566564', 'Address', 'nagpur', '2018-02-09 04:36:00', 'acme@gmail.com', 22),
(2, 'Acme Inc', '+44 564612345', 'Guildhall, PO Box 270, London', 'London', '2018-02-09 04:36:06', 'acme@gmail.com', 22),
(3, 'ramdeshmukh', '1234567689', 'ramtek', 'nagpur', '2018-02-03 11:10:49', 'sewakdeshmukh19@gmail.com', 1),
(4, 'ganesh', '12345665432', 'ram nagar,nagpur,maharashtra,india', 'nagpur', '2018-02-03 05:01:51', 'ganesh@gmail.com', 1),
(7, 'rakeshcustomer', '1234567890', 'ramnager,nagpur', 'nagpur', '2018-02-03 11:25:05', 'rakeshcustomer@gmail.com', 5),
(8, 'test', '424234234342', 'test address', 'test city', '2018-02-09 07:15:36', '', 22);

-- --------------------------------------------------------

--
-- Table structure for table `contact`
--

CREATE TABLE `contact` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(70) COLLATE utf8_unicode_ci NOT NULL,
  `email` varchar(70) COLLATE utf8_unicode_ci NOT NULL,
  `comments` text COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `userid` int(70) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `email_confirmations`
--

CREATE TABLE `email_confirmations` (
  `id` int(10) UNSIGNED NOT NULL,
  `usersId` int(10) UNSIGNED NOT NULL,
  `code` char(32) NOT NULL,
  `createdAt` int(10) UNSIGNED NOT NULL,
  `modifiedAt` int(10) UNSIGNED DEFAULT NULL,
  `confirmed` char(1) DEFAULT 'N'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `email_confirmations`
--

INSERT INTO `email_confirmations` (`id`, `usersId`, `code`, `createdAt`, `modifiedAt`, `confirmed`) VALUES
(0, 8, 'grbVppDjOHknNflVKmIRdJDZP41Cqi2', 1517661536, NULL, 'N'),
(0, 9, 'IDG1m0kLWwt7tcYNACjEw22XuQC8wE', 1517663981, NULL, 'N'),
(0, 10, 'EJqzJiT6fIT8ViASmKIxYv6AnOHfJB', 1517816761, NULL, 'N'),
(0, 11, 't7osucjD3IpuiY4SGf8AIV6BtUj9WwXZ', 1517820633, NULL, 'N'),
(0, 12, 'aLRiqvw5XdY4gWle8mKad0EoIg5TG2e', 1517821241, NULL, 'N'),
(0, 13, 'MboKy2tPTkDHZM3iGJHilYeSN3WzFJN', 1517821516, NULL, 'N'),
(0, 14, 'caGnvlb0YlFnE1O3UDfCAdRou5Ot44n', 1517822203, NULL, 'N'),
(0, 15, 'mTNsD8Dr3Ovf4ji3Q3SVVhZlMASHaDwQ', 1517823059, NULL, 'N'),
(0, 16, 'FgJDYZDZOW4CJdPDRPqhU244c4LlhyvN', 1517824018, NULL, 'N'),
(0, 17, 'VutsjsMjudl3xFzIIGEXfVj8Kw9lRRG', 1517824346, NULL, 'N');

-- --------------------------------------------------------

--
-- Table structure for table `failed_logins`
--

CREATE TABLE `failed_logins` (
  `id` int(10) UNSIGNED NOT NULL,
  `usersId` int(10) UNSIGNED DEFAULT NULL,
  `ipAddress` char(15) NOT NULL,
  `attempted` int(10) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `failed_logins`
--

INSERT INTO `failed_logins` (`id`, `usersId`, `ipAddress`, `attempted`) VALUES
(0, 7, '::1', 1517661473),
(0, 7, '::1', 1517661477),
(0, 7, '::1', 1517661479),
(0, 7, '::1', 1517661495),
(0, 8, '::1', 1517661557),
(0, 8, '::1', 1517661575),
(0, 8, '::1', 1517663057),
(0, 8, '::1', 1517663935),
(0, 8, '::1', 1517663948),
(0, 9, '::1', 1517663991),
(0, 9, '::1', 1517664151),
(0, 9, '::1', 1517664161),
(0, 9, '::1', 1517805098),
(0, 9, '::1', 1517805792),
(0, 9, '::1', 1517805796),
(0, 9, '::1', 1517806688),
(0, 9, '::1', 1517807300),
(0, 9, '::1', 1517809743),
(0, 9, '::1', 1517809766),
(0, 9, '::1', 1517809780),
(0, 0, '::1', 1517809807),
(0, 9, '::1', 1517809827),
(0, 9, '::1', 1517816689),
(0, 10, '::1', 1517816782),
(0, 10, '::1', 1517816851),
(0, 10, '::1', 1517816858),
(0, 0, '::1', 1517820540),
(0, 11, '::1', 1517820690),
(0, 0, '::1', 1517821206),
(0, 0, '::1', 1517821485),
(0, 13, '::1', 1517821538),
(0, 13, '::1', 1517821633),
(0, 0, '::1', 1517822169),
(0, 14, '::1', 1517822215),
(0, 14, '::1', 1517822258),
(0, NULL, '::1', 1517822575),
(0, NULL, '::1', 1517822981),
(0, NULL, '::1', 1517823073),
(0, NULL, '::1', 1517824782),
(0, NULL, '::1', 1517833222),
(0, 0, '::1', 1517899650),
(0, 0, '::1', 1517899659);

-- --------------------------------------------------------

--
-- Table structure for table `genba_languages`
--

CREATE TABLE `genba_languages` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(20) NOT NULL,
  `code` varchar(10) NOT NULL,
  `country_prefix` varchar(20) NOT NULL,
  `flag_url` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `genba_languages`
--

INSERT INTO `genba_languages` (`id`, `name`, `code`, `country_prefix`, `flag_url`) VALUES
(5, 'Español', '1', 'es', 'https://genba.online/uploads/flag/Spanish-ES.png'),
(15, 'English', '5', 'en', 'https://genba.online/uploads/flag/English-EN.png'),
(16, 'Hindi', '4', 'in', 'https://www.fg-a.com/flags/indian-button-round-1.png');

-- --------------------------------------------------------

--
-- Table structure for table `genba_lang_strings`
--

CREATE TABLE `genba_lang_strings` (
  `id` int(11) UNSIGNED NOT NULL,
  `languages_id` int(11) UNSIGNED NOT NULL,
  `backend` longtext,
  `frontend` longtext,
  `customer_app` text,
  `operator_app` text
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `genba_lang_strings`
--

INSERT INTO `genba_lang_strings` (`id`, `languages_id`, `backend`, `frontend`, `customer_app`, `operator_app`) VALUES
(3, 5, '{"Edit selected language":"Editar el idioma seleccionado"}', '{}', '{}', '{}'),
(4, 15, '{"Edit selected language":"Edit selected language","Invoices":"Invoices","Customer":"Customer","Name":"Name","Telephone":"Telephone","address":"address","city":"city","Product Type":"Product Type","Product":"Product","Stores Stock":"Stores Stock","Price":"Price","Quantity":"Quantity","Subtotal":"Subtotal","CGST(%)":"CGST(%)","SGST(%)":"SGST(%)","Sub Total":"Sub Total","Total Amount":"Total Amount","Rs":"Rs","Go Back":"Go Back","Save":"Save","edit_invoice":"Edit Invoice"}', NULL, NULL, NULL),
(5, 16, '{"Edit selected language":"\\u091a\\u092f\\u0928\\u093f\\u0924 \\u092d\\u093e\\u0937\\u093e \\u0938\\u0902\\u092a\\u093e\\u0926\\u093f\\u0924 \\u0915\\u0930\\u0947\\u0902","Invoices":" \\u091a\\u093e\\u0932\\u093e\\u0928","Customer":"\\u0917\\u094d\\u0930\\u093e\\u0939\\u0915","Name":"\\u0928\\u093e\\u092e","Telephone":"\\u091f\\u0947\\u0932\\u0940\\u092b\\u094b\\u0928","address":"\\u092a\\u0924\\u093e","city":"\\u0936\\u0939\\u0930","Product Type":"\\u0909\\u0924\\u094d\\u092a\\u093e\\u0926 \\u092a\\u094d\\u0930\\u0915\\u093e\\u0930","Product":"\\u0909\\u0924\\u094d\\u092a\\u093e\\u0926","Stores Stock":"\\u0938\\u094d\\u091f\\u094b\\u0930 \\u0938\\u094d\\u091f\\u0949\\u0915","Price":"\\u092e\\u0942\\u0932\\u094d\\u092f","Quantity":"\\u092e\\u093e\\u0924\\u094d\\u0930\\u093e","Subtotal":"\\u0909\\u092a-\\u092f\\u094b\\u0917","CGST(%)":"\\u0938\\u0940\\u091c\\u0940\\u090f\\u0938\\u091f\\u0940 (%)","SGST(%)":"\\u090f\\u0938\\u091c\\u0940\\u090f\\u0938\\u091f\\u0940 (%)","Sub Total":"\\u0909\\u092a \\u0915\\u0941\\u0932","Total Amount":"\\u0915\\u0941\\u0932 \\u0930\\u0915\\u092e","Rs":"\\u0930\\u0941\\u092a\\u092f\\u0947","Go Back":"\\u0935\\u093e\\u092a\\u0938 \\u091c\\u093e\\u0913","Save":"\\u091c\\u092e\\u093e \\u0915\\u0930\\u0947\\u0902","edit_invoice":"\\u091a\\u093e\\u0932\\u093e\\u0928 \\u0938\\u0902\\u092a\\u093e\\u0926\\u093f\\u0924 \\u0915\\u0930\\u0947\\u0902","Create Invoice":"\\u0907\\u0928\\u0935\\u0949\\u092f\\u0938 \\u092c\\u0928\\u093e\\u090f\\u0901","ADD ANOTHER":"\\u090f\\u0915 \\u0914\\u0930 \\u091c\\u094b\\u0921\\u093c\\u0947\\u0902","Search Customer":"\\u0917\\u094d\\u0930\\u093e\\u0939\\u0915 \\u0916\\u094b\\u091c\\u0947\\u0902","Id":"\\u0905\\u0928\\u0941 \\u0915\\u094d\\u0930\\u092e\\u093e\\u0902\\u0915","email":"\\u0908\\u092e\\u0947\\u0932","Search":"\\u0916\\u094b\\u091c","Create Customer":"\\u0917\\u094d\\u0930\\u093e\\u0939\\u0915 \\u092c\\u0928\\u093e\\u090f\\u0902"}', NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `invoices`
--

CREATE TABLE `invoices` (
  `id` int(10) UNSIGNED NOT NULL,
  `cid` int(10) NOT NULL,
  `cname` varchar(70) NOT NULL,
  `cnumber` varchar(70) NOT NULL,
  `caddress` varchar(70) NOT NULL,
  `ccity` varchar(70) NOT NULL,
  `amount` decimal(16,2) NOT NULL,
  `cgst` int(70) NOT NULL,
  `sgst` int(70) NOT NULL,
  `create_date` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `userid` int(70) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `invoices`
--

INSERT INTO `invoices` (`id`, `cid`, `cname`, `cnumber`, `caddress`, `ccity`, `amount`, `cgst`, `sgst`, `create_date`, `userid`) VALUES
(3, 4, 'ganesh', '12345665432', 'ram nagar,nagpur,maharashtra,india', 'nagpur', '11.55', 5, 5, '2018-02-03 10:34:22', 1),
(4, 4, 'ganesh', '12345665432', 'ram nagar,nagpur,maharashtra,india', 'nagpur', '11.55', 5, 5, '2018-02-03 10:34:33', 1),
(5, 3, 'ram', '1234567689', 'ramtek', 'nagpur', '11.00', 5, 5, '2018-02-03 10:34:38', 1),
(6, 3, 'ram', '1234567689', 'ramtek', 'nagpur', '11.00', 5, 5, '2018-02-03 10:34:45', 1),
(7, 3, 'ram', '1234567689', 'ramtek', 'nagpur', '100.20', 10, 10, '2018-02-03 10:42:19', 1),
(8, 4, 'ganesh', '12345665432', 'ram nagar,nagpur,maharashtra,india', 'nagpur', '58.85', 5, 5, '2018-02-03 15:13:39', 1),
(10, 7, 'rakeshcustomer', '1234567890', 'ramnager,nagpur', 'nagpur', '1560.00', 28, 28, '2018-02-03 16:56:20', 5);

-- --------------------------------------------------------

--
-- Table structure for table `invoice_items`
--

CREATE TABLE `invoice_items` (
  `id` int(10) UNSIGNED NOT NULL,
  `ptype` int(40) NOT NULL,
  `name` varchar(40) NOT NULL,
  `price` decimal(16,2) NOT NULL,
  `qty` int(10) NOT NULL,
  `total` decimal(16,2) NOT NULL,
  `invoiceid` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `invoice_items`
--

INSERT INTO `invoice_items` (`id`, `ptype`, `name`, `price`, `qty`, `total`, `invoiceid`) VALUES
(4, 5, '6', '3.50', 3, '10.50', 3),
(5, 5, '6', '3.50', 3, '10.50', 4),
(6, 5, '12', '10.00', 1, '10.00', 5),
(7, 5, '12', '10.00', 1, '10.00', 6),
(8, 5, '12', '10.00', 4, '40.00', 7),
(9, 6, '9', '40.00', 1, '40.00', 7),
(10, 5, '6', '3.50', 1, '3.50', 7),
(11, 5, '6', '3.50', 1, '3.50', 8),
(12, 6, '10', '50.00', 1, '50.00', 8),
(15, 12, '14', '500.00', 2, '1000.00', 10);

-- --------------------------------------------------------

--
-- Table structure for table `password_changes`
--

CREATE TABLE `password_changes` (
  `id` int(11) NOT NULL,
  `usersId` int(10) UNSIGNED NOT NULL,
  `ipAddress` char(15) NOT NULL,
  `userAgent` text NOT NULL,
  `createdAt` int(10) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `password_changes`
--

INSERT INTO `password_changes` (`id`, `usersId`, `ipAddress`, `userAgent`, `createdAt`) VALUES
(1, 21, '::1', 'Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.36 (KHTML, like Gecko) Ubuntu Chromium/62.0.3202.94 Chrome/62.0.3202.94 Safari/537.36', 1518002529),
(2, 21, '::1', 'Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.36 (KHTML, like Gecko) Ubuntu Chromium/62.0.3202.94 Chrome/62.0.3202.94 Safari/537.36', 1518002534),
(3, 21, '::1', 'Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.36 (KHTML, like Gecko) Ubuntu Chromium/62.0.3202.94 Chrome/62.0.3202.94 Safari/537.36', 1518002783),
(4, 21, '::1', 'Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.36 (KHTML, like Gecko) Ubuntu Chromium/62.0.3202.94 Chrome/62.0.3202.94 Safari/537.36', 1518002787),
(5, 21, '::1', 'Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.36 (KHTML, like Gecko) Ubuntu Chromium/62.0.3202.94 Chrome/62.0.3202.94 Safari/537.36', 1518002978),
(6, 21, '::1', 'Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.36 (KHTML, like Gecko) Ubuntu Chromium/62.0.3202.94 Chrome/62.0.3202.94 Safari/537.36', 1518003021);

-- --------------------------------------------------------

--
-- Table structure for table `permissions`
--

CREATE TABLE `permissions` (
  `id` int(10) UNSIGNED NOT NULL,
  `profilesId` int(10) UNSIGNED NOT NULL,
  `resource` varchar(16) NOT NULL,
  `action` varchar(16) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `permissions`
--

INSERT INTO `permissions` (`id`, `profilesId`, `resource`, `action`) VALUES
(1, 3, 'users', 'index'),
(2, 3, 'users', 'search'),
(3, 3, 'profiles', 'index'),
(4, 3, 'profiles', 'search'),
(5, 1, 'users', 'index'),
(6, 1, 'users', 'search'),
(7, 1, 'users', 'edit'),
(8, 1, 'users', 'create'),
(9, 1, 'users', 'delete'),
(10, 1, 'users', 'changePassword'),
(11, 1, 'profiles', 'index'),
(12, 1, 'profiles', 'search'),
(13, 1, 'profiles', 'edit'),
(14, 1, 'profiles', 'create'),
(15, 1, 'profiles', 'delete'),
(16, 1, 'permissions', 'index'),
(17, 2, 'users', 'index'),
(18, 2, 'users', 'search'),
(19, 2, 'users', 'edit'),
(20, 2, 'users', 'create'),
(21, 2, 'profiles', 'index'),
(22, 2, 'profiles', 'search');

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE `products` (
  `id` int(10) UNSIGNED NOT NULL,
  `product_types_id` int(10) UNSIGNED NOT NULL,
  `name` varchar(70) COLLATE utf8_unicode_ci NOT NULL,
  `price` decimal(16,2) NOT NULL,
  `active` enum('Y','N') COLLATE utf8_unicode_ci NOT NULL,
  `qty` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  `creat_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `userid` int(70) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`id`, `product_types_id`, `name`, `price`, `active`, `qty`, `creat_date`, `userid`) VALUES
(1, 5, 'Artichoke', '10.50', 'Y', '40', '2017-12-30 04:33:12', 1),
(2, 5, 'Bell pepper', '10.40', 'Y', '10.00', '2017-12-30 04:33:12', 0),
(3, 5, 'Cauliflower', '20.10', 'Y', '0.00', '2017-12-30 04:33:12', 0),
(4, 5, 'Chinese cabbage', '15.50', 'Y', '10.00', '2017-12-30 04:33:12', 1),
(5, 5, 'Malabar spinach', '7.50', 'Y', '0.00', '2017-12-30 04:33:12', 0),
(6, 5, 'Onion', '3.50', 'Y', '48', '2017-12-30 04:33:12', 0),
(7, 5, 'Peanut', '4.50', 'Y', '0.00', '2017-12-30 04:33:12', 0),
(8, 6, 'Banana', '10.00', 'Y', '9', '2017-12-30 04:33:12', 0),
(9, 6, 'Apple', '40.00', 'Y', '9', '2018-01-09 12:07:55', 1),
(10, 6, 'Mango', '50.00', 'Y', '10', '2018-01-09 12:19:46', 1),
(11, 6, 'Orange', '20.00', 'Y', '10', '2018-01-09 13:18:06', 1),
(12, 5, 'tomato', '10.00', 'Y', '45', '2018-01-25 10:48:06', 0),
(14, 12, 'table', '500.00', 'Y', '8', '2018-02-03 11:23:18', 5),
(15, 12, 'test', '10.00', 'Y', NULL, '2018-02-12 06:44:26', 1);

-- --------------------------------------------------------

--
-- Table structure for table `product_types`
--

CREATE TABLE `product_types` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(70) COLLATE utf8_unicode_ci NOT NULL,
  `userid` int(70) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `product_types`
--

INSERT INTO `product_types` (`id`, `name`, `userid`) VALUES
(5, 'Vegetables', 2),
(6, 'Fruits', 1),
(12, 'furniture', 5);

-- --------------------------------------------------------

--
-- Table structure for table `profiles`
--

CREATE TABLE `profiles` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(64) NOT NULL,
  `active` char(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `profiles`
--

INSERT INTO `profiles` (`id`, `name`, `active`) VALUES
(1, 'Administrators', 'Y'),
(2, 'Users', 'Y');

-- --------------------------------------------------------

--
-- Table structure for table `remember_tokens`
--

CREATE TABLE `remember_tokens` (
  `id` int(10) UNSIGNED NOT NULL,
  `usersId` int(10) UNSIGNED NOT NULL,
  `token` char(32) NOT NULL,
  `userAgent` varchar(120) NOT NULL,
  `createdAt` int(10) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `reset_passwords`
--

CREATE TABLE `reset_passwords` (
  `id` int(11) NOT NULL,
  `usersId` int(10) UNSIGNED NOT NULL,
  `email` varchar(48) NOT NULL,
  `createdAt` varchar(40) NOT NULL,
  `modifiedAt` varchar(40) NOT NULL,
  `reset` varchar(40) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `reset_passwords`
--

INSERT INTO `reset_passwords` (`id`, `usersId`, `email`, `createdAt`, `modifiedAt`, `reset`) VALUES
(1, 22, 'test@gmail.com', '1518073426', '', '123456789');

-- --------------------------------------------------------

--
-- Table structure for table `site_options`
--

CREATE TABLE `site_options` (
  `id` int(11) UNSIGNED NOT NULL,
  `key` varchar(70) NOT NULL,
  `value` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `site_options`
--

INSERT INTO `site_options` (`id`, `key`, `value`) VALUES
(3, 'lang_native_backend', '["Edit selected language","Invoices","Customer","Name","Telephone","address","city","Product Type","Product","Stores Stock","Price","Quantity","Subtotal","CGST(%)","SGST(%)","Sub Total","Total Amount","Rs","Go Back","Save","edit_invoice","Create Invoice","ADD ANOTHER","Search Customer","Id","email","Search","Create Customer"]'),
(4, 'lang_native_frontend', '[]'),
(5, 'lang_native_customer', '[]'),
(6, 'lang_native_operator', '[]'),
(7, 'site_close_status', '0'),
(8, 'site_close_message', 'App is close for now.'),
(9, 'country_iso_codes', '1,34,52,502,503,504,505,506,507');

-- --------------------------------------------------------

--
-- Table structure for table `success_logins`
--

CREATE TABLE `success_logins` (
  `id` int(11) NOT NULL,
  `usersId` int(10) UNSIGNED NOT NULL,
  `ipAddress` char(15) NOT NULL,
  `userAgent` varchar(120) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `success_logins`
--

INSERT INTO `success_logins` (`id`, `usersId`, `ipAddress`, `userAgent`) VALUES
(1, 21, '::1', 'Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.36 (KHTML, like Gecko) Ubuntu Chromium/62.0.3202.94 Chrome/62.0.3202.94 Sa'),
(2, 21, '::1', 'Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.36 (KHTML, like Gecko) Ubuntu Chromium/62.0.3202.94 Chrome/62.0.3202.94 Sa'),
(3, 21, '::1', 'Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.36 (KHTML, like Gecko) Ubuntu Chromium/62.0.3202.94 Chrome/62.0.3202.94 Sa'),
(4, 21, '::1', 'Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.36 (KHTML, like Gecko) Ubuntu Chromium/62.0.3202.94 Chrome/62.0.3202.94 Sa'),
(5, 21, '::1', 'Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.36 (KHTML, like Gecko) Ubuntu Chromium/62.0.3202.94 Chrome/62.0.3202.94 Sa'),
(6, 21, '::1', 'Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.36 (KHTML, like Gecko) Ubuntu Chromium/62.0.3202.94 Chrome/62.0.3202.94 Sa'),
(7, 21, '::1', 'Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.36 (KHTML, like Gecko) Ubuntu Chromium/62.0.3202.94 Chrome/62.0.3202.94 Sa'),
(8, 21, '::1', 'Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.36 (KHTML, like Gecko) Ubuntu Chromium/62.0.3202.94 Chrome/62.0.3202.94 Sa'),
(9, 21, '::1', 'Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.36 (KHTML, like Gecko) Ubuntu Chromium/62.0.3202.94 Chrome/62.0.3202.94 Sa'),
(10, 21, '::1', 'Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.36 (KHTML, like Gecko) Ubuntu Chromium/62.0.3202.94 Chrome/62.0.3202.94 Sa'),
(11, 21, '::1', 'Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.36 (KHTML, like Gecko) Ubuntu Chromium/62.0.3202.94 Chrome/62.0.3202.94 Sa'),
(12, 21, '::1', 'Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.36 (KHTML, like Gecko) Ubuntu Chromium/62.0.3202.94 Chrome/62.0.3202.94 Sa'),
(13, 21, '::1', 'Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.36 (KHTML, like Gecko) Ubuntu Chromium/62.0.3202.94 Chrome/62.0.3202.94 Sa'),
(14, 21, '::1', 'Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.36 (KHTML, like Gecko) Ubuntu Chromium/62.0.3202.94 Chrome/62.0.3202.94 Sa'),
(15, 21, '::1', 'Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.36 (KHTML, like Gecko) Ubuntu Chromium/62.0.3202.94 Chrome/62.0.3202.94 Sa'),
(16, 21, '::1', 'Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.36 (KHTML, like Gecko) Ubuntu Chromium/62.0.3202.94 Chrome/62.0.3202.94 Sa'),
(17, 21, '::1', 'Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.36 (KHTML, like Gecko) Ubuntu Chromium/62.0.3202.94 Chrome/62.0.3202.94 Sa'),
(18, 21, '::1', 'Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.36 (KHTML, like Gecko) Ubuntu Chromium/62.0.3202.94 Chrome/62.0.3202.94 Sa'),
(19, 21, '::1', 'Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.36 (KHTML, like Gecko) Ubuntu Chromium/62.0.3202.94 Chrome/62.0.3202.94 Sa'),
(20, 21, '::1', 'Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.36 (KHTML, like Gecko) Ubuntu Chromium/62.0.3202.94 Chrome/62.0.3202.94 Sa'),
(21, 21, '::1', 'Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.36 (KHTML, like Gecko) Ubuntu Chromium/62.0.3202.94 Chrome/62.0.3202.94 Sa'),
(22, 21, '::1', 'Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.36 (KHTML, like Gecko) Ubuntu Chromium/62.0.3202.94 Chrome/62.0.3202.94 Sa'),
(23, 21, '::1', 'Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.36 (KHTML, like Gecko) Ubuntu Chromium/62.0.3202.94 Chrome/62.0.3202.94 Sa'),
(24, 21, '::1', 'Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.36 (KHTML, like Gecko) Ubuntu Chromium/62.0.3202.94 Chrome/62.0.3202.94 Sa'),
(25, 21, '::1', 'Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.36 (KHTML, like Gecko) Ubuntu Chromium/62.0.3202.94 Chrome/62.0.3202.94 Sa'),
(26, 21, '::1', 'Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.36 (KHTML, like Gecko) Ubuntu Chromium/62.0.3202.94 Chrome/62.0.3202.94 Sa'),
(27, 21, '::1', 'Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.36 (KHTML, like Gecko) Ubuntu Chromium/62.0.3202.94 Chrome/62.0.3202.94 Sa'),
(28, 21, '::1', 'Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.36 (KHTML, like Gecko) Ubuntu Chromium/62.0.3202.94 Chrome/62.0.3202.94 Sa'),
(29, 21, '::1', 'Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.36 (KHTML, like Gecko) Ubuntu Chromium/62.0.3202.94 Chrome/62.0.3202.94 Sa'),
(30, 21, '::1', 'Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.36 (KHTML, like Gecko) Ubuntu Chromium/62.0.3202.94 Chrome/62.0.3202.94 Sa'),
(31, 21, '::1', 'Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.36 (KHTML, like Gecko) Ubuntu Chromium/62.0.3202.94 Chrome/62.0.3202.94 Sa'),
(32, 21, '::1', 'Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.36 (KHTML, like Gecko) Ubuntu Chromium/62.0.3202.94 Chrome/62.0.3202.94 Sa'),
(33, 21, '::1', 'Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.36 (KHTML, like Gecko) Ubuntu Chromium/62.0.3202.94 Chrome/62.0.3202.94 Sa'),
(34, 21, '::1', 'Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.36 (KHTML, like Gecko) Ubuntu Chromium/62.0.3202.94 Chrome/62.0.3202.94 Sa'),
(35, 21, '::1', 'Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.36 (KHTML, like Gecko) Ubuntu Chromium/62.0.3202.94 Chrome/62.0.3202.94 Sa'),
(36, 21, '::1', 'Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.36 (KHTML, like Gecko) Ubuntu Chromium/62.0.3202.94 Chrome/62.0.3202.94 Sa'),
(37, 21, '::1', 'Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.36 (KHTML, like Gecko) Ubuntu Chromium/62.0.3202.94 Chrome/62.0.3202.94 Sa'),
(38, 21, '::1', 'Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.36 (KHTML, like Gecko) Ubuntu Chromium/62.0.3202.94 Chrome/62.0.3202.94 Sa'),
(39, 21, '::1', 'Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.36 (KHTML, like Gecko) Ubuntu Chromium/62.0.3202.94 Chrome/62.0.3202.94 Sa'),
(40, 21, '::1', 'Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.36 (KHTML, like Gecko) Ubuntu Chromium/62.0.3202.94 Chrome/62.0.3202.94 Sa'),
(41, 21, '::1', 'Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.36 (KHTML, like Gecko) Ubuntu Chromium/62.0.3202.94 Chrome/62.0.3202.94 Sa'),
(42, 21, '::1', 'Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.36 (KHTML, like Gecko) Ubuntu Chromium/62.0.3202.94 Chrome/62.0.3202.94 Sa'),
(43, 21, '::1', 'Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.36 (KHTML, like Gecko) Ubuntu Chromium/62.0.3202.94 Chrome/62.0.3202.94 Sa'),
(44, 21, '::1', 'Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.36 (KHTML, like Gecko) Ubuntu Chromium/62.0.3202.94 Chrome/62.0.3202.94 Sa'),
(45, 21, '::1', 'Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.36 (KHTML, like Gecko) Ubuntu Chromium/62.0.3202.94 Chrome/62.0.3202.94 Sa'),
(46, 21, '::1', 'Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.36 (KHTML, like Gecko) Ubuntu Chromium/62.0.3202.94 Chrome/62.0.3202.94 Sa'),
(47, 21, '::1', 'Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.36 (KHTML, like Gecko) Ubuntu Chromium/62.0.3202.94 Chrome/62.0.3202.94 Sa'),
(48, 21, '::1', 'Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.36 (KHTML, like Gecko) Ubuntu Chromium/62.0.3202.94 Chrome/62.0.3202.94 Sa'),
(49, 21, '::1', 'Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.36 (KHTML, like Gecko) Ubuntu Chromium/62.0.3202.94 Chrome/62.0.3202.94 Sa'),
(50, 21, '::1', 'Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.36 (KHTML, like Gecko) Ubuntu Chromium/62.0.3202.94 Chrome/62.0.3202.94 Sa'),
(51, 21, '::1', 'Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.36 (KHTML, like Gecko) Ubuntu Chromium/62.0.3202.94 Chrome/62.0.3202.94 Sa'),
(52, 21, '::1', 'Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.36 (KHTML, like Gecko) Ubuntu Chromium/62.0.3202.94 Chrome/62.0.3202.94 Sa'),
(53, 21, '::1', 'Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.36 (KHTML, like Gecko) Ubuntu Chromium/62.0.3202.94 Chrome/62.0.3202.94 Sa'),
(54, 21, '::1', 'Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.36 (KHTML, like Gecko) Ubuntu Chromium/62.0.3202.94 Chrome/62.0.3202.94 Sa'),
(55, 21, '::1', 'Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.36 (KHTML, like Gecko) Ubuntu Chromium/62.0.3202.94 Chrome/62.0.3202.94 Sa'),
(56, 21, '::1', 'Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.36 (KHTML, like Gecko) Ubuntu Chromium/62.0.3202.94 Chrome/62.0.3202.94 Sa'),
(57, 21, '::1', 'Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.36 (KHTML, like Gecko) Ubuntu Chromium/62.0.3202.94 Chrome/62.0.3202.94 Sa'),
(58, 21, '::1', 'Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.36 (KHTML, like Gecko) Ubuntu Chromium/62.0.3202.94 Chrome/62.0.3202.94 Sa'),
(59, 21, '::1', 'Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.36 (KHTML, like Gecko) Ubuntu Chromium/62.0.3202.94 Chrome/62.0.3202.94 Sa');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(10) UNSIGNED NOT NULL,
  `username` varchar(32) COLLATE utf8_unicode_ci NOT NULL,
  `password` char(40) COLLATE utf8_unicode_ci NOT NULL,
  `mustChangePassword` char(1) CHARACTER SET utf8 DEFAULT NULL,
  `profilesId` int(10) UNSIGNED NOT NULL,
  `banned` char(1) COLLATE utf8_unicode_ci NOT NULL,
  `suspended` char(1) COLLATE utf8_unicode_ci NOT NULL,
  `name` varchar(120) COLLATE utf8_unicode_ci NOT NULL,
  `email` varchar(70) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `active` char(1) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `username`, `password`, `mustChangePassword`, `profilesId`, `banned`, `suspended`, `name`, `email`, `created_at`, `active`) VALUES
(1, 'demo', '7c4a8d09ca3762af61e59520943dc26494f8941b', 'Y', 2, 'N', 'N', 'Phalcon Demo', 'demo@phalconphp.com', '2012-04-10 20:53:03', 'Y'),
(2, 'sewak', '827ccb0eea8a706c4c34a16891f84e7b', NULL, 2, '', '', 'sewak deshmukh', 'sewakdeshmukh19@gmail.com', '2017-11-27 12:33:24', 'Y'),
(3, 'ttttt', '8cb2237d0679ca88db6464eac60da96345513964', NULL, 2, '', '', 'ttt', 'jorge@indicode.tech', '2017-11-28 11:32:52', 'Y'),
(4, 'ram', '8cb2237d0679ca88db6464eac60da96345513964', NULL, 2, '', '', 'deshmukh', 'ram@gmail.com', '2017-12-26 12:13:54', 'Y'),
(5, 'rakesh', '7c4a8d09ca3762af61e59520943dc26494f8941b', NULL, 2, '', '', 'rakesh', 'rakesh@gmail.com', '2018-02-03 11:17:22', 'Y'),
(6, 'qqqq', '77d3319e3cd2e949ebc39e5bfd8598af278050e6', NULL, 2, '', '', 'qqq', 'qq@ss.hh', '2018-02-03 12:12:24', 'Y'),
(21, 'admin', 'f7c3bc1d808e04732adf679965ccc34ca7ae3441', 'Y', 1, 'N', 'N', 'admin', 'admin@gmail.com', '2018-02-06 13:40:56', 'Y'),
(22, 'testname', 'f7c3bc1d808e04732adf679965ccc34ca7ae3441', 'N', 2, 'N', 'N', 'test', 'test@gmail.com', '2018-02-08 07:03:46', 'Y');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `companies`
--
ALTER TABLE `companies`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `contact`
--
ALTER TABLE `contact`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `genba_languages`
--
ALTER TABLE `genba_languages`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `genba_lang_strings`
--
ALTER TABLE `genba_lang_strings`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `invoices`
--
ALTER TABLE `invoices`
  ADD PRIMARY KEY (`id`),
  ADD KEY `cid` (`cid`);

--
-- Indexes for table `invoice_items`
--
ALTER TABLE `invoice_items`
  ADD PRIMARY KEY (`id`),
  ADD KEY `invoiceid` (`invoiceid`),
  ADD KEY `ptype` (`ptype`) USING BTREE;

--
-- Indexes for table `password_changes`
--
ALTER TABLE `password_changes`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `permissions`
--
ALTER TABLE `permissions`
  ADD PRIMARY KEY (`id`),
  ADD KEY `profilesId` (`profilesId`);

--
-- Indexes for table `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `product_types`
--
ALTER TABLE `product_types`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `profiles`
--
ALTER TABLE `profiles`
  ADD PRIMARY KEY (`id`),
  ADD KEY `active` (`active`);

--
-- Indexes for table `reset_passwords`
--
ALTER TABLE `reset_passwords`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `site_options`
--
ALTER TABLE `site_options`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `key` (`key`);

--
-- Indexes for table `success_logins`
--
ALTER TABLE `success_logins`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD KEY `profilesId` (`profilesId`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `companies`
--
ALTER TABLE `companies`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;
--
-- AUTO_INCREMENT for table `contact`
--
ALTER TABLE `contact`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `genba_languages`
--
ALTER TABLE `genba_languages`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;
--
-- AUTO_INCREMENT for table `genba_lang_strings`
--
ALTER TABLE `genba_lang_strings`
  MODIFY `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
--
-- AUTO_INCREMENT for table `invoices`
--
ALTER TABLE `invoices`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;
--
-- AUTO_INCREMENT for table `invoice_items`
--
ALTER TABLE `invoice_items`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;
--
-- AUTO_INCREMENT for table `password_changes`
--
ALTER TABLE `password_changes`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
--
-- AUTO_INCREMENT for table `permissions`
--
ALTER TABLE `permissions`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=23;
--
-- AUTO_INCREMENT for table `products`
--
ALTER TABLE `products`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;
--
-- AUTO_INCREMENT for table `product_types`
--
ALTER TABLE `product_types`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;
--
-- AUTO_INCREMENT for table `profiles`
--
ALTER TABLE `profiles`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `reset_passwords`
--
ALTER TABLE `reset_passwords`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `site_options`
--
ALTER TABLE `site_options`
  MODIFY `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;
--
-- AUTO_INCREMENT for table `success_logins`
--
ALTER TABLE `success_logins`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=60;
--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=23;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
