
 <?php use Phalcon\Tag; ?>
 <div class="row" data-plugin="matchHeight" data-by-row="true" style="margin-right: 71px;
    margin-left: 100px;">
 <?php 
 $id_retrieve = $id;
 //echo $id_retrieve;
 $languageString=LanguagesString::find();
 $backData=array();
 $frontData=array();
 $customerData=array();
 $operatorData=array();
/*  $records=LanguagesString::findFirst($id_retrieve); */
 foreach($languageString as $k=>$v)
 {
	 /* echo $v->languages_id;
	  echo "<br/>";
	 echo $id_retrieve;
	 echo "<br/>"; */
	if($v->languages_id == $id_retrieve)
	{
		$backData = json_decode($v->backend,true);
		$frontData = json_decode($v->frontend,true);
		$customerData = json_decode($v->customer_app,true);
		$operatorData = json_decode($v->operator_app,true);
		
	}
 }
 $siteoption=SiteOptions::find("key IN('lang_native_backend','lang_native_frontend','lang_native_customer','lang_native_operator')");
 //$genba_moments_nested=SiteOptions::findFirstByKey('genba_moments_nested');
 //$genba_moments_nested=($genba_moments_nested->value) ? $genba_moments_nested->value : array();
 foreach($siteoption as $k=>$v)
 {
	switch($v->key)
	 {
		 case "lang_native_backend":
		  $one=json_decode($v->value);
		 break;
		 case "lang_native_frontend":
		  $two=json_decode($v->value);
		 break;
		 case "lang_native_customer":
		   $three=json_decode($v->value);
		 break;
		 case "lang_native_operator":
		   $four=json_decode($v->value);
		 break;
	 }			 
 }
 /* echo "<pre>";
 print_r( $one);
 print_r( $two);
 print_r( $three);
 print_r($four); */
 ?>
 <?= $this->tag->stylesheetLink('global/vendor/editable-table/editable-table.css') ?>
        <div class="col-sm-12"> 
        <!-- Panel Linearea Two -->
        <!--<h3 class="panel-title blue-grey-200 font-weight-200"> 
        <i class="panel-title-icon icon md-cast blue-gray-100" aria-hidden="true"></i> <?= $t->_('Create a new country') ?></h3>-->
        
        <div class="widget widget-shadow" id="charLineareaTwo">
            <div class="widget-content padding-30 height-full">
                <div class="row" style="height:calc(100% - 300px);">
                    <div class="col-xs-8">
                      <h3 class="grey-700"><?= $t->_('Edit selected language') ?></h3>
                    </div>
                    
                  </div>
                    
                
                  <div style="padding-top:10px;">
				   <form name="form-editstring" method="post" id="editStringForm" autocomplete="on" action=""  enctype="multipart/form-data" >
                    <div class="row">
                        <div class="col-md-12 padding-top-25">
                        
                        <div class="nav-tabs-horizontal">
                          <ul id="update_tab_custom" class="nav nav-tabs nav-tabs-line" data-plugin="nav-tabs" role="tablist">
                            
							<li data-ref="backend" class="active" role="presentation"><a data-toggle="tab" href="#exampleTabsLineOne" aria-controls="exampleTabsLineOne"
                              role="tab" ><?= $t->_('Backend') ?></a></li>
							  
                            <!-- <li data-ref="frontend" role="presentation"><a data-toggle="tab" href="#exampleTabsLineTwo" aria-controls="exampleTabsLineTwo"
                              role="tab" ><?= $t->_('Frontend') ?></a></li> 
							  
                            <li data-ref="customer_app" role="presentation"><a data-toggle="tab" href="#exampleTabsLineThree" aria-controls="exampleTabsLineThree"
                              role="tab" ><?= $t->_('Mobile App (Customers)') ?></a></li>
							  
                            <li data-ref="operator_app" role="presentation"><a data-toggle="tab" href="#exampleTabsLineFour" aria-controls="exampleTabsLineFour"
                              role="tab" ><?= $t->_('Mobile App (Operators)') ?></a></li> -->
							  
                          </ul>
                          <div class="tab-content padding-top-20">
                            <div class="tab-pane active" id="exampleTabsLineOne" role="tabpanel">
                              <table class="editable-table table table-striped cls_backend" id="editableTable">
                                <thead>
                                  <tr>
                                    <th><?= $t->_('Native string') ?></th>
                                    <th><?= $t->_('Translation') ?></th>
                                  </tr>
                                </thead>
                                <tbody>
									<?php
									foreach($one as $p=>$q)
									{
									?>
								   <tr>
										<td style="cursor:not-allowed"><?php echo $q;?></td>
										<td><?php echo isset($backData[$q])? $backData[$q] : '';?></td>
								   
								   </tr>
								   <?php
									}
								   ?>
								<?php 
							    /*  foreach($one as $p=>$q)
								{
									echo "<tr>";
									echo '<td style="disabled">'.$q.'</td>';
									$val=(isset($backData[$q])) ? $backData[$q] : '';
									echo '<td>'.$val.'</td>';
									echo "</tr>";
								} */
								?>
                                </tbody>
                              </table>
                            </div>
                            <div class="tab-pane" id="exampleTabsLineTwo" role="tabpanel">
                              <table class="editable-table table table-striped cls_frontend" id="editableTable2">
                                <thead>
                                  <tr>
                                    <th><?= $t->_('Native string') ?></th>
                                    <th><?= $t->_('Translation') ?></th>
                                  </tr>
                                </thead>
                                <tbody>
								
								<?php
									foreach($two as $p=>$q)
									{
									?>
								   <tr>
										<td style="cursor:not-allowed"><?php echo $q;?></td>
										<td><?php echo isset($frontData[$q])? $frontData[$q] : '';?></td>
								   
								   </tr>
								   <?php
									}
								   ?>
								
								
                                <?php 
								
								/* foreach($two as $p=>$q)
								{
									echo "<tr>";
									echo '<td >'.$q.'</td>';
									$val=(isset($frontData[$q])) ? $frontData[$q] : '';
									echo '<td>'.$val.'</td>';
									echo "</tr>";
								}  */
								?>
                                    
                                 
                                </tbody>
                              </table>
                            </div>
                            <div class="tab-pane" id="exampleTabsLineThree" role="tabpanel">
                              <table class="editable-table table table-striped cls_customers" id="editableTable3">
                                <thead>
                                  <tr>
                                    <th><?= $t->_('Native string') ?></th>
                                    <th><?= $t->_('Translation') ?></th>
                                  </tr>
                                </thead>
                                <tbody>
								<?php
									foreach($three as $p=>$q)
									{
									?>
								   <tr>
										<td style="cursor:not-allowed"><?php echo $q;?></td>
										<td><?php echo isset($customerData[$q])? $customerData[$q] : '';?></td>
								   
								   </tr>
								   <?php
									}
								   ?>
                                <?php 
								/* echo "<pre>";
								print_r($myData3); */ 
								/* echo "<pre>";
								print_r($three); */
								/*  foreach($three as $p=>$q)
								{
									echo "<tr>";
									echo '<td >'.$q.'</td>';
									$val=(isset($customerData[$q])) ? $customerData[$q] : '';
									echo '<td>'.$val.'</td>';
									echo "</tr>";
								} */
								?>
                                </tbody>
                              </table>
                            </div>
                            <div class="tab-pane" id="exampleTabsLineFour" role="tabpanel">
                              <table class="editable-table table table-striped cls_operators" id="editableTable4" data-plugin="">
                                <thead>
                                  <tr>
                                    <th><?= $t->_('Native string') ?></th>
                                    <th><?= $t->_('Translation') ?></th>
                                  </tr>
                                </thead>
                                <tbody>
								<?php
									foreach($four as $p=>$q)
									{
									?>
								   <tr>
										<td style="cursor:not-allowed"><?php echo $q;?></td>
										<td><?php echo isset($operatorData[$q])? $operatorData[$q] : '';?></td>
								   
								   </tr>
								   <?php
									}
								   ?>
								
                                <?php 
							
								/* foreach($four as $p=>$q)
								{
									echo "<tr>";
									echo '<td >'.$q.'</td>';
									$val=(isset($operatorData[$q])) ? $operatorData[$q] : '';
									echo '<td>'.$val.'</td>';
									echo "</tr>";
								} */
								?>
                                </tbody>
                              </table>
                            </div>
                          </div>
                        </div>
                        
                        
                    <div class="row padding-top-20">
                    	<div class="col-md-9"></div>
                        <div class="col-md-3">
                            <div class="text-right">
                                <button type="button" class="btn btn-block btn-success" id="update_lang"><?= $t->_('Update language strings') ?></button>
								<input type="hidden" name="id_get" id="id_get" value="<?= $id ?>"/> 
                            </div>   
                        </div>
                  	</div> 
                   	
          	    </div>
              
             </div>
            </form>
           </div> 
              
          </div>
          </div>
        <!-- End Panel Linearea Two --> 
      </div>
      </div>

	  <?= $this->tag->javascriptInclude('global/vendor/editable-table/mindmup-editabletable.js') ?>
	  <?= $this->tag->javascriptInclude('global/assets/examples/js/tables/editable.js') ?>
	  <!-- <?= $this->tag->javascriptInclude('global/js/components/editable-table.js') ?> -->
	  <script>
		$(document).ready(function(){
		$('#editableTable').editableTableWidget();
		$('#editableTable2').editableTableWidget();
		$('#editableTable3').editableTableWidget();
		$('#editableTable4').editableTableWidget();
		});
	  </script>
	  <script type="text/javascript">
	    $(document).ready(function(){
			 var l_id  = $('#id_get').val();		 
			 $("#update_lang").click(function(){
			   var update_data={};	
			   var update_type=$("ul#update_tab_custom").find("li.active").attr("data-ref");
			   switch (update_type) {
				    case 'backend':
				    	$(".cls_backend tbody").find('tr').each(function (i,el) { 
						    var $tds = $(this).find('td');
						    $nativeString= $tds.eq(0).text();
						    $translation = $tds.eq(1).text();
						    update_data[$nativeString]=$translation;
					    }); 
				    break;
				    case 'frontend':
				    	$(".cls_frontend tbody").find('tr').each(function (i,el) { 
					    var $tds = $(this).find('td');
						    $nativeString= $tds.eq(0).text();
						    $translation = $tds.eq(1).text();
						    update_data[$nativeString]=$translation;
		        		});
				    break;
				    case 'customer_app':
    					$(".cls_customers tbody").find('tr').each(function (i,el) { 
					    var $tds = $(this).find('td');
						    $nativeString= $tds.eq(0).text();
						    $translation = $tds.eq(1).text();
						    update_data[$nativeString]=$translation;
						
		        		});
				    break;
				    case 'operator_app':
				    	$(".cls_operators tbody").find('tr').each(function (i,el) { 
					    var $tds = $(this).find('td');
						    $nativeString= $tds.eq(0).text();
						    $translation = $tds.eq(1).text();
						    update_data[$nativeString]=$translation;
		        		});
				    break;
				}
			console.log(update_type);
			console.log(update_data);	
			//if (data_backend && data_frontend && data_customers && data_operators){
            $.ajax({
                type: "POST",  
                url:"../../admin-languages/update_string",
                dataType: "json",
				beforeSend: function(){
					$('#myModal').modal('show');
				},
				data:{
					l_id : l_id,
					update_type:update_type,
					update_data:update_data,
				},
                success:function(response){
					if(response['msg']=='success')
					{
						$('#myModal').modal('hide');	
					}
                } 
                }); 
			//}
			
    
			 });
			/* $.ajaxStart(function () {
				$('#myModal').show();  // show loading indicator
			});

			$.ajaxStop(function() 
			{
				$('#myModal').hide();  // hide loading indicator
			}); */
			
		});
	
	  </script>
	  <script type="text/javascript">
	 
	  </script>
