<?= $this->getContent() ?>

<ul class="pager">
    <li class="previous">
        <?= $this->tag->linkTo(['products', '&larr; Go Back']) ?>
    </li>
    <li class="next">
        <?= $this->tag->linkTo(['products/new', 'Create products']) ?>
    </li>
</ul>

<?php $v22381122901iterated = false; ?><?php $v22381122901iterator = $page->items; $v22381122901incr = 0; $v22381122901loop = new stdClass(); $v22381122901loop->self = &$v22381122901loop; $v22381122901loop->length = count($v22381122901iterator); $v22381122901loop->index = 1; $v22381122901loop->index0 = 1; $v22381122901loop->revindex = $v22381122901loop->length; $v22381122901loop->revindex0 = $v22381122901loop->length - 1; ?><?php foreach ($v22381122901iterator as $product) { ?><?php $v22381122901loop->first = ($v22381122901incr == 0); $v22381122901loop->index = $v22381122901incr + 1; $v22381122901loop->index0 = $v22381122901incr; $v22381122901loop->revindex = $v22381122901loop->length - $v22381122901incr; $v22381122901loop->revindex0 = $v22381122901loop->length - ($v22381122901incr + 1); $v22381122901loop->last = ($v22381122901incr == ($v22381122901loop->length - 1)); ?><?php $v22381122901iterated = true; ?>
    <?php if ($v22381122901loop->first) { ?>
<table class="table table-bordered table-striped" align="center">
    <thead>
        <tr>
            <th>Id</th>
            <th>Product Type</th>
            <th>Name</th>
            <th>Price</th>
            <th>Active</th>
        </tr>
    </thead>
    <tbody>
    <?php } ?>
        <tr>
            <td><?= $product->id ?></td>
            <td><?= $product->getProductTypes()->name ?></td>
            <td><?= $product->name ?></td>
            <td>$<?= sprintf('%.2f', $product->price) ?></td>
            <td><?= $product->getActiveDetail() ?></td>
            <td width="7%"><?= $this->tag->linkTo(['products/edit/' . $product->id, '<i class="glyphicon glyphicon-edit"></i> Edit', 'class' => 'btn btn-default']) ?></td>
            <td width="7%"><?= $this->tag->linkTo(['products/delete/' . $product->id, '<i class="glyphicon glyphicon-remove"></i> Delete', 'class' => 'btn btn-default']) ?></td>
        </tr>
    <?php if ($v22381122901loop->last) { ?>
    </tbody>
    <tbody>
        <tr>
            <td colspan="7" align="right">
                <div class="btn-group">
                    <?= $this->tag->linkTo(['products/search', '<i class="icon-fast-backward"></i> First', 'class' => 'btn']) ?>
                    <?= $this->tag->linkTo(['products/search?page=' . $page->before, '<i class="icon-step-backward"></i> Previous', 'class' => 'btn']) ?>
                    <?= $this->tag->linkTo(['products/search?page=' . $page->next, '<i class="icon-step-forward"></i> Next', 'class' => 'btn']) ?>
                    <?= $this->tag->linkTo(['products/search?page=' . $page->last, '<i class="icon-fast-forward"></i> Last', 'class' => 'btn']) ?>
                    <span class="help-inline"><?= $page->current ?> of <?= $page->total_pages ?></span>
                </div>
            </td>
        </tr>
    </tbody>
</table>
    <?php } ?>
<?php $v22381122901incr++; } if (!$v22381122901iterated) { ?>
    No products are recorded
<?php } ?>
