<?php use Phalcon\Tag; ?>
<?= $this->getContent() ?>
<?= $this->tag->javascriptInclude('js/jquery.validate.min.js') ?>
 <div class="row" data-plugin="matchHeight" data-by-row="true" style="margin-right: 71px;
    margin-left: 100px;">
        <div class="col-sm-12"> 
              <div class="widget widget-shadow" id="charLineareaTwo">
            <div class="widget-content padding-30 height-full">
                <div class="row" style="height:calc(100% - 300px);">
                    <div class="col-xs-8">
                      <h3 class="grey-700"><?= $t->_('Create a new language') ?></h3>
                    </div>
                    <div class="col-xs-4">
                      <div class="row pull-right">
                        <div class="col-xs-12">
                          <a href="#" class="no-decoration"><div class="counter-label grey-600"><?= $t->_('Help') ?></div></a>
                        </div>
                      </div>
                    </div>
                  </div>
                 <div style="padding-top:10px;">
                    <form name="form-new" id="form-new" method="post" autocomplete="on" action="../admin-languages/new" enctype="multipart/form-data" class="" role="form">
   
                    <div class="row">
                        <div class="col-md-6 padding-top-25">
                            <div class="form-group">
                                <span class="label-field"><?= $t->_('Name') ?></span><br />   
                                <span class="label-subfield"><?= $t->_('Insert the language textual name') ?></span>
                                <?= $this->tag->textField(['name', 'class' => 'form-control', 'placeholder' => 'Español', 'id' => 'inputPlaceholder']) ?>
                            </div>
                        </div>
                        <div class="col-md-6 padding-top-25">
                            <div class="form-group">
                                <span class="label-field"><?= $t->_('Code') ?></span><br />
                                <span class="label-subfield"><?= $t->_('Select a digit-based code for this language') ?></span>
                                <?= $this->tag->textField(['code', 'class' => 'form-control', 'placeholder' => '3', 'id' => 'inputPlaceholder']) ?>
                            </div>
                        </div>
                    </div>
                    <div class="row">    
                        <div class="col-md-6 padding-top-25">
                            <div class="form-group">
                                <span class="label-field"><?= $t->_('Language Prefix') ?></span><br />
                                <span class="label-subfield"><?= $t->_('Insert the ISO prefix code for this language') ?></span>
                                <?= $this->tag->textField(['country_prefix', 'class' => 'form-control', 'placeholder' => 'es-ES', 'id' => 'inputPlaceholder']) ?>
                            </div>
                        </div>
                        <div class="col-md-6 padding-top-25">
                        <span class="label-field"><?= $t->_('Image Flag') ?></span><br />
                        <span class="label-subfield"><?= $t->_('Select a representative image for this language (400x290)') ?></span>
                            <input type="file" id="input-file-max-fs" data-plugin="dropify" name="image" accept="image/*" alt="" data-max-file-size="2M" data-height="70"/>
                        </div>    
                    </div>
                        
                    <div class="row padding-top-20">
                        <div class="col-md-9"></div>
                        <div class="col-md-3">
                            <div class="text-right">
                                <button type="submit" class="btn btn-block btn-success"><?= $t->_('Create') ?></button>
                            </div>   
                        </div>
                    </div>
                <?= $this->tag->endForm() ?>
              </div>
                </div>
          </div>
        <!-- End Panel Linearea Two --> 
      </div>
      </div>

<!-- 
        <div class="form-group">
            <label for="name">Language Name </label>
            <?= $this->tag->textField(['name', 'class' => 'form-control', 'placeholder' => 'required']) ?>
        </div>
        <div class="form-group">
            <label for="code">Language Code</label>
            <?= $this->tag->textField(['code', 'class' => 'form-control', 'placeholder' => 'required']) ?>
        </div>

   
        <div class="form-group">
            <label for="prefix">Country Prefix</label>
            <?= $this->tag->textField(['country_prefix', 'class' => 'form-control', 'placeholder' => 'required']) ?>
        </div>
         <div class="col-sm-3">
            <img src="/global/photos/placeholder.png" alt="category image" class="img-thumbnail" id="imagePreview">
        </div>
            <div class="col-sm-9">
                <div class="form-group">
                    <label for="image">Flag</label>  
                    <input type="file" name="image" id="image" accept="image/*" alt="cat_image">
                
                </div>
            </div>
    
    <div align="center">
        <?= $this->tag->submitButton(['Save', 'class' => 'btn btn-success', 'value' => 'Submit']) ?>
        <input type="reset" class="btn btn-default" value="Reset"/>
    </div> -->


<script>
$(document).ready(function(){
   /* $("#image").on("change", function()
    {
        var files = !!this.files ? this.files : [];
        if (!files.length || !window.FileReader) return; 
        if (/^image/.test( files[0].type)){ // only image file
            var reader = new FileReader(); // instance of the FileReader
            reader.readAsDataURL(files[0]); // read the local file
            reader.onloadend = function(){ // set image data as background of div
            $("#imagePreview").attr("src", this.result);
            }
        }
    });*/
    intializeValidation();
    $("#form-new").validate({
        rules: { 
                code: {required: true},
                name: {required: true},
                country_prefix: {required: true},
        },
        
    });
});
</script>