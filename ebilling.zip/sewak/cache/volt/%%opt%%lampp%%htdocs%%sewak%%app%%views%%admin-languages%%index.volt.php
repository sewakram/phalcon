<?php use Phalcon\Tag; ?>
<?= $this->getContent() ?>
<?= $this->tag->javascriptInclude('js/bootbox.min.js') ?>
<?= $this->tag->stylesheetLink('css/datatablescss/customdatables.css') ?>
<?= $this->tag->stylesheetLink('css/datatablescss/datatablesbootstrap.css') ?>
<div class="row" data-plugin="matchHeight" data-by-row="true">

 <div class="col-sm-12"> 
             <div class="widget widget-shadow" id="charLineareaTwo">
            <div class="widget-content padding-30 height-full">
                
                  <div style="padding-top:30px;">
                    
                    <div class="row">
                        <div class="col-lg-12">
                            <div class="example table-responsive">
                            <?php $i = 1; ?>
                            <?php $v30046411691iterated = false; ?><?php $v30046411691iterator = $data; $v30046411691incr = 0; $v30046411691loop = new stdClass(); $v30046411691loop->self = &$v30046411691loop; $v30046411691loop->length = count($v30046411691iterator); $v30046411691loop->index = 1; $v30046411691loop->index0 = 1; $v30046411691loop->revindex = $v30046411691loop->length; $v30046411691loop->revindex0 = $v30046411691loop->length - 1; ?><?php foreach ($v30046411691iterator as $languages) { ?><?php $v30046411691loop->first = ($v30046411691incr == 0); $v30046411691loop->index = $v30046411691incr + 1; $v30046411691loop->index0 = $v30046411691incr; $v30046411691loop->revindex = $v30046411691loop->length - $v30046411691incr; $v30046411691loop->revindex0 = $v30046411691loop->length - ($v30046411691incr + 1); $v30046411691loop->last = ($v30046411691incr == ($v30046411691loop->length - 1)); ?><?php $v30046411691iterated = true; ?>
                            <?php if ($v30046411691loop->first) { ?>

                        <table class="table table-bordered filtertable" data-selectable="selectable" data-row-selectable="true">
                            <thead>
                                  <tr style="background-color:#f5f5f5; vertical-align:middle;">
                                    <th class="width-50 manualcss">
                                      <span class="checkbox-custom checkbox-primary">
                                        <input class="selectable-all" type="checkbox">
                                        <label></label>
                                      </span>
                                    </th>
                                    <th><?= $t->_('Id') ?></th>
                                    <th><?= $t->_('Name') ?></th>
                                    <th><?= $t->_('Code') ?></th>
                                    <th><?= $t->_('Prefix') ?></th>
                                    <th><?= $t->_('Flag') ?></th> 
                                    <th class="text-nowrap text-center"><?= $t->_('Actions') ?></th>
                                 </tr>
                            </thead>
                             <tbody>
                            <?php } ?>

                            <tr style="vertical-align:middle;" id="<?= $languages->id ?>">
                                    <td class="manualcss">
                                      <span class="checkbox-custom checkbox-primary">
                                        <input class="selectable-item" type="checkbox" id="row-619" value="619">
                                        <label for="row-619"></label>
                                      </span>
                                    </td>
                                <td><?php echo $i; ?></td>
                                <td><?= $languages->name ?></td>   
                                <td><?= $languages->code ?></td>
                                <td><?= $languages->country_prefix ?></td>  
                                <td class="text-nowrap text-center"><?= $this->tag->image([$languages->flag_url . '?last=' . time(), 'alt' => 'flag', 'style' => 'width: 50px', 'class' => 'img-responsive img-rounded img-cat-max-width-limit text-center']) ?></td>
                                <td class="text-nowrap text-center">
                                  <a href="../admin-languages/editstring/<?php echo $languages->id; ?>" type="button" class="btn btn-sm btn-icon btn-flat btn-default" data-toggle="tooltip" 
                                      data-original-title="<?= $t->_('Edit') ?>">
                                        <i class="fa fa-pencil-square-o" aria-hidden="true"></i>Edit Strings
                                  </a>
                                        <!-- <a href="admin-languages/editstring/<?php //echo $languages->id; ?>" type="button" class="btn btn-sm btn-icon btn-flat btn-default" data-toggle="tooltip" 
                                      data-original-title="<?= $t->_('Edit language strings') ?>">
                                        <i class="icon md-label" aria-hidden="true"></i>
                                      </a> -->
									  <?php
										if($languages->id !=15)
										{
											
									   ?>
									   <button type="button" class="btn btn-md btn-icon btn-flat btn-danger" data-toggle="tooltip" data-original-title="<?= $t->_('Delete') ?>" onclick="return ConfirmDel(<?= $languages->id ?>)">Delete
                                     <i class="fa fa-window-close" aria-hidden="true"></i>  
                                      </button>
									   <?php 
										} 
										else{
										?> 
											<button type="button" class="btn btn-sm btn-icon btn-flat btn-danger avoid_btn" data-toggle=""	data-original-title="" disabled> Delete 
											</button>
										<?php
										}
										
									  ?>
                                      
                                </td>
                            </tr>
                            <?php $i++; ?>
                             <?php if ($v30046411691loop->last) { ?>
                             </tbody>
                  

                        </table>
                            <?php } ?>
                          <?php $v30046411691incr++; } if (!$v30046411691iterated) { ?>
                              No Orders are recorded
                          <?php } ?>
                        </div>
      
    
    </div>
     </div>
                   <!--  <div class="row">
                        <div class="col-md-7"></div>
                        <div class="col-md-5 text-right">
                            <nav>
                              <ul data-plugin="paginator" data-total="50">
                              </ul>
                            </nav>
                        </div>      
                    </div> -->
            </div>
              
              
              
          </div>
          </div>
        <!-- End Panel Linearea Two --> 
      </div>
      </div>
<script type="text/javascript">
  function ConfirmDel(url)
    {
    bootbox.confirm("<h3 class='boot_dialog text-danger'><?= $t->_('Are you sure?') ?></h3>", function(result) {
        if (result){
            $.ajax({
                  type: "POST",
                  url:"/admin-languages/delete/"+url,
                  dataType: "json",
                  success:  function(response){
                   /* console.log(response); */
                    if(response['msg']==='success'){
                          bootbox.alert('<h3 class="boot_dialog"><?= $t->_('Language is deleted successfully') ?>.<h3>');
                          $('#'+response['id']).remove();
                          console.log('#'+response['id']);
						  window.rowdatatable(url);
                    }else{
                          bootbox.alert('<h3 class="boot_dialog"><?= $t->_('Language is not deleted successfully') ?>.<h3><br><h4 class="text-danger boot_dialog">'+response['msg']+'<h4>');
                    } 
                  }
                });
        } 
        });
    }
</script>