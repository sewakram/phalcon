<?= $this->getContent() ?>

<!--<ul class="pager">
    <li class="previous">
        <?= $this->tag->linkTo(['products', '&larr; Go Back']) ?>
    </li>
    <li class="next">
        <?= $this->tag->linkTo(['products/new', 'Create products']) ?>
    </li>
</ul>-->
<div class="row"><br>

<div class="col-md-2">
<?= $this->tag->linkTo(['users/index', '&larr; Go Back', 'class' => 'btn btn-primary']) ?>
</div>
<div class="col-md-8"></div>
<div class="col-md-2">
<?= $this->tag->linkTo(['products/new/' . $userid, 'class' => 'btn btn-primary', 'Create product']) ?>
</div>
</div><br>
<?php $v24339968451iterated = false; ?><?php $v24339968451iterator = $page->items; $v24339968451incr = 0; $v24339968451loop = new stdClass(); $v24339968451loop->self = &$v24339968451loop; $v24339968451loop->length = count($v24339968451iterator); $v24339968451loop->index = 1; $v24339968451loop->index0 = 1; $v24339968451loop->revindex = $v24339968451loop->length; $v24339968451loop->revindex0 = $v24339968451loop->length - 1; ?><?php foreach ($v24339968451iterator as $product) { ?><?php $v24339968451loop->first = ($v24339968451incr == 0); $v24339968451loop->index = $v24339968451incr + 1; $v24339968451loop->index0 = $v24339968451incr; $v24339968451loop->revindex = $v24339968451loop->length - $v24339968451incr; $v24339968451loop->revindex0 = $v24339968451loop->length - ($v24339968451incr + 1); $v24339968451loop->last = ($v24339968451incr == ($v24339968451loop->length - 1)); ?><?php $v24339968451iterated = true; ?>
    <?php if ($v24339968451loop->first) { ?>
<table class="table table-bordered table-striped" align="center">
    <thead>
        <tr>
            <th>Id</th>
            <th>Product Type</th>
            <th>Name</th>
            <th>Price</th>
            <th>Active</th>
        </tr>
    </thead>
    <tbody>
    <?php } ?>
        <tr>
            <td><?= $product->id ?></td>
            <td><?= $product->getProductTypes()->name ?></td>
            <td><?= $product->name ?></td>
            <td>$<?= sprintf('%.2f', $product->price) ?></td>
            <td><?= $product->getActiveDetail() ?></td>
            <td width="7%"><?= $this->tag->linkTo(['products/edit/' . $product->id, '<i class="glyphicon glyphicon-edit"></i> Edit', 'class' => 'btn btn-default']) ?></td>
            <td width="7%"><?= $this->tag->linkTo(['products/delete/' . $product->id, '<i class="glyphicon glyphicon-remove"></i> Delete', 'class' => 'btn btn-default']) ?></td>
        </tr>
    <?php if ($v24339968451loop->last) { ?>
    </tbody>
    <tbody>
        <tr>
            <td colspan="7" align="right">
                <div class="btn-group">
                    <?= $this->tag->linkTo(['products/search', '<i class="icon-fast-backward"></i> First', 'class' => 'btn']) ?>
                    <?= $this->tag->linkTo(['products/search?page=' . $page->before, '<i class="icon-step-backward"></i> Previous', 'class' => 'btn']) ?>
                    <?= $this->tag->linkTo(['products/search?page=' . $page->next, '<i class="icon-step-forward"></i> Next', 'class' => 'btn']) ?>
                    <?= $this->tag->linkTo(['products/search?page=' . $page->last, '<i class="icon-fast-forward"></i> Last', 'class' => 'btn']) ?>
                    <span class="help-inline"><?= $page->current ?> of <?= $page->total_pages ?></span>
                </div>
            </td>
        </tr>
    </tbody>
</table>
    <?php } ?>
<?php $v24339968451incr++; } if (!$v24339968451iterated) { ?>
    No products are recorded
<?php } ?>
