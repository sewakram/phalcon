<div class="row">
<form method="post" autocomplete="off">

<div class="center scaffold">
<ul class="pager">
    <li class="previous pull-left">
        <?= $this->tag->linkTo(['users', '&larr; Go Back']) ?>
    </li>
    <li class="pull-right">
        <?= $this->tag->submitButton(['Save', 'class' => 'btn btn-success']) ?>
    </li>
</ul>

<?= $this->getContent() ?>

<div class="center scaffold">
    <h2>Create a User</h2>

    <div class="col-md-2 form-group">
           <span class="label-field"> <label for="name">Name</label></span>
        <?= $form->render('name', ['class' => 'form-control']) ?>
    </div>

    <div class="col-md-2 form-group">
           <span class="label-field"> <label for="email">E-Mail</label></span>
        <?= $form->render('email', ['class' => 'form-control']) ?>
    </div>

    <div class="col-md-2 form-group">
           <span class="label-field"> <label for="profilesId">Profile</label></span>
        <?= $form->render('profilesId', ['class' => 'form-control']) ?>
    </div>

</div>
</div>

</form>
</div>