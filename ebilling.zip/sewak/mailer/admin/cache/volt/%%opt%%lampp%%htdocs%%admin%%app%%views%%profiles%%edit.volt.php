
<form method="post" autocomplete="off">

<!--<ul class="pager">
    <li class="previous pull-left">
        <?= $this->tag->linkTo(['profiles', '&larr; Go Back']) ?>
    </li>
    <li class="pull-right">
        <?= $this->tag->submitButton(['Save', 'class' => 'btn btn-success']) ?>
    </li>
</ul>-->
<div class="row"><br>

<div class="col-md-10">
<?= $this->tag->linkTo(['profiles', '&larr; Go Back', 'class' => 'btn btn-primary']) ?>
</div>
<div class="col-md-2">
<?= $this->tag->submitButton(['Save', 'class' => 'btn btn-success']) ?>
</div>
</div><br>

<?= $this->getContent() ?>
<div class="row">
<div class="center scaffold">

    <h2>Edit profile</h2>

    <ul class="nav nav-tabs">
        <li class="active"><a href="#A" data-toggle="tab">Basic</a></li>
        <li><a href="#B" data-toggle="tab">Users</a></li>
    </ul>

    <div class="tabbable">
        <div class="tab-content">
            <div class="tab-pane active" id="A">

                <?= $form->render('id') ?>

                <div class="col-md-3 form-group">
           <span class="label-field"> <label for="name">Name</label>
                    <?= $form->render('name', ['class' => 'form-control']) ?>
                </div>

                <div class="col-md-3 form-group">
           <span class="label-field"> <label for="active">Active?</label>
                    <?= $form->render('active', ['class' => 'form-control']) ?>
                </div>

            </div>

            <div class="tab-pane" id="B">
                <p>
                    <table class="table table-bordered table-striped" align="center">
                        <thead>
                            <tr>
                                <th>Id</th>
                                <th>Name</th>
                                <th>Banned?</th>
                                <th>Suspended?</th>
                                <th>Active?</th>
                                <th colspan="2">Action</th>
                            </tr>
                        </thead>
                        <tbody>
                        <?php $v119841321iterated = false; ?><?php foreach ($profile->users as $user) { ?><?php $v119841321iterated = true; ?>
                            <tr>
                                <td><?= $user->id ?></td>
                                <td><?= $user->name ?></td>
                                <td><?= ($user->banned == 'Y' ? 'Yes' : 'No') ?></td>
                                <td><?= ($user->suspended == 'Y' ? 'Yes' : 'No') ?></td>
                                <td><?= ($user->active == 'Y' ? 'Yes' : 'No') ?></td>
                                <td width="12%"><?= $this->tag->linkTo(['users/edit/' . $user->id, '<i class="icon-pencil"></i> Edit', 'class' => 'btn']) ?></td>
                                
                            </tr>
                        <?php } if (!$v119841321iterated) { ?>
                            <tr><td colspan="3" align="center">There are no users assigned to this profile</td></tr>
                        <?php } ?>
                        </tbody>
                    </table>
                </p>
            </div>

        </div>
    </div>

    </form>
</div>