<?= $this->getContent() ?>

<ul class="pager">
    <li class="previous">
        <?= $this->tag->linkTo(['products', '&larr; Go Back']) ?>
    </li>
    <li class="next">
        <?= $this->tag->linkTo(['products/new', 'Create products']) ?>
    </li>
</ul>

<?php $v20406930921iterated = false; ?><?php $v20406930921iterator = $page->items; $v20406930921incr = 0; $v20406930921loop = new stdClass(); $v20406930921loop->self = &$v20406930921loop; $v20406930921loop->length = count($v20406930921iterator); $v20406930921loop->index = 1; $v20406930921loop->index0 = 1; $v20406930921loop->revindex = $v20406930921loop->length; $v20406930921loop->revindex0 = $v20406930921loop->length - 1; ?><?php foreach ($v20406930921iterator as $product) { ?><?php $v20406930921loop->first = ($v20406930921incr == 0); $v20406930921loop->index = $v20406930921incr + 1; $v20406930921loop->index0 = $v20406930921incr; $v20406930921loop->revindex = $v20406930921loop->length - $v20406930921incr; $v20406930921loop->revindex0 = $v20406930921loop->length - ($v20406930921incr + 1); $v20406930921loop->last = ($v20406930921incr == ($v20406930921loop->length - 1)); ?><?php $v20406930921iterated = true; ?>
    <?php if ($v20406930921loop->first) { ?>
<table class="table table-bordered table-striped" align="center">
    <thead>
        <tr>
            <th>Id</th>
            <th>Product Type</th>
            <th>Name</th>
            <th>Price</th>
            <th>Active</th>
        </tr>
    </thead>
    <tbody>
    <?php } ?>
        <tr>
            <td><?= $product->id ?></td>
            <td><?= $product->getProductTypes()->name ?></td>
            <td><?= $product->name ?></td>
            <td>$<?= sprintf('%.2f', $product->price) ?></td>
            <td><?= $product->getActiveDetail() ?></td>
            <td width="7%"><?= $this->tag->linkTo(['products/edit/' . $product->id, '<i class="glyphicon glyphicon-edit"></i> Edit', 'class' => 'btn btn-default']) ?></td>
            <td width="7%"><?= $this->tag->linkTo(['products/delete/' . $product->id, '<i class="glyphicon glyphicon-remove"></i> Delete', 'class' => 'btn btn-default']) ?></td>
        </tr>
    <?php if ($v20406930921loop->last) { ?>
    </tbody>
    <tbody>
        <tr>
            <td colspan="7" align="right">
                <div class="btn-group">
                    <?= $this->tag->linkTo(['products/search', '<i class="icon-fast-backward"></i> First', 'class' => 'btn']) ?>
                    <?= $this->tag->linkTo(['products/search?page=' . $page->before, '<i class="icon-step-backward"></i> Previous', 'class' => 'btn']) ?>
                    <?= $this->tag->linkTo(['products/search?page=' . $page->next, '<i class="icon-step-forward"></i> Next', 'class' => 'btn']) ?>
                    <?= $this->tag->linkTo(['products/search?page=' . $page->last, '<i class="icon-fast-forward"></i> Last', 'class' => 'btn']) ?>
                    <span class="help-inline"><?= $page->current ?> of <?= $page->total_pages ?></span>
                </div>
            </td>
        </tr>
    </tbody>
</table>
    <?php } ?>
<?php $v20406930921incr++; } if (!$v20406930921iterated) { ?>
    No products are recorded
<?php } ?>
