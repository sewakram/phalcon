<?= $this->getContent() ?>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-select/1.12.4/css/bootstrap-select.min.css">
<script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-select/1.12.4/js/bootstrap-select.min.js"></script>
<div align="right">
    <?= $this->tag->linkTo(['users/create', '<i class=\'icon-plus-sign\'></i> Create Users', 'class' => 'btn btn-primary']) ?>
</div>
<div class="row">
<form method="post" action="<?= $this->url->get('users/search') ?>" autocomplete="off">
    
   <div class="center scaffold">

        <h2>Search users</h2> 
    <div class="col-md-2 form-group">
           <span class="label-field"> <label for="id">Id</label></span>
            <?= $form->render('id') ?>
        </div>

        <div class="col-md-2 form-group">
           <span class="label-field"> <label for="name">Name</label></span>
            <?= $form->render('name') ?>
        </div>
        <div class="col-md-2 form-group">
           <span class="label-field"> <label for="email">E-Mail</label></span>
            <?= $form->render('email') ?>
        </div>

        <div class="col-md-2 form-group">
           <span class="label-field"> <label for="profilesId">Profile</label></span>
            <?= $form->render('profilesId', ['class' => 'form-control']) ?>
        </div>

        <br><div class="col-md-2 form-group">
            <?= $this->tag->submitButton(['Search', 'class' => 'btn btn-primary']) ?>
        </div>

</div>
</form>
</div>