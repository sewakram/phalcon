<?= $this->getContent() ?>

<!--<ul class="pager">
    <li class="previous pull-left">
        <?= $this->tag->linkTo(['profiles/index', '&larr; Go Back']) ?>
    </li>
    <li class="pull-right">
        <?= $this->tag->linkTo(['profiles/create', 'Create profiles', 'class' => 'btn btn-primary']) ?>
    </li>
</ul>-->
<div class="row"><br>

<div class="col-md-10">
<?= $this->tag->linkTo(['profiles/index', '&larr; Go Back', 'class' => 'btn btn-primary']) ?>
</div>
<div class="col-md-2">
<?= $this->tag->linkTo(['profiles/create', 'Create profiles', 'class' => 'btn btn-primary']) ?>
</div>
</div><br>
<?php $v13468355081iterated = false; ?><?php $v13468355081iterator = $page->items; $v13468355081incr = 0; $v13468355081loop = new stdClass(); $v13468355081loop->self = &$v13468355081loop; $v13468355081loop->length = count($v13468355081iterator); $v13468355081loop->index = 1; $v13468355081loop->index0 = 1; $v13468355081loop->revindex = $v13468355081loop->length; $v13468355081loop->revindex0 = $v13468355081loop->length - 1; ?><?php foreach ($v13468355081iterator as $profile) { ?><?php $v13468355081loop->first = ($v13468355081incr == 0); $v13468355081loop->index = $v13468355081incr + 1; $v13468355081loop->index0 = $v13468355081incr; $v13468355081loop->revindex = $v13468355081loop->length - $v13468355081incr; $v13468355081loop->revindex0 = $v13468355081loop->length - ($v13468355081incr + 1); $v13468355081loop->last = ($v13468355081incr == ($v13468355081loop->length - 1)); ?><?php $v13468355081iterated = true; ?>
<?php if ($v13468355081loop->first) { ?>
<table class="table table-bordered table-striped" align="center">
    <thead>
        <tr>
            <th>Id</th>
            <th>Name</th>
            <th>Active?</th>
            <th colspan="2">Action</th>
        </tr>
    </thead>
<?php } ?>
    <tbody>
        <tr>
            <td><?= $profile->id ?></td>
            <td><?= $profile->name ?></td>
            <td><?= ($profile->active == 'Y' ? 'Yes' : 'No') ?></td>
            <td width="12%"><?= $this->tag->linkTo(['profiles/edit/' . $profile->id, '<i class="icon-pencil"></i> Edit', 'class' => 'btn']) ?></td>
            <td width="12%"><?= $this->tag->linkTo(['profiles/delete/' . $profile->id, '<i class="icon-remove"></i> Delete', 'class' => 'btn']) ?></td>
        </tr>
    </tbody>
<?php if ($v13468355081loop->last) { ?>
    <tbody>
        <tr>
            <td colspan="10" align="right">
                <div class="btn-group">
                    <?= $this->tag->linkTo(['profiles/search', '<i class="icon-fast-backward"></i> First', 'class' => 'btn']) ?>
                    <?= $this->tag->linkTo(['profiles/search?page=' . $page->before, '<i class="icon-step-backward"></i> Previous', 'class' => 'btn ']) ?>
                    <?= $this->tag->linkTo(['profiles/search?page=' . $page->next, '<i class="icon-step-forward"></i> Next', 'class' => 'btn']) ?>
                    <?= $this->tag->linkTo(['profiles/search?page=' . $page->last, '<i class="icon-fast-forward"></i> Last', 'class' => 'btn']) ?>
                    <span class="help-inline"><?= $page->current ?>/<?= $page->total_pages ?></span>
                </div>
            </td>
        </tr>
    <tbody>
</table>
<?php } ?>
<?php $v13468355081incr++; } if (!$v13468355081iterated) { ?>
    No profiles are recorded
<?php } ?>
