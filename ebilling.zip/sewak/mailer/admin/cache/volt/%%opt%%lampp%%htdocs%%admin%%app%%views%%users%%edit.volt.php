
<form method="post" autocomplete="off">

<ul class="pager">
    <li class="previous pull-left">
        <?= $this->tag->linkTo(['users', '&larr; Go Back']) ?>
    </li>
    <li class="pull-right">
        <?= $this->tag->submitButton(['Save', 'class' => 'btn btn-big btn-success']) ?>
    </li>
</ul>

<?= $this->getContent() ?>

<div class="center scaffold">
    <h2>Edit users</h2>

    <ul class="nav nav-tabs">
        <li class="active"><a href="#A" data-toggle="tab">Basic</a></li>
        <li><a href="#B" data-toggle="tab">Successful Logins</a></li>
        <li><a href="#C" data-toggle="tab">Password Changes</a></li>
        <li><a href="#D" data-toggle="tab">Reset Passwords</a></li>
    </ul>

<div class="tabbable">
    <div class="tab-content">
        <div class="tab-pane active" id="A">

            <?= $form->render('id') ?>

            
                <div class="row">
                 <div class="col-md-2 form-group">
           <span class="label-field"><label for="name">Name</label></span>
                    <?= $form->render('name', ['class' => 'form-control']) ?>
                </div>

                 <div class="col-md-2 form-group">
           <span class="label-field"><label for="profilesId">Profile</label></span>
                    <?= $form->render('profilesId', ['class' => 'form-control']) ?>
                </div>

                 <div class="col-md-2 form-group">
           <span class="label-field"><label for="suspended">Suspended?</label></span>
                    <?= $form->render('suspended', ['class' => 'form-control']) ?>
                </div>

           

            

                <div class="col-md-2 form-group">
           <span class="label-field"><label for="email">E-Mail</label>
                    <?= $form->render('email', ['class' => 'form-control']) ?>
                </div>

                <div class="col-md-2 form-group">
           <span class="label-field"><label for="banned">Banned?</label>
                    <?= $form->render('banned', ['class' => 'form-control']) ?>
                </div>

                <div class="col-md-2 form-group">
           <span class="label-field"><label for="active">Confirmed?</label>
                    <?= $form->render('active', ['class' => 'form-control']) ?>
                </div>
            </div>
            
        </div>

        <div class="tab-pane" id="B">
            <p>
                <table class="table table-bordered table-striped" align="center">
                    <thead>
                        <tr>
                            <th>Id</th>
                            <th>IP Address</th>
                            <th>User Agent</th>
                        </tr>
                    </thead>
                    <tbody>
                    <?php $v15692821301iterated = false; ?><?php foreach ($user->successLogins as $login) { ?><?php $v15692821301iterated = true; ?>
                        <tr>
                            <td><?= $login->id ?></td>
                            <td><?= $login->ipAddress ?></td>
                            <td><?= $login->userAgent ?></td>
                        </tr>
                    <?php } if (!$v15692821301iterated) { ?>
                        <tr><td colspan="3" align="center">User does not have successfull logins</td></tr>
                    <?php } ?>
                    </tbody>
                </table>
            </p>
        </div>

        <div class="tab-pane" id="C">
            <p>
                <table class="table table-bordered table-striped" align="center">
                    <thead>
                        <tr>
                            <th>Id</th>
                            <th>IP Address</th>
                            <th>User Agent</th>
                            <th>Date</th>
                        </tr>
                    </thead>
                    <tbody>
                    <?php $v15692821301iterated = false; ?><?php foreach ($user->passwordChanges as $change) { ?><?php $v15692821301iterated = true; ?>
                        <tr>
                            <td><?= $change->id ?></td>
                            <td><?= $change->ipAddress ?></td>
                            <td><?= $change->userAgent ?></td>
                            <td><?= date('Y-m-d H:i:s', $change->createdAt) ?></td>
                        </tr>
                    <?php } if (!$v15692821301iterated) { ?>
                        <tr><td colspan="3" align="center">User has not changed his/her password</td></tr>
                    <?php } ?>
                    </tbody>
                </table>
            </p>
        </div>

        <div class="tab-pane" id="D">
            <p>
            
                <table class="table table-bordered table-striped" align="center">
                    <thead>
                        <tr>
                            <th>Id</th>
                            <th>Created Date</th>
                            <th>Email</th>
                            <th>Password</th>
                            
                        </tr>
                    </thead>
                    <tbody>
                    <?php 
                    
                    foreach($qry as $reset)
                       
                    {
                    ?>
                        <tr>
                            <th><?php echo $reset->id;?></th>
                            <th><?php echo date("Y-m-d H:i:s", $reset->createdAt) ;?></th>
                            <th><?php echo $reset->email; ?></th>
                            <th><input type="text" class="form-control" value="<?php echo $reset->reset; ?>"> </th>
                            
                        </tr>
                    <?php 
                }?>
                    </tbody>
                </table>
                
            </p>
        </div>

    </div>
</div>

    </form>
