<?= $this->getContent() ?>

<ul class="pager">
    <li class="previous pull-left">
        <?= $this->tag->linkTo(['companies/index', '&larr; Go Back']) ?>
    </li>
    <li class="pull-right">
        <?= $this->tag->linkTo(['companies/new', 'Create companies']) ?>
    </li>
</ul>

<?php $v91046551iterated = false; ?><?php $v91046551iterator = $page->items; $v91046551incr = 0; $v91046551loop = new stdClass(); $v91046551loop->self = &$v91046551loop; $v91046551loop->length = count($v91046551iterator); $v91046551loop->index = 1; $v91046551loop->index0 = 1; $v91046551loop->revindex = $v91046551loop->length; $v91046551loop->revindex0 = $v91046551loop->length - 1; ?><?php foreach ($v91046551iterator as $company) { ?><?php $v91046551loop->first = ($v91046551incr == 0); $v91046551loop->index = $v91046551incr + 1; $v91046551loop->index0 = $v91046551incr; $v91046551loop->revindex = $v91046551loop->length - $v91046551incr; $v91046551loop->revindex0 = $v91046551loop->length - ($v91046551incr + 1); $v91046551loop->last = ($v91046551incr == ($v91046551loop->length - 1)); ?><?php $v91046551iterated = true; ?>
<?php if ($v91046551loop->first) { ?>
<table class="table table-bordered table-striped" align="center">
    <thead>
        <tr>
            <th>Id</th>
            <th>Name</th>
            <th>Telephone</th>
            <th>Address</th>
            <th>City</th>
        </tr>
    </thead>
<?php } ?>
    <tbody>
        <tr>
            <td><?= $company->id ?></td>
            <td><?= $company->name ?></td>
            <td><?= $company->telephone ?></td>
            <td><?= $company->address ?></td>
            <td><?= $company->city ?></td>
            <td width="7%"><?= $this->tag->linkTo(['companies/edit/' . $company->id, '<i class="glyphicon glyphicon-edit"></i> Edit', 'class' => 'btn btn-default']) ?></td>
            <td width="7%"><?= $this->tag->linkTo(['companies/delete/' . $company->id, '<i class="glyphicon glyphicon-remove"></i> Delete', 'class' => 'btn btn-default']) ?></td>
        </tr>
    </tbody>
<?php if ($v91046551loop->last) { ?>
    <tbody>
        <tr>
            <td colspan="7" align="right">
                <div class="btn-group">
                    <?= $this->tag->linkTo(['companies/search', '<i class="icon-fast-backward"></i> First', 'class' => 'btn btn-default']) ?>
                    <?= $this->tag->linkTo(['companies/search?page=' . $page->before, '<i class="icon-step-backward"></i> Previous', 'class' => 'btn btn-default']) ?>
                    <?= $this->tag->linkTo(['companies/search?page=' . $page->next, '<i class="icon-step-forward"></i> Next', 'class' => 'btn btn-default']) ?>
                    <?= $this->tag->linkTo(['companies/search?page=' . $page->last, '<i class="icon-fast-forward"></i> Last', 'class' => 'btn btn-default']) ?>
                    <span class="help-inline"><?= $page->current ?>/<?= $page->total_pages ?></span>
                </div>
            </td>
        </tr>
    <tbody>
</table>
<?php } ?>
<?php $v91046551incr++; } if (!$v91046551iterated) { ?>
    No companies are recorded
<?php } ?>
