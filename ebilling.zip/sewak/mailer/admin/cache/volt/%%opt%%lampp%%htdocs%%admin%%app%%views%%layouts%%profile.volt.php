


<div align="center">
    <?= $this->getContent() ?>
</div>
