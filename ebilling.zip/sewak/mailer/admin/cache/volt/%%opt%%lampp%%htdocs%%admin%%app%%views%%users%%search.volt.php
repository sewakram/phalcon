<?= $this->getContent() ?>

<!--<ul class="pager">
    <li class="previous pull-left">
        <?= $this->tag->linkTo(['users/index', '&larr; Go Back']) ?>
    </li>
    <li class="pull-right">
        <?= $this->tag->linkTo(['users/create', 'Create users', 'class' => 'btn btn-primary']) ?>
    </li>
</ul>-->
<div class="row"><br>

<div class="col-md-10">
<?= $this->tag->linkTo(['users/index', '&larr; Go Back', 'class' => 'btn btn-primary']) ?>
</div>
<div class="col-md-2">
<?= $this->tag->linkTo(['users/create', 'Create users', 'class' => 'btn btn-primary']) ?>
</div>
</div><br>
<?php $v7322734101iterated = false; ?><?php $v7322734101iterator = $page->items; $v7322734101incr = 0; $v7322734101loop = new stdClass(); $v7322734101loop->self = &$v7322734101loop; $v7322734101loop->length = count($v7322734101iterator); $v7322734101loop->index = 1; $v7322734101loop->index0 = 1; $v7322734101loop->revindex = $v7322734101loop->length; $v7322734101loop->revindex0 = $v7322734101loop->length - 1; ?><?php foreach ($v7322734101iterator as $user) { ?><?php $v7322734101loop->first = ($v7322734101incr == 0); $v7322734101loop->index = $v7322734101incr + 1; $v7322734101loop->index0 = $v7322734101incr; $v7322734101loop->revindex = $v7322734101loop->length - $v7322734101incr; $v7322734101loop->revindex0 = $v7322734101loop->length - ($v7322734101incr + 1); $v7322734101loop->last = ($v7322734101incr == ($v7322734101loop->length - 1)); ?><?php $v7322734101iterated = true; ?>
<?php if ($v7322734101loop->first) { ?>
<table class="table table-bordered table-striped" align="center">
    <thead>
        <tr>
            <th>Id</th>
            <th>Name</th>
            <th>Email</th>
            <th>Profile</th>
            <th>Banned?</th>
            <th>Suspended?</th>
            <th>Confirmed?</th>
            <th colspan="5">Action</th>
        </tr>
    </thead>
<?php } ?>
    <tbody>
        <tr>
            <td><?= $user->id ?></td>
            <td><?= $user->name ?></td>
            <td><?= $user->email ?></td>
            <td><?= $user->profile->name ?></td>
            <td><?= ($user->banned == 'Y' ? 'Yes' : 'No') ?></td>
            <td><?= ($user->suspended == 'Y' ? 'Yes' : 'No') ?></td>
            <td><?= ($user->active == 'Y' ? 'Yes' : 'No') ?></td>
            <td width="12%"><?= $this->tag->linkTo(['users/edit/' . $user->id, '<i class="icon-pencil"></i> Edit', 'class' => 'btn']) ?></td>
            <td width="12%"><?= $this->tag->linkTo(['invoices/adminindex/' . $user->id, '<i class="icon-pencil"></i> Invoices', 'class' => 'btn']) ?></td>
            <td width="12%"><?= $this->tag->linkTo(['companies/adminsearch/' . $user->id, '<i class="icon-pencil"></i> Customers', 'class' => 'btn']) ?></td>
            <td width="12%"><?= $this->tag->linkTo(['products/adminsearch/' . $user->id, '<i class="icon-pencil"></i> Products', 'class' => 'btn']) ?></td>
            <td width="12%"><?= $this->tag->linkTo(['producttypes/adminsearch/' . $user->id, '<i class="icon-pencil"></i> Stores', 'class' => 'btn']) ?></td>
        </tr>
    </tbody>
<?php if ($v7322734101loop->last) { ?>
    <tbody>
        <tr>
            <td colspan="10" align="right">
                <div class="btn-group">
                    <?= $this->tag->linkTo(['users/search', '<i class="icon-fast-backward"></i> First', 'class' => 'btn']) ?>
                    <?= $this->tag->linkTo(['users/search?page=' . $page->before, '<i class="icon-step-backward"></i> Previous', 'class' => 'btn ']) ?>
                    <?= $this->tag->linkTo(['users/search?page=' . $page->next, '<i class="icon-step-forward"></i> Next', 'class' => 'btn']) ?>
                    <?= $this->tag->linkTo(['users/search?page=' . $page->last, '<i class="icon-fast-forward"></i> Last', 'class' => 'btn']) ?>
                    <span class="help-inline"><?= $page->current ?>/<?= $page->total_pages ?></span>
                </div>
            </td>
        </tr>
    <tbody>
</table>
<?php } ?>
<?php $v7322734101incr++; } if (!$v7322734101iterated) { ?>
    No users are recorded
<?php } ?>
