<?= $this->getContent() ?>

<div align="right">
    <?= $this->tag->linkTo(['profiles/create', '<i class=\'icon-plus-sign\'></i> Create Profiles', 'class' => 'btn btn-primary']) ?>
</div>

<form method="post" action="<?= $this->url->get('profiles/search') ?>" autocomplete="off">
    <div class="row">
    <div class="center scaffold">

        <h2>Search profiles</h2><br>

        <div class="col-md-3 form-group">
           <span class="label-field"> <label for="id">Id</label></span>
            <?= $form->render('id') ?>
        </div>

        <div class="col-md-3 form-group">
           <span class="label-field"> <label for="name">Name</label></span>
            <?= $form->render('name') ?>
        </div>

        <div class="col-md-2 form-group">
            <?= $this->tag->submitButton(['Search', 'class' => 'btn btn-primary']) ?>
        </div>

    </div>
    </div>

</form>