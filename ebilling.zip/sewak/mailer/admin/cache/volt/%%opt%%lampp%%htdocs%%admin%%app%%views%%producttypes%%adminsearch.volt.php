<?= $this->getContent() ?>

<!--<ul class="pager">
    <li class="previous">
        <?= $this->tag->linkTo(['producttypes', '&larr; Go Back']) ?>
    </li>
    <li class="next">
        <?= $this->tag->linkTo(['producttypes/new', 'Create product types', 'class' => 'btn btn-primary']) ?>
    </li>
</ul>-->
<div class="row"><br>

<div class="col-md-2">
<?= $this->tag->linkTo(['producttypes', '&larr; Go Back', 'class' => 'btn btn-primary']) ?>
</div>
<div class="col-md-8"></div>
<div class="col-md-2">
<?= $this->tag->linkTo(['producttypes/new/' . $userid, 'class' => 'btn btn-primary', 'Create product']) ?>
</div>
</div><br>
<?php $v42383500631iterated = false; ?><?php $v42383500631iterator = $page->items; $v42383500631incr = 0; $v42383500631loop = new stdClass(); $v42383500631loop->self = &$v42383500631loop; $v42383500631loop->length = count($v42383500631iterator); $v42383500631loop->index = 1; $v42383500631loop->index0 = 1; $v42383500631loop->revindex = $v42383500631loop->length; $v42383500631loop->revindex0 = $v42383500631loop->length - 1; ?><?php foreach ($v42383500631iterator as $producttype) { ?><?php $v42383500631loop->first = ($v42383500631incr == 0); $v42383500631loop->index = $v42383500631incr + 1; $v42383500631loop->index0 = $v42383500631incr; $v42383500631loop->revindex = $v42383500631loop->length - $v42383500631incr; $v42383500631loop->revindex0 = $v42383500631loop->length - ($v42383500631incr + 1); $v42383500631loop->last = ($v42383500631incr == ($v42383500631loop->length - 1)); ?><?php $v42383500631iterated = true; ?>
    <?php if ($v42383500631loop->first) { ?>
<table class="table table-bordered table-striped" align="center">
    <thead>
        <tr>
            <th>Id</th>
            <th>Name</th>
            <th colspan="2">Action</th>
        </tr>
    </thead>
    <tbody>
    <?php } ?>
        <tr>
            <td><?= $producttype->id ?></td>
            <td><?= $producttype->name ?></td>
            <td width="7%"><?= $this->tag->linkTo(['producttypes/edit/' . $producttype->id, '<i class="glyphicon glyphicon-edit"></i> Edit', 'class' => 'btn btn-default']) ?></td>
            <td width="7%"><?= $this->tag->linkTo(['producttypes/delete/' . $producttype->id, '<i class="glyphicon glyphicon-remove"></i> Delete', 'class' => 'btn btn-default']) ?></td>
        </tr>
    <?php if ($v42383500631loop->last) { ?>
    </tbody>
    <tbody>
        <tr>
            <td colspan="4" align="right">
                <div class="btn-group">
                    <?= $this->tag->linkTo(['producttypes/search', '<i class="icon-fast-backward"></i> First', 'class' => 'btn']) ?>
                    <?= $this->tag->linkTo(['producttypes/search?page=' . $page->before, '<i class="icon-step-backward"></i> Previous', 'class' => 'btn']) ?>
                    <?= $this->tag->linkTo(['producttypes/search?page=' . $page->next, '<i class="icon-step-forward"></i> Next', 'class' => 'btn']) ?>
                    <?= $this->tag->linkTo(['producttypes/search?page=' . $page->last, '<i class="icon-fast-forward"></i> Last', 'class' => 'btn']) ?>
                    <span class="help-inline"><?= $page->current ?>/<?= $page->total_pages ?></span>
                </div>
            </td>
        </tr>
    <tbody>
</table>
    <?php } ?>
<?php $v42383500631incr++; } if (!$v42383500631iterated) { ?>
    No product types are recorded
<?php } ?>
