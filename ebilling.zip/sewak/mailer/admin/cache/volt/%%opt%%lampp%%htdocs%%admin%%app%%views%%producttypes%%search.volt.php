<?= $this->getContent() ?>

<ul class="pager">
    <li class="previous">
        <?= $this->tag->linkTo(['producttypes', '&larr; Go Back']) ?>
    </li>
    <li class="next">
        <?= $this->tag->linkTo(['producttypes/new', 'Create product types', 'class' => 'btn btn-primary']) ?>
    </li>
</ul>

<?php $v36696225021iterated = false; ?><?php $v36696225021iterator = $page->items; $v36696225021incr = 0; $v36696225021loop = new stdClass(); $v36696225021loop->self = &$v36696225021loop; $v36696225021loop->length = count($v36696225021iterator); $v36696225021loop->index = 1; $v36696225021loop->index0 = 1; $v36696225021loop->revindex = $v36696225021loop->length; $v36696225021loop->revindex0 = $v36696225021loop->length - 1; ?><?php foreach ($v36696225021iterator as $producttype) { ?><?php $v36696225021loop->first = ($v36696225021incr == 0); $v36696225021loop->index = $v36696225021incr + 1; $v36696225021loop->index0 = $v36696225021incr; $v36696225021loop->revindex = $v36696225021loop->length - $v36696225021incr; $v36696225021loop->revindex0 = $v36696225021loop->length - ($v36696225021incr + 1); $v36696225021loop->last = ($v36696225021incr == ($v36696225021loop->length - 1)); ?><?php $v36696225021iterated = true; ?>
    <?php if ($v36696225021loop->first) { ?>
<table class="table table-bordered table-striped" align="center">
    <thead>
        <tr>
            <th>Id</th>
            <th>Name</th>
        </tr>
    </thead>
    <tbody>
    <?php } ?>
        <tr>
            <td><?= $producttype->id ?></td>
            <td><?= $producttype->name ?></td>
            <td width="7%"><?= $this->tag->linkTo(['producttypes/edit/' . $producttype->id, '<i class="glyphicon glyphicon-edit"></i> Edit', 'class' => 'btn btn-default']) ?></td>
            <td width="7%"><?= $this->tag->linkTo(['producttypes/delete/' . $producttype->id, '<i class="glyphicon glyphicon-remove"></i> Delete', 'class' => 'btn btn-default']) ?></td>
        </tr>
    <?php if ($v36696225021loop->last) { ?>
    </tbody>
    <tbody>
        <tr>
            <td colspan="4" align="right">
                <div class="btn-group">
                    <?= $this->tag->linkTo(['producttypes/search', '<i class="icon-fast-backward"></i> First', 'class' => 'btn']) ?>
                    <?= $this->tag->linkTo(['producttypes/search?page=' . $page->before, '<i class="icon-step-backward"></i> Previous', 'class' => 'btn']) ?>
                    <?= $this->tag->linkTo(['producttypes/search?page=' . $page->next, '<i class="icon-step-forward"></i> Next', 'class' => 'btn']) ?>
                    <?= $this->tag->linkTo(['producttypes/search?page=' . $page->last, '<i class="icon-fast-forward"></i> Last', 'class' => 'btn']) ?>
                    <span class="help-inline"><?= $page->current ?>/<?= $page->total_pages ?></span>
                </div>
            </td>
        </tr>
    <tbody>
</table>
    <?php } ?>
<?php $v36696225021incr++; } if (!$v36696225021iterated) { ?>
    No product types are recorded
<?php } ?>
