<?= $this->getContent() ?>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-select/1.12.4/css/bootstrap-select.min.css">
<script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-select/1.12.4/js/bootstrap-select.min.js"></script>
<style type="text/css">
    @import url(//maxcdn.bootstrapcdn.com/font-awesome/4.2.0/css/font-awesome.min.css);

hr {
  height: 4px;
  margin-left: 15px;
  margin-bottom:-3px;
}

.hr-warning{
  background-image: -webkit-linear-gradient(left, rgba(210,105,30,.8), rgba(210,105,30,.6), rgba(0,0,0,0));
}
.hr-success{
  background-image: -webkit-linear-gradient(left, rgba(15,157,88,.8), rgba(15, 157, 88,.6), rgba(0,0,0,0));
}
.hr-primary{
  background-image: -webkit-linear-gradient(left, rgba(66,133,244,.8), rgba(66, 133, 244,.6), rgba(0,0,0,0));
}
.hr-danger{
  background-image: -webkit-linear-gradient(left, rgba(244,67,54,.8), rgba(244,67,54,.6), rgba(0,0,0,0));
}
</style>
<style>
.loader {
  border: 16px solid #f3f3f3;
  border-radius: 50%;
  border-top: 16px solid #3498db;
  width: 120px;
  height: 120px;
  -webkit-animation: spin 2s linear infinite; /* Safari */
  animation: spin 2s linear infinite;
}

/* Safari */
@-webkit-keyframes spin {
  0% { -webkit-transform: rotate(0deg); }
  100% { -webkit-transform: rotate(360deg); }
}

@keyframes spin {
  0% { transform: rotate(0deg); }
  100% { transform: rotate(360deg); }
}
</style>
<?= $this->tag->form(['']) ?>

   
<div class="row"><br>
<div class="col-md-2">
<?= $this->tag->linkTo(['invoices', '&larr; Go Back', 'class' => 'btn btn-primary']) ?>
</div>
<div class="col-md-8">
</div>
<div class="col-md-2">
<button type="button" class="btn btn-primary" onclick="savedata()">Save</button>
</div>
</div><br>
<h2>edit_invoice</h2>
  <div id="loader" class="hide"></div>
    <fieldset>

        <?php foreach ($form as $element) { ?>
        
        <?php if (is_a($element, 'Phalcon\Forms\Element\Hidden')) { ?>
            <?= $element ?>
        <?php } else { ?>
            <div class="col-md-3 form-group">
            <span class="label-field"><?= $element->label() ?></span>
            <?= $element->render(['class' => 'form-control']) ?>
            </div>
            
        <?php } ?>
    <?php } ?>

    </fieldset>
    <fieldset>

<!-- Products -->
<!-- <hr class="hr-primary" /> -->
 <!--Table-->
<div class="row padding-top-15">

    <div class="col-lg-12">
    
        <table class="table table-responsive product_list">

          <thead class="cart-table-header">

            <tr  >
                <td><span style="font-weight: bold;">Product Type</span></td>
                <td><span style="font-weight: bold;">Product</span></td>
                <!-- <td align="center"><span style="font-weight: bold;">Stores Stock</span></td> -->
                <td align="center"><span style="font-weight: bold;">Price</span></td>
                <td><span style="font-weight: bold;">Quantity</span></td>
                <td align="center"><span style="font-weight: bold;">Subtotal</span></td>
                <td align="center"></td>
            </tr>
           </thead>
           <tbody>
            <?php
              //echo '<pre>';print_r($items);exit();
             foreach($items as $v)
                    {
                      
                    ?>
            <tr id="1">
            <td id="selectty">
                    
                  <input type="Hidden" value="<?php echo $v->i->id; ?>" id="pid" name="pname">
                   <select class="form-control" id="producttype" name="producttype" data-type="producttype" onchange="getProducts(this)">
                     
                    
                  
                    <option value="0">Select product type</option>
                    <?php
                    foreach($prodtype as $k=>$ve)
                    {
                    ?>
                    <option value="<?php echo $ve->id;?>" <?php echo $v->t->id==$ve->id ? 'selected':'';?> ><?php echo $ve->name; ?></option>
                    <?php
                    }
                    ?>
                    </select>
                </td>
                <td id="select">

                      <select class="form-control" onchange="getProducts(this)" id="selected_products" name="selectedproducts" data-type="products">
                    <!-- <option value="0">Select product</option> -->
                     <?php
                     //$sum='';
                    foreach($products as $p)
                    {
                     // $sum += $v->i->total;
                      if($p->product_types_id==$v->t->id){
                    ?>
                     <option value="<?php echo $p->id;?>" <?php echo $p->id==$v->i->name?'selected':''?> ><?php echo $p->name; ?></option>
                     <?php
                   }
                    }
                    ?>
                    </select>
                    
                </td>
                <!-- <td id="stock" align="center"><span class="amount-sent" data-type="stock" style="font-size:16px;" id="store_stock"></span> --><!-- <input type="text" class="form-control" readonly="readonly" id="store_stock" name="store_stock"> --><!-- </td> -->
                <td id="price1" align="center"><span class="amount-sent" data-type="price1" style="font-size:16px;" id="price"><?php echo $v->i->price; ?></span></td>
                <td id="qty" ><input type="text" value="<?php echo $v->i->qty; ?>" class="form-control" onkeyup="getCal(this)" data-type="qty" id="myinput" placeholder="0" style="font-size:20px;" name="myinput"></td>
                <td id="subt" align="center">Rs.<span id="subtotal" data-type="subt" class="amount-sent" style="font-size:16px;" ><span id="subtotal_get"><?php echo $v->i->total; ?></span></span></td>
                <td align="center">
                <button type="button" class="btn btn-sm btn-danger" data-toggle="tooltip"
                  data-original-title="Add another" id="add_html" onclick="return removeanother(1,this);">
                <span class="glyphicon glyphicon-remove" aria-hidden="true"></span>
                </button></td>
            </tr>
            <?php
             }
             ?>

           </tbody>
        </table>
            
    </div>
    <div class="col-lg-12">
        <button type="button" class="btn btn-sm btn-success add_html"  id="add_html">
        ADD ANOTHER
        </button>
    </div>
</div>
<!--// Table-->
<div class="row">
<div class="col-md-10">
  
</div>
           <div class="col-md-1">
            <span style="font-size:16px;"> CGST(%) </span>
            <input type="text" id="cgst" onkeyup="getCal()" name="cgst" class="form-control" value="<?php echo !empty($product->cgst)?$product->cgst:''; ?>">
            </div>
            <div class="col-md-1">
              <span style="font-size:16px;"> SGST(%) </span>
             <input type="text" id="sgst" onkeyup="getCal()" name="sgst" class="form-control" value="<?php echo !empty($product->sgst)?$product->sgst:''; ?>">
            </div>
            
</div>
<div class="row padding-top-25">
<div class="col-md-9"></div>
    <div class="col-md-3">
        <div class="text-right">
             
            <span style="font-size: 20px; font-weight: 300; color:#a0a0a0;"> Sub Total Rs.</span>
            <span id="gtotal" class="text-genba" style="font-size: 20px; font-weight: 300;"> <!-- <?php //echo $sum ?>  --></span><br />
            
            <span style="font-size: 20px; font-weight: 300; color:#a0a0a0;"> Total Amount Rs.</span>
            <span id="gtotalamt" class="text-genba" style="font-size: 20px; font-weight: 300;"><!-- <?php// echo $amount; ?> --> </span><br />
            
        </div>
    </div>
</div>   
        
    </fieldset>

</form>
<script type="text/javascript">
$(document).ready(function(){
getCal();
//console.log($('select[data-plugin=selectpicker]'));
$.getScript('https://cdnjs.cloudflare.com/ajax/libs/bootstrap-select/1.12.4/js/bootstrap-select.min.js',function(){
    //$('.selectpicker').selectpicker();    
});

$("#cname").attr('readonly',true);
$("#cnumber").attr('readonly',true);
$("#caddress").attr('readonly',true);
$("#ccity").attr('readonly',true);
var fomdata={};

//////////////////////////////////////////////////////////////////////////////////////
$("#cname").change(function () {
    var mydata = $(this).val();
    var cust_id=$("#cname").val();

    $.ajax({
        type: "POST",
        url: "findcustomers?customer_id="+cust_id+"",
        data: {
            cust:mydata // as you are getting in php $_POST['action1'] 
        },
        dataType : "json",
        success: function(response) {
        responses=response.fomdata;
           console.log(responses);
           //alert(responses.name);
             $("#cname").val(responses.name);
             $("#cnumber").val(responses.telephone);
             $("#caddress").val(responses.address);
             $("#ccity").val(responses.city);
            
            }
        });
    });

/////////////////////////////////////////////////////////////////////////////////////
$('.add_html').on('click', function(id,this_ref){
  // alert("hi");

    if($('table.product_list tbody tr').is(':not(:visible)')==true && $('table.product_list tbody tr:eq(0)').hasClass('data-call')!=true)
        {
           $('table.product_list tbody tr').show();    
        }
        else{
        var id = $('table tbody tr').length;
        id = parseInt(id);
        id++;
        var newhtml = $('table.product_list tbody tr:eq(0)').html();
        // console.log(newhtml);
         var newnode = $("<tr id='"+id+"'>");
         newnode.html(newhtml);
         $('table tbody tr:last').after(newnode);
         $('tr#'+id).find('select[data-type="products"]');//.attr({id:"nw",name:"Opens in a new window"})
         $('tr#'+id).find('select[data-type="producttype"]');
         var oldval = $('tr#'+id).prev('tr').find('input#pid').val();
         $('tr#'+id).find('input#pid').val(parseInt(oldval)+1);
         //$('tr#'+id).find('span[data-type="stock"]').text('0');
         $('tr#'+id).find('span[data-type="price1"]').text('0');
         $('tr#'+id).find('span[data-type="subt"]').text('0');
         $('tr#'+id).find('input[data-type="qty"]').val(0);
         
         $('#select_product_'+id+'').change(function () {
    var namedata = $(this).val();
    var prod_id=$('#select_product_'+id+'').val();

    $.ajax({
        type: "POST",
        url: "findproducts?prod_id="+prod_id+"",
        data: {
            pname:namedata // as you are getting in php $_POST['action1'] 
        },
        dataType : "json",
        success: function(response) {
        responses=response.proddata;
        
            //alert(responses.qty);
             //$('#stock_'+id+'').text(responses.qty);
             $('#price_'+id+'').text(responses.price);
             //$('#myinput_'+id+'').text(responses.price);
             //$('#subtotal_'+id+'').text(responses.price);
            
            
            }
        });
    });
        //set value by product end
       
       }

    
});

});

function getCal(qty=null){  
   // $('input').on('keyup', function(){
    var tr_ref = $(qty).parents('tr');

   var gtotal = [];
    var x = $(qty).val();

    var store_stock = $(tr_ref).find('span[data-type="stock"]').text();
   // var store_stock = $('#stock_'+id+'').text();
    store_stock = parseInt(store_stock);
    var status = parseInt(x)>parseInt(store_stock) ?  false :  true;
    if(!status)
    {
       alert('Product not available');
       $(qty).val('');
       $(tr_ref).find('span[data-type="subt"]').text(0);
    }else{
    var y = $(tr_ref).find('span[data-type="price1"]').text();
    y = parseFloat(parseFloat(y).toFixed(2));

    var total = y*parseFloat(x);

    if(isNaN(total))
    {
        total = 0;
    }
    total = parseFloat(parseFloat(total).toFixed(2));
    $(tr_ref).find('span[data-type="subt"]').text(total);
    //$('#subtotal_'+id+'').text(total);
    }

        var sum=0;
   
        $('tbody tr').each(function(){
          sum += parseFloat($(this).find('td:eq(4) span').text()); 
          //console.log(sum);
        });
        console.log('sum',sum);
        var cgst=parseFloat($('#cgst').val());
        var sgst=parseFloat($('#sgst').val());
       var gst=parseFloat(((cgst+sgst)*sum)/100);
        $('span#gtotal').html(sum.toFixed(2));
        if(isNaN(sum+gst))
    {
        $('span#gtotalamt').html(sum.toFixed(2));
    }else{
       $('span#gtotalamt').html((sum+gst).toFixed(2));
    }
        
       

console.log(gst+'and'+sum);
        //$('#gtotal').val(sum);
        
     
}
function savedata(){
  
  var mydata={};
  var userdata = {};
  userdata['id']      = $("#id").val();
  userdata['cid']      = $("#cid").val();
  userdata['cgst']      = $("#cgst").val();
  userdata['sgst']      = $("#sgst").val();
  userdata['cname']      = $("#cname").val();
  userdata['cnumber'] = $("#cnumber").val();
  userdata['caddress']   = $("#caddress").val();
  userdata['ccity']      = $("#ccity").val(); 
  userdata['gtotal']      = $("#gtotalamt").text();
  
  var productdata = [];
  $('table.product_list tbody tr').each(function(i,v){
    var products = {};
    products['id']  = $(this).find('#pid').val();
    products['producttype']  = $(this).find('#producttype').val();
    products['products']     = $(this).find('#selected_products').val();
    products['productprice'] = parseFloat($(this).find('span[data-type="price1"]').text());
    products['productqnty']  = $(this).find('#myinput').val();
    products['subt']         = parseFloat($(this).find('span[data-type="subt"]').text());
    productdata.push(products);
  })
  mydata['products'] = productdata;
  mydata['user'] = userdata;
  
  console.log(mydata);
 $.ajax({
              type : "POST",
              url : "../update",
              data: {
                     mydata:mydata // as you are getting in php $_POST['action1'] 
                     },
              dataType : "json",
              beforeSend: function(){
                    $('#loader').removeClass('hide');
                    $('#loader').addClass('loader');
              },
              success: function(response){
                    console.log(response);
                    if(response['status']==true)
                    {
                      window.location="/sewak/invoices";     
                    }else{
                        $('#error_msg').text(response['message']).addClass('alert btn-danger');
                    }    
              },
              complete: function(){
                    $('#loader').removeClass('loader');
                    $('#loader').addClass('hide');
               }
              
        });
}
function getProducts(this_ref){

       var mydata = $(this_ref).val();
        console.log(mydata);
        var name = $(this_ref).attr('name');
        var post;
       var prod={};
        if(name=='producttype'){
            post = 'producttype';
        }else{
            post = 'products';
        }
       
    var tr_ref = $(this_ref).parents('tr');
     $.ajax({
        type: "POST",
        url: "edit?ptype_id="+mydata+"&data_type="+post,
        
        dataType : "json",
        success: function(response) {
            //console.log(response);
        if(response['status']==true){
            var htmlp = '<option>SELECT PRODUCT</option>';
          if(response['prod'].length > 0 && post=="producttype"){
               $.each(response['prod'],function(i,v){
                
                htmlp+= '<option value="'+v['id']+'">'+v["name"]+'</option>';
             })
               
               //console.log(tr_ref);
               $(tr_ref).find('select[data-type="products"] option:not(:first)').remove();
              
               $(tr_ref).find('select[data-type="products"]').html(htmlp);
               
           }

            prodrow=response['prod'];
           console.log(post+'and'+(prodrow.length));
           if((prodrow.length > 0) && post=='products'){
               console.log(prodrow[0].qty);
               $(tr_ref).find('span[data-type="stock"]').text(prodrow[0].qty);
               $(tr_ref).find('span[data-type="price1"]').text(prodrow[0].price);
           }
          }

        }  
        
    
        });
 
    };
    function removeanother(id,this_refer){

    var prevtd = $(this_refer).parents('td').prev('td');
    console.log(prevtd);
    var coltotal = $(prevtd).find('span').text();
    console.log('coltotal-----'+coltotal);
    var coly = coltotal;
    console.log('coly----'+coly);
    var colval = parseFloat(parseFloat(coly).toFixed(2));
    var gtotalstring = $('span#gtotal').text();
    var gtotal = gtotalstring;
    var gval = parseFloat(parseFloat(gtotal).toFixed(2));
    var preprev = $(prevtd).prev('td');
    var val = $(preprev).find('input').val();
    if(val>0)
    {
        var result = gval - colval ;
    }
    else{
     var result = gval;
    }
    if(isNaN(result)!=true)
    {
        $('span#gtotal').text(result.toFixed(2));    
    }
    if(result<0){
      $('span#gtotal').text(0);
    }
    if($('table.product_list tbody tr').length==1)
    {
        console.log($('table.product_list tbody tr').length);
        $('table.product_list tbody tr').hide();   
    }
    else{
        $(this_refer).parents('tr').remove();
    }   
}
</script>
