

<!-- <ul class="pager">
    <li class="previous">
        <?= $this->tag->linkTo(['invoices', '&larr; Go Back']) ?>
    </li>
    <li class="next">
        <?= $this->tag->linkTo(['invoices/new', 'Create Invoice', 'class' => 'btn btn-success']) ?>
    </li>
</ul> -->
<div class="row"><br>

<div class="col-md-10">
</div>
<div class="col-md-2">
<?= $this->tag->linkTo(['invoices/new', 'Create Invoice', 'class' => 'btn btn-primary']) ?>
</div>
</div><br>
<?= $this->getContent() ?>
<?php $v27350815631iterated = false; ?><?php $v27350815631iterator = $page->items; $v27350815631incr = 0; $v27350815631loop = new stdClass(); $v27350815631loop->self = &$v27350815631loop; $v27350815631loop->length = count($v27350815631iterator); $v27350815631loop->index = 1; $v27350815631loop->index0 = 1; $v27350815631loop->revindex = $v27350815631loop->length; $v27350815631loop->revindex0 = $v27350815631loop->length - 1; ?><?php foreach ($v27350815631iterator as $product) { ?><?php $v27350815631loop->first = ($v27350815631incr == 0); $v27350815631loop->index = $v27350815631incr + 1; $v27350815631loop->index0 = $v27350815631incr; $v27350815631loop->revindex = $v27350815631loop->length - $v27350815631incr; $v27350815631loop->revindex0 = $v27350815631loop->length - ($v27350815631incr + 1); $v27350815631loop->last = ($v27350815631incr == ($v27350815631loop->length - 1)); ?><?php $v27350815631iterated = true; ?>

    <?php if ($v27350815631loop->first) { ?>
<table class="table table-bordered table-striped" align="center">
    <thead>
        <tr>
            <th>Number</th>
            <th>Customer</th>
            <th>Contact No.</th>
            <th>Date</th>
            <th>Total</th>
            <th colspan="3">Action</th>
            
        </tr>
    </thead>
    <tbody>
    <?php } ?>
        <tr>
            <td>#WG<?= $product->id ?></td>
            <td><?= $product->cname ?></td>
            <td><?= $product->cnumber ?></td>
            <td><?= $product->create_date ?></td>
            <td>$<?= sprintf('%.2f', $product->amount) ?></td>
            <td width="7%"><?= $this->tag->linkTo(['print/index/' . $product->id, '<i class="glyphicon glyphicon-eye-open"></i> View', 'class' => 'btn btn-success']) ?></td>
            <td width="7%"><?= $this->tag->linkTo(['invoices/edit/' . $product->id, '<i class="glyphicon glyphicon-edit"></i> Edit', 'class' => 'btn btn-warning']) ?></td>
            <td width="7%"><?= $this->tag->linkTo(['invoices/delete/' . $product->id, '<i class="glyphicon glyphicon-remove"></i> Delete', 'class' => 'btn btn-danger']) ?></td>
        </tr>
    <?php if ($v27350815631loop->last) { ?>
    </tbody>
    <tbody>
        <tr>
            <td colspan="8" align="right">
                <div class="btn-group">
                    <?= $this->tag->linkTo(['invoices/index', '<i class="icon-fast-backward"></i> First', 'class' => 'btn']) ?>
                    <?= $this->tag->linkTo(['invoices/index?page=' . $page->before, '<i class="icon-step-backward"></i> Previous', 'class' => 'btn']) ?>
                    <?= $this->tag->linkTo(['invoices/index?page=' . $page->next, '<i class="icon-step-forward"></i> Next', 'class' => 'btn']) ?>
                    <?= $this->tag->linkTo(['invoices/index?page=' . $page->last, '<i class="icon-fast-forward"></i> Last', 'class' => 'btn']) ?>
                    <span class="help-inline"><?= $page->current ?> of <?= $page->total_pages ?></span>
                </div>
            </td>
        </tr>
    </tbody>
</table>
    <?php } ?>
<?php $v27350815631incr++; } if (!$v27350815631iterated) { ?>
    No invoices are recorded
<?php } ?>
