<?php

class PrintController extends ControllerBase
{

    public function initialize()
    {

        $this->tag->setTitle('View invoice us');
        //parent::initialize();

    }

    public function indexAction($id)
    {
      // try{
    	$qry="SELECT t.*,i.*,p.* FROM ProductTypes as t,Invoice_items as i ,Products as p where t.id=i.ptype AND p.id=i.name AND i.invoiceid='".$id."'";
            
              $items = $this->modelsManager->executeQuery($qry);


              $amts = Invoices::findFirstById($id);
              $this->view->items = $items;
              $this->view->amts = $amts;
        // }catch(Exception $e){
        //   echo '<pre>';
        //   print_r($e->getMessage());
        // }

    }
}
