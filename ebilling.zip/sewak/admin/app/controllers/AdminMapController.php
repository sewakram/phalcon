<?php 
use Phalcon\Http\Request;
use Phalcon\Http\Response;
use Phalcon\Mvc\Model\Resultset\Simple;
class AdminMapController extends ControllerBase
{
    public function initialize()
    {
        $this->tag->setTitle('highlight_string(str)');
        parent::initialize();
    }
   public function indexAction()
   {
   	// echo "hi";exit();
   	
   	   try{    
		   $request=$this->request;
			$response = new Response();	
			if ($request->isAjax() == true) {
				$value = $request->getPost('value');
				$value = strpos($value,',') ? explode(',',$value) : (array)$value;
				$searchkey = $request->getPost('searchkey');
				$string = SiteOptions::findFirstByKey($searchkey);
				$strings = $string->toArray();
				$strings = json_decode($strings['value']);
				$found = array();
				$added = array();
				foreach ($value as $key => $keyvalue) {				
					if(!in_array($keyvalue, $strings))
					{
						array_push($strings, $keyvalue);	
						array_push($added,$keyvalue);
					}
					else{
						array_push($found,$keyvalue);
					}
				}
				$string->value = json_encode($strings);
				if($string->save()){
					return json_encode(array('status'=>true,'string'=>$strings,'found'=>$found,'added'=>$added));
				}
				else{
					return json_encode(array('status'=>false,'msg'=>'error'));	
				}
				
				exit();

			}
		}
	  catch(\Exception $e){
	  	return json_encode(array('status'=>false,'msg'=>$e->getMessage()));	
	  	exit();
	  }		
   }

}
?>