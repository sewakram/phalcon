<?php
use Phalcon\Mvc\Model\Criteria;
use Phalcon\Paginator\Adapter\Model as Paginator;
use Phalcon\Mvc\Model\Query;
class AdminLanguagesController extends ControllerBase
{   
    
    public function initialize()
    {
        $this->tag->setTitle('Languages');
        parent::initialize();
        
    }
    public function indexAction()
    {

            $languages = Languages::find( [
			"order" => "id DESC",
          ]);
        

        if (!$languages){
            $this->flash->notice("The search did not find any languages");
            return $this->response->redirect("admin-languages");
        }
          $this->view->data = $languages;
         // $this->view->langdata = $languages;
          $di = new \Phalcon\Di();
           $di->setShared('langdata', $languages);
      
    }

    
    /**
     * New create companies based on current criteria
     */
    public function newAction()
    {
        if ($this->request->isPost()) {
            $name = $this->request->getPost('name', array('string', 'striptags'));
            $code = $this->request->getPost('code');
            $countryprefix = $this->request->getPost('country_prefix');
            $languages = new Languages();
            $languages->name = $name;
            $languages->code = $code;
            $languages->country_prefix = $countryprefix;
			$base_url = $this->config->application['base_url'];
            if($this->request->hasFiles() == true)
            {
                 //checking if file exist
                 foreach($this->request->getUploadedFiles() as $file) {     
                    if( $file->getName()){
                         $slug = $file->getName();
						  $img_path="".$base_url."uploads/flag/".$slug;
                          $languages->flag_url = $img_path;
                          $file->moveTo("uploads/flag/".$slug);  
                         }
                       
                }
            }
            else{
                 foreach ($languages->getMessages() as $message) {
                    $this->flash->error((string) $message);
                }
            } 
            if ($languages->save() == false) {
                foreach ($languages->getMessages() as $message) {
                    $this->flash->error((string) $message);
                }
            } else {
                $this->flash->success('Language created successfully');
                return $this->response->redirect("admin-languages");
            }
        }
    }

    /**
     * Edits a company based on its id
     */
    public function editAction($id)
    {
        $language = Languages::findFirstById($id);
        if (!$this->request->isPost()) {
            if (!$language) {
                $this->flash->error("Language not found");
                return $this->forward("Language");
            }
            $this->view->setVars(array("language"=> $language));
        }else{
            /*echo "<pre>";print_r($_POST);*/
            $name = $this->request->getPost('name', array('string', 'striptags'));
            $code = $this->request->getPost('code');
            $countryprefix = $this->request->getPost('country_prefix');
			$name = isset($name)?$name:'';
			$code = isset($code)?$code:'';
            $countryprefix = isset($countryprefix)?$countryprefix:'';
            $language->name = $name;
            $language->code = $code;
            $language->country_prefix = $countryprefix;
			$base_url = $this->config->application['base_url'];
			
			if($this->request->hasFiles() == true){
                    foreach($this->request->getUploadedFiles() as $file) {
						 if( $file->getName()){
						  $slug = $file->getName();
						  $img_path="".$base_url."uploads/flag/".$slug;
                          $language->flag_url = $img_path;
                          $file->moveTo("uploads/flag/".$slug);  
						}   
                    }
                }
			
            if ($language->update() == false) {
                foreach ($language->getMessages() as $message) {
                    $this->flash->error((string) $message);
                }
            } else {
                $this->flash->success('Language updated successfully');
                return $this->response->redirect("admin-languages");
            }
        }
    }
    /**
     * Deletes a company
     *
     * @param string $id
     */
    public function deleteAction($id)
    {
        $this->view->disable();
        $request=$this->request;
        if ($request->isAjax() == true) {
            $user = Languages::findFirstById($id);
            if (!$user->delete()) {
                $errors = array();
                foreach ($user->getMessages() as $message) {
                    $errors[] = $message->getMessage();
                }
                echo json_encode(array('status'=>'error','msg'=>$errors,'id'=>$id));
                return;
            }else{
                echo json_encode(array('msg'=>'success','id'=>$id));
                return;
            }

        }        
    }
	public function editstringAction($id)
	{
		$this->view->id=$id;
	}

	public function update_stringAction() 
	{
	
		$l_id = $_POST['l_id'];
        $update_data = $_POST['update_data'];
        $update_type = $_POST['update_type'];
/*		$backEndData = $_POST['backEndData'];
		$frontEndData = $_POST['frontEndData'];
		$customersData = $_POST['customersData'];
		$operatorsData = $_POST['operatorsData'];*/
		$records=LanguagesString::findFirst("languages_id=$l_id");
			if(!$records==false)
			{
				
			    $records->languages_id=$l_id;
                switch ($update_type) {
                    case 'backend':
                        $records->backend=json_encode($update_data);
                    break;
                    case 'frontend':
                        $records->frontend=json_encode($update_data);
                    break;
                    case 'customer_app':
                        $records->customer_app=json_encode($update_data);
                    break;
                    case 'operator_app':
                        $records->operator_app=json_encode($update_data);
                    break;
                }
/*				$records->backend=json_encode($backEndData);
				$records->frontend=json_encode($frontEndData);
				$records->customer_app=json_encode($customersData);
				$records->operator_app=json_encode($operatorsData); */
                $error = array();
                if ($records->save() == false) {
                    foreach ($records->getMessages() as $message) {
                        $error[] = $message->getMessage();
                    }
                }
			return json_encode(array('msg'=>'success','error_message'=>$error));
			}
			else{
				$records = new LanguagesString();
				$records->languages_id = $l_id;
                switch ($update_type) {
                    case 'backend':
                        $records->backend=json_encode($update_data);
                    break;
                    case 'frontend':
                        $records->frontend=json_encode($update_data);
                    break;
                    case 'customer_app':
                        $records->customer_app=json_encode($update_data);
                    break;
                    case 'operator_app':
                        $records->operator_app=json_encode($update_data);
                    break;
                }
/*				$records->backend = json_encode($backEndData);
				$records->frontend = json_encode($frontEndData);
				$records->customer_app =json_encode($customersData);
				$records->operator_app =json_encode($operatorsData);*/
				//echo "different";
                $error = array();
				if ($records->save() == false) {
                    foreach ($records->getMessages() as $message) {
                        $error[] = $message->getMessage();
                    }
                }
            return json_encode(array('msg'=>'success','error_message'=>$error));
			}
			
	}
}



