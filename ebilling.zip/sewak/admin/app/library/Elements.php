<?php

use Phalcon\Mvc\User\Component;

/**
 * Elements
 *
 * Helps to build UI elements for the application
 */
class Elements extends Component
{
     private $_headerMenu = [
        'navbar-left' => [
            // 'index' => [
            //     'caption' => 'Home',
            //     'action' => 'index'
            // ],
            
            // 'about' => [
            //     'caption' => 'About',
            //     'action' => 'index'
            // ],
            // 'contact' => [
            //     'caption' => 'Contact',
            //     'action' => 'index'
            // ],
         ],
         'navbar-right' => [
            // 'index' => [
            //     'caption' => 'Home',
            //     'action' => 'index'
            // ],
            
            // 'about' => [
            //     'caption' => 'About',
            //     'action' => 'index'
            // ],
            // 'contact' => [
            //     'caption' => 'Contact',
            //     'action' => 'index'
            // ],
         ],
         'navbar-center' => [
            // 'session' => [
            //     // 'caption' => 'Log In/Sign Up',
            //     // 'action' => 'index'
            // ],profiles
         'users' => [
                'caption' => 'Users',
                'action' => 'index',
                'any' => true
            ],
          'profiles' => [
                'caption' => 'Rolls',
                'action' => 'index',
                'any' => true
            ],
        'admin-languages' => [
                'caption' => 'Manage languages',
                'action' => 'index',
                'any' => true
            ],
         'invoices' => [
                'caption' => 'Invoices',
                'action' => 'index',
                'any' => true
            ],
            'companies' => [
                'caption' => 'Companies',
                'action' => 'index',
                'any' => true
            ],
            'products' => [
                'caption' => 'Products',
                'action' => 'index',
                'any' => true
            ],
            'producttypes' => [
                'caption' => 'Product Types',
                'action' => 'index',
                'any' => true
            ],
            'profile' => [
                'caption' => 'Your Profile',
                'action' => 'index',
                'any' => false
            ],
          ]
     ];

    private $_tabs = [
        'Invoices' => [
            'controller' => 'invoices',
            'action' => 'index',
            'any' => false
        ],
        'Companies' => [
            'controller' => 'companies',
            'action' => 'index',
            'any' => false
        ],
        'Products' => [
            'controller' => 'products',
            'action' => 'index',
            'any' => false
        ],
        'Product Types' => [
            'controller' => 'producttypes',
            'action' => 'index',
            'any' => false
        ],
        'Your Profile' => [
            'controller' => 'invoices',
            'action' => 'profile',
            'any' => false
        ]
    ];

    /**
     * Builds header menu with left and right items
     *
     * @return string
     */
    public function getMenu()
    {

        $auth = $this->session->get('auth');
        if ($auth) {
            $this->_headerMenu['navbar-center']['users'];
            $this->_headerMenu['navbar-right']['session'] = [
                'caption' => 'Log Out',
                'action' => 'end'
            ];
            
        } else {
            unset($this->_headerMenu['navbar-left']['invoices']);
        }

        $controllerName = $this->view->getControllerName();
        foreach ($this->_headerMenu as $position => $menu) {
            echo '<div class="nav-collapse">';
            echo '<ul class="nav nav-tabs ', $position, '">';
            foreach ($menu as $controller => $option) {
                if ($controllerName == $controller) {
                    echo '<li class="active">';
                } else {
                    echo '<li>';
                }
                echo $this->tag->linkTo($controller . '/' . $option['action'], $option['caption']);
                echo '</li>';
            }
            echo '</ul>';
            echo '</div>';
        }

    }

    /**
     * Returns menu tabs
     */
    // public function getTabs()
    // {
    //     $controllerName = $this->view->getControllerName();
    //     $actionName = $this->view->getActionName();
    //     echo '<ul class="nav nav-tabs">';
    //     foreach ($this->_tabs as $caption => $option) {
    //         if ($option['controller'] == $controllerName && ($option['action'] == $actionName || $option['any'])) {
    //             echo '<li class="active">';
    //         } else {
    //             echo '<li>';
    //         }
    //         echo $this->tag->linkTo($option['controller'] . '/' . $option['action'], $caption), '</li>';
    //     }
    //     echo '</ul>';
    // }
}
